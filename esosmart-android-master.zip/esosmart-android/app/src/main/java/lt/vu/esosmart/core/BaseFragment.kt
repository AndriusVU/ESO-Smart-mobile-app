package lt.vu.esosmart.core

import android.content.Context
import android.widget.Toast
import androidx.fragment.app.Fragment

abstract class BaseFragment: Fragment() {
    fun showError(error:String){
        Toast.makeText(this.context, error, Toast.LENGTH_LONG).show()
    }
}