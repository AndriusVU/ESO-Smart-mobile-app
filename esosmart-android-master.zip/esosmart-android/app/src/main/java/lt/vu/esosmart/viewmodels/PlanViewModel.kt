package lt.vu.esosmart.viewmodels

import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import lt.vu.esosmart.data.Plans
import java.lang.ref.WeakReference

class PlanViewModel:BaseViewModel() {

    companion object{
        val TAG = "PlanViewModel"
    }

    var planStatus:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mGetPlansTask:GetPlansTask? = null

    var plans:Plans? = null

    fun doGetPlans(){
        mGetPlansTask = GetPlansTask(this, planStatus)
        mGetPlansTask?.execute()
    }

    fun hasPlans():Boolean{
        return plans != null
    }

    fun cancelRegister(){
        mGetPlansTask?.cancel(true)
        mGetPlansTask = null
    }

    fun isInProgress():Boolean{
        return mGetPlansTask!=null
    }


    private class GetPlansTask internal constructor(model: PlanViewModel, status:MutableLiveData<*>? = null):BaseTask<String>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: String?): BaseApi.ApiResponse? {

            val response = model.get()?.mBackendService?.doGetPlans()

            if(response is BaseApi.ApiSuccessResponse){
                model.get()?.plans = response.data as Plans
            }

            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mGetPlansTask = null
        }
    }

}