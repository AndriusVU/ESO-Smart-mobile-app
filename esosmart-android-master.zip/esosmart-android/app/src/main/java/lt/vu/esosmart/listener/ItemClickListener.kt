package lt.vu.esosmart.listener

import android.view.View


interface ItemClickListener {
    fun onItemClick(position: Int)
}