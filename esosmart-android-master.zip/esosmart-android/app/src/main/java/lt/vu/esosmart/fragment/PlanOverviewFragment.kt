package lt.vu.esosmart.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.app_bar_main.view.*
import kotlinx.android.synthetic.main.fragment_plan_overview.*
import kotlinx.android.synthetic.main.include_zone_price.view.*
import lt.vu.esosmart.App
import lt.vu.esosmart.BuildConfig
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.data.PriceType
import javax.inject.Inject

class PlanOverviewFragment:Fragment() {

    companion object{
        val TAG = "PlanOverviewFragment"
    }

    @Inject
    lateinit var mPrefs: Prefs


    val args:PlanOverviewFragmentArgs by navArgs()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.component.inject(this)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_plan_overview, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tv_plan_title.text = args.userPlan.plan.title

        if(args.userPlan.plan.description.isNotBlank()){
            tv_plan_desc.text = args.userPlan.plan.description
            tv_plan_desc.visibility = View.VISIBLE
        }else{
            tv_plan_desc.visibility = View.GONE
        }

        if(args.userPlan.plan.icon?.isNotBlank()?:false){
            Glide.with(iv_icon)
                .load(BuildConfig.ASSETS_BASE + args.userPlan.plan.icon)
                .apply(RequestOptions().fitCenter())
                .into(iv_icon)
        }

        tv_zone_title.text = args.userPlan.zone.title

        in_price_ded.visibility = View.GONE
        in_price_all.visibility = View.GONE
        in_price_day.visibility = View.GONE
        in_price_night.visibility = View.GONE
        in_price_morning.visibility = View.GONE
        in_price_evening.visibility = View.GONE

        args.userPlan.zone.prices.forEachIndexed { index, zonePrice ->

            var inView:View? = null
            var unit = getString(R.string.general_ct_kwh)

            when(zonePrice.id){
                PriceType.DED.id -> {
                    inView = in_price_ded
                    unit = getString(R.string.general_eur_m)
                }
                PriceType.ALL.id -> {
                    inView = in_price_all
                }
                PriceType.NIGHT.id -> {
                    inView = in_price_night
                }
                PriceType.MORNING.id -> {
                    inView = in_price_morning
                }
                PriceType.DAY.id -> {
                    inView = in_price_day
                }
                PriceType.EVENING.id -> {
                    inView = in_price_evening
                }
            }

            inView?.let {
                it.visibility = View.VISIBLE
                it.tv_price_title.text = zonePrice.title
                it.tv_price_amount.text = getString(R.string.general_float_format, zonePrice.price)
                it.tv_price_unit.text = unit
            }
        }

        btnContinue.setOnClickListener {
            mPrefs.userPlan = args.userPlan
            it.findNavController().navigate(
                R.id.homeFragment
            )
        }
        btnChange.setOnClickListener {
            it.findNavController().navigate(
                PlanOverviewFragmentDirections.actionPlanOverviewFragmentToMyPlanFragment()
            )
        }

    }
    override fun onStart() {
        super.onStart()
        requireActivity().nav_view.setCheckedItem(R.id.nav_my_plan)
        requireActivity().toolbar.tollbarTitle.text = getString(R.string.menu_my_plan)
    }
}