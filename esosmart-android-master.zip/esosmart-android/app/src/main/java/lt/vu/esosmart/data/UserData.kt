package lt.vu.esosmart.data

data class UserData(
    val id:Int,
    val first_name:String?,
    val last_name:String?,
    val phone:String,
    val email:String,
    val object_address:String,
    val object_uid:String?,
    val role: Array<String>,
    val roles: Array<UserRole>
) {
    fun getFullname():String{
        return first_name  + " " + last_name
    }
    fun isV1():Boolean{
        return role.contains(RoleType.V1.id)
    }
    fun isV2():Boolean{
        return role.contains(RoleType.V2.id)
    }
}

data class UserRole(
    val title:String,
    val description:String
)

enum class RoleType(val id:String){
    V0("v0"),
    V1("v1"),
    V2("v2"),
    V3("v3"),
}