package lt.vu.esosmart.core;

import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonSyntaxException
import lt.vu.esosmart.R
import lt.vu.esosmart.data.ErrorData
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import java.io.IOException
import java.lang.Exception
import java.util.*
import javax.inject.Inject

typealias MetaInfo = HashMap<String, Any>

open class BaseApi
constructor(
        protected val okHttpClient: OkHttpClient,
        protected val context: Context,
        protected val gson: Gson
)
{

    companion object {
        private val TAG = "BaseApi"

        val SUCCESS_RETURN = ApiSuccessResponse("ok")
        val CANCEL_RETURN = ApiCancelResponse("cancel")

        val XML = "text/xml; charset=utf-8".toMediaTypeOrNull()
        val JSON = "application/json; charset=utf-8".toMediaTypeOrNull()

        val METHOD_POST = "post"
        val METHOD_GET = "get"


        fun prettyContentFormat(content: String):String{
            return content
        }

    }

    var contentType = JSON

    lateinit var mApiEndpoint:String

    open protected fun getRequiredHeaders():Headers.Builder{
        return Headers.Builder()
    }


    open inner class BaseApiRequest<T, RespType>(val endpoint:String = mApiEndpoint){

        private lateinit var respTypeClass:Class<RespType>
        open val pathSegment:String? = null
        open val requestMethod = METHOD_POST

//        open protected fun getRequiredHeaders():Headers.Builder{
//            return Headers.Builder()
//        }

        open fun doRequest(requestData:T, cls:Class<RespType>):ApiResponse{
            respTypeClass = cls
            getUrlBuilder(requestData)?.also { urlBuilder ->
                getRequest(urlBuilder.build(), requestData)?.also {req ->
                    try{
                        val response = okHttpClient.newCall(req.build()).execute()
                        if(response.isSuccessful){

                            response.body?.let {
                                return onResponseSuccessful(it)
                            }?:run {
                                return ApiErrorResponse("Successful response body is empty")
                            }
                        }else{
                            response.body?.let {
                                return ApiErrorResponse(onResponseUnSuccessful(it))
                            }?:run{
                                return ApiErrorResponse("Unsuccessful response body is empty")
                            }
                        }
                    }catch (e:IOException){
                        e.printStackTrace()
                        return ApiErrorResponse(context.getString(R.string.request_io_error).format(e.message))
                    }
                }?.run {
                    return ApiErrorResponse("error: request failed to create")
                }
            }

            return ApiErrorResponse(context.getString(R.string.request_endpoint_error).format(endpoint))
        }

        open protected fun getRequestBodyContent(data:T):String?{
            return null
        }
        open protected fun getRequestBody(data:T):RequestBody{
            return RequestBody.create(contentType, getRequestBodyContent(data)?:"")
        }
        open protected fun getRequest(url:HttpUrl, requestData:T):Request.Builder?{
            val req = Request.Builder()
                    .url(url)
                    .headers(getRequiredHeaders().build())
            when(requestMethod){
                METHOD_GET -> {
                    return req.get()
                }
                METHOD_POST -> {
                    val reqBody = getRequestBody(requestData)
                    req.post(reqBody)
                }
            }
            return req
        }
        open fun getUrlBuilder(requestData:T):HttpUrl.Builder?{
            endpoint.toHttpUrlOrNull()?.newBuilder()?.also { urlBuilder ->
                if (pathSegment != null){
                    urlBuilder.addPathSegments(pathSegment!!)
                }
                return urlBuilder;
            }
            return null
        }

        open protected fun onResponseSuccessful(responseBody:ResponseBody):ApiResponse{
            val jsonBody = responseBody.string()

            try{
                val error = gson.fromJson<ErrorData>(jsonBody, ErrorData::class.java)
                if(error.error.isNotEmpty()){
                    return ApiErrorResponse(error.error, error.code)
                }
            }catch (e:Exception){
            }

            try{
                val data = gson.fromJson<RespType>(jsonBody, respTypeClass)
                return ApiSuccessResponse(data!!)
            }catch (e:Exception){


                if(jsonBody.contains("Request Rejected")){

                    val error = jsonBody.replace("(<.+?>|\\[Go Back\\])".toRegex(), " ").trim().replace("\\s+".toRegex(), " ")

                    return ApiErrorResponse(error)

                }else{
                    try{
                        val error = gson.fromJson<ErrorData>(jsonBody, ErrorData::class.java)
                        return ApiErrorResponse(error.error, error.code)
                    }catch (e:Exception){
                        return ApiErrorResponse("FromJsonException:" + e.message)
                    }
                }





            }
        }
        open protected fun onResponseUnSuccessful(responseBody:ResponseBody):String{
            return responseBody.string()
        }

        protected fun log(type:String, content:String){
            Log.d(TAG, "$type: " + "\n".repeat(2) + prettyContentFormat(content) + "\n".repeat(2) + "-".repeat(10))
        }
    }


    interface OnReqCallback{
        fun onReqSuccess()
        fun onReqCancel()
        fun onReqFailure(error:String)
    }


    open class ApiResponse(val response:String){}
    class ApiErrorResponse(var error:String, val code:Int? = 0):ApiResponse(error)
    class ApiSuccessResponse(val data: Any):ApiResponse(data.toString()){
        val json:String = response
    }
    class ApiProgressResponse(val progress:Int):ApiResponse(progress.toString())
    class ApiCancelResponse(val reason:String):ApiResponse(reason)

    data class JsonError(
            val error: JsonElement?
    )
}