package lt.vu.esosmart.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.holder_notification_item.view.*
import lt.kryptis.helpers.TextHelpers
import lt.vu.esosmart.BuildConfig
import lt.vu.esosmart.R
import lt.vu.esosmart.data.NotificationData
import lt.vu.esosmart.data.Plan
import lt.vu.esosmart.listener.ItemClickListener

class NotificationRecyclerViewAdapter(val items:Array<NotificationData>):RecyclerView.Adapter<NotificationRecyclerViewAdapter.ViewHolder>() {


    private var mClickListener:ItemClickListener? = null

    override fun getItemCount() = items.size;

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.holder_notification_item, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.setData(items[position]);

        holder.item.setOnClickListener {
            mClickListener?.onItemClick(position)
            holder.item.iv_isNew.visibility = View.INVISIBLE
        }
    }



    fun setClickListener(clickListener: ItemClickListener){
        mClickListener = clickListener
    }

    inner class ViewHolder(val item: View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(item){
        private var mData: NotificationData? = null;
        init {
            itemView.setOnClickListener {
            }
        }

        fun setData(data: NotificationData){
            mData = data;

            itemView.tv_title.text = data.subject
            itemView.tv_subtitle.text = TextHelpers.htmlToCharSequence(data.description)
            itemView.tv_date.text = data.created_at.getDateOnly()



            data.read_at?.let {
                itemView.iv_isNew.visibility = View.INVISIBLE
            }?:run{
                itemView.iv_isNew.visibility = View.VISIBLE
            }
        }
    }
}