package lt.vu.esosmart.viewmodels

import android.util.Log
import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.App
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import lt.vu.esosmart.data.*
import lt.vu.esosmart.fragment.userUsage.UserUsagetPeriod
import java.lang.ref.WeakReference
import javax.inject.Inject

class CompareViewModel:BaseViewModel() {

    companion object{
        val TAG = "CompareViewModel"
    }

    @Inject
    lateinit var mPrefs: Prefs

    init {
        App.component.inject(this)
    }

    var status:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mTask:RequestTask? = null

    var compareData:CompareData? = null

    fun doGetCompareData(period:UserUsagetPeriod){
        mTask = RequestTask(status){
            val compResp = mBackendService.doGetUserCompare(CompareRequestData(mPrefs.userToken?:"", period))
            if(compResp is BaseApi.ApiSuccessResponse){
                compareData = compResp.data as CompareData
            }
            compResp
        }
        mTask?.execute()
    }

    fun cancel(){
        mTask?.cancel(true)
        mTask = null
    }

    fun isInProgress():Boolean{
        return mTask!=null
    }

}