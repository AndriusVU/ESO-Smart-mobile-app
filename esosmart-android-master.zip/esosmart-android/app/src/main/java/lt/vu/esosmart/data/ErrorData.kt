package lt.vu.esosmart.data

data class ErrorData(
    val error:String,
    val code:Int?,
    val token:String?
)