package lt.vu.esosmart.Utillies

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.text.format.DateUtils
import android.util.Range
import android.view.inputmethod.InputMethodManager
import androidx.core.app.ActivityCompat
import lt.kryptis.helpers.DateHelper
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*


object Utilities {


    val dayHours:Range<Int> by lazy {
        Range<Int>(7,22)
    }
    val morningHours:Range<Int> by lazy {
        Range<Int>(5, 6)
    }

    val workHours:Range<Int> by lazy {
        Range<Int>(7, 16)
    }

    val eveningHours:Range<Int> by lazy {
        Range<Int>(17, 21)
    }
    /**
     * Gets an instance of a S3 client which is constructed using the given
     * Context.
     *
     * @param context An Context instance.
     * @return A default S3 client.
     */


    /**
     * Gets an instance of the TransferUtility which is constructed using the
     * given Context
     *
     * @param context
     * @return a TransferUtility instance
     */

    /**
     * Converts number of bytes into proper scale.
     *
     * @param bytes number of bytes to be converted.
     * @return A string that represents the bytes in a proper scale.
     */
    fun getBytesString(bytes: Long): String {
        val quantifiers = arrayOf("KB", "MB", "GB", "TB")
        var speedNum = bytes.toDouble()
        var i = 0
        while (true) {
            if (i >= quantifiers.size) {
                return ""
            }
            speedNum /= 1024.0
            if (speedNum < 512) {
                return String.format("%.2f", speedNum) + " " + quantifiers[i]
            }
            i++
        }
    }

    @SuppressLint("SimpleDateFormat")
    fun toSimpleString(date: Date) : String {
        val format = SimpleDateFormat("hh:mm")
        return format.format(date)
    }

    fun toDateString(date: Date) : String {
        val format = SimpleDateFormat("MMM dd")
        return format.format(date)
    }

    fun rgb(hex: String): Int {
        val color = java.lang.Long.parseLong(hex.replace("#", ""), 16).toInt()
        val r = color shr 16 and 0xFF
        val g = color shr 8 and 0xFF
        val b = color shr 0 and 0xFF
        return Color.rgb(r, g, b)
    }

    @SuppressLint("ObsoleteSdkInt")
    @Throws(Throwable::class)
    fun retriveVideoFrameFromVideo(videoPath: String): Bitmap? {
        var bitmap: Bitmap? = null
        var mediaMetadataRetriever: MediaMetadataRetriever? = null
        try {
            mediaMetadataRetriever = MediaMetadataRetriever()
            if (Build.VERSION.SDK_INT >= 14)
                mediaMetadataRetriever.setDataSource(videoPath, HashMap())
            else
                mediaMetadataRetriever.setDataSource(videoPath)

            bitmap = mediaMetadataRetriever.getFrameAtTime(1, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            e.printStackTrace()
            throw Throwable(
                "Exception in retriveVideoFrameFromVideo(String videoPath)" + e.message
            )

        } finally {
            mediaMetadataRetriever?.release()
        }
        return bitmap
    }

    fun showKeyboard(context: Context) {
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).toggleSoftInput(
            InputMethodManager.SHOW_FORCED,
            InputMethodManager.HIDE_IMPLICIT_ONLY
        )
    }


    fun openServerConnection(postData: String) {


        val thread = Thread(Runnable {
            try {
                val url = URL("https://fcm.googleapis.com/fcm/send")
                val httpURLConnection = url.openConnection() as HttpURLConnection
                httpURLConnection.setRequestProperty("Content-Type", "application/json")
                httpURLConnection.setRequestProperty(
                    "Authorization",
                    "key=${AppConstants.SEVER_KEY}"
                )
                httpURLConnection.requestMethod = "POST"
                httpURLConnection.doInput = true
                httpURLConnection.doOutput = true
                val outputStream = httpURLConnection.outputStream
                val bufferedWriter = BufferedWriter(OutputStreamWriter(outputStream, "UTF-8"))
                bufferedWriter.write(postData)
                bufferedWriter.flush()
                bufferedWriter.close()
                outputStream.close()
                val inputStream = httpURLConnection.inputStream
                val bufferedReader = BufferedReader(InputStreamReader(inputStream, "iso-8859-1"))
                val result = StringBuilder()
                var line = ""
//                while ((line = bufferedReader.readLine()) != null) {
//                    result.append(line)
//                }
                bufferedReader.close()
                inputStream.close()
                httpURLConnection.disconnect()

            } catch (e: IOException) {
                e.printStackTrace()
            }
        })

        thread.start()


        //  return null;
    }

    /**
     * Copies the data from the passed in Uri, to a new file for use with the
     * Transfer Service
     *
     * @param context
     * @param uri
     * @return
     * @throws IOException
     */
    @Throws(IOException::class)
    fun copyContentUriToFile(context: Context, uri: Uri): File {
        val `is` = context.contentResolver.openInputStream(uri)
        val copiedData = File(
            context.getDir("SampleImagesDir", Context.MODE_PRIVATE), UUID
                .randomUUID().toString()
        )
        copiedData.createNewFile()

        val fos = FileOutputStream(copiedData)
        val buf = ByteArray(2046)
        var read = -1
//        while ((read = `is`!!.read(buf)) != -1) {
//            fos.write(buf, 0, read)
//        }

        fos.flush()
        fos.close()

        return copiedData
    }

    fun isValid(url: String): Boolean {
        /* Try creating a valid URL */
        return try {
            URL(url).toURI()
            true
        } catch (e: Exception) {
            false
        }
        // If there was an Exception
        // while creating URL object
    }

    fun getApplicationName(context: Context): String {
        val applicationInfo = context.applicationInfo
        val stringId = applicationInfo.labelRes
        return if (stringId == 0) applicationInfo.nonLocalizedLabel.toString() else context.getString(stringId)
    }


    /*
	 * Fills in the map with information in the observer so that it can be used
	 * with a SimpleAdapter to populate the UI
	 */
    //	public static void fillMap(Map<String, Object> map, TransferObserver observer, boolean isChecked) {
    //		int progress = (int) ((double) observer.getBytesTransferred() * 100 / observer
    //				.getBytesTotal());
    //		map.put("id", observer.getId());
    //		map.put("checked", isChecked);
    //		map.put("fileName", observer.getAbsoluteFilePath());
    //		map.put("progress", progress);
    //		map.put("bytes",
    //				getBytesString(observer.getBytesTransferred()) + "/"
    //						+ getBytesString(observer.getBytesTotal()));
    //		map.put("state", observer.getState());
    //		map.put("percentage", progress + "%");
    //	}

    /**
     * Dismiss dialog
     */
    fun dismissDialog(dialog: Dialog) {

        try {

            dialog.dismiss()
        } catch (e: Exception) {

            //	LogUtil.e("Dismiss dialog", "Dismiss dialog");
        }

    }

    /**
     * Show alert dialog
     *
     * @param title
     * Dialog title
     * @param message
     * Dialog message
     * @param positiveText
     * Positive button text
     * @param negativeText
     * Negative button text
     * @param positiveButtonClick
     * Positive button click listener
     * @param negativeButtonClick
     * Negative button click listener
     * @param isCancelAble
     * True if can cancel
     */
    fun showAlertDialog(
        context: Context, title: String,
        message: String, positiveText: String, negativeText: String,
        positiveButtonClick: DialogInterface.OnClickListener?,
        negativeButtonClick: DialogInterface.OnClickListener?,
        isCancelAble: Boolean
    ) {

        val dialogBuilder = AlertDialog.Builder(context)
        dialogBuilder.setCancelable(isCancelAble)
        dialogBuilder.setMessage(message)
        if (title != "") {

            dialogBuilder.setTitle(title)
        }

        // Positive button
        if (positiveText != "") {

            if (positiveButtonClick != null) {

                dialogBuilder.setPositiveButton(
                    positiveText,
                    positiveButtonClick
                )
            } else {

                dialogBuilder.setPositiveButton(
                    positiveText
                ) { dialog, which -> dialog.dismiss() }
            }
        }

        // Negative button
        if (negativeText != "") {

            if (negativeButtonClick != null) {

                dialogBuilder.setNegativeButton(
                    negativeText,
                    negativeButtonClick
                )
            } else {

                dialogBuilder.setNegativeButton(
                    negativeText
                ) { dialog, which -> dialog.dismiss() }
            }
        }

        val dialog = dialogBuilder.create()
        dialog.show()
    }

    /**
     * Show alert dialog
     *
     * @param title
     * Dialog title
     * @param messages
     * Dialog message
     * @param positiveText
     * Positive button text
     * @param negativeText
     * Negative button text
     * @param positiveButtonClick
     * Positive button click listener
     * @param negativeButtonClick
     * Negative button click listener
     * @param isCancelAble
     * True if can cancel
     */
    fun showAlertDialogListDataCall(
        context: Context,
        title: String, messages: List<String>, positiveText: String,
        negativeText: String,
        positiveButtonClick: DialogInterface.OnClickListener?,
        negativeButtonClick: DialogInterface.OnClickListener?,
        isCancelAble: Boolean
    ) {

        val dialogBuilder = AlertDialog.Builder(context)
        dialogBuilder.setCancelable(isCancelAble)

        val Items = messages.toTypedArray<CharSequence>()
        dialogBuilder.setItems(Items) { dialog, i ->
            startCall(
                context,
                String.format(
                    "tel:%s",
                    Items[i].toString().replace("[^\\d.]".toRegex(), "")
                )
            )
            dialog.dismiss()
        }

        if (title != "") {

            dialogBuilder.setTitle(title)
        }

        // Positive button
        if (positiveText != "") {

            if (positiveButtonClick != null) {

                dialogBuilder.setPositiveButton(
                    positiveText,
                    positiveButtonClick
                )
            } else {

                dialogBuilder.setPositiveButton(
                    positiveText
                ) { dialog, which -> dialog.dismiss() }
            }
        }

        // Negative button
        if (negativeText != "") {

            if (negativeButtonClick != null) {

                dialogBuilder.setNegativeButton(
                    negativeText,
                    negativeButtonClick
                )
            } else {

                dialogBuilder.setNegativeButton(
                    negativeText
                ) { dialog, which -> dialog.dismiss() }
            }
        }

        val dialog = dialogBuilder.create()
        dialog.show()
    }

    fun startCall(ctx: Context, phone: String) {

        val intent = Intent(Intent.ACTION_CALL, Uri.parse(phone))
        //		ctx.startActivity(intent);
    }

    fun startSendMail(ctx: Context, email: String, subject: String) {

        val intent = Intent(
            Intent.ACTION_SENDTO, Uri.parse(
                String
                    .format("mailto:%s", email)
            )
        )
        intent.putExtra(Intent.EXTRA_SUBJECT, subject)
        ctx.startActivity(intent)
    }

    /**
     * Get type face
     */
    fun getTypeFace(context: Context, style: Int): Typeface {

        val typeFace: Typeface
        when (style) {
            1 ->

                typeFace = Typeface.createFromAsset(
                    context.assets,
                    "WorkSans-Thin.ttf"
                )
            2 ->

                typeFace = Typeface.createFromAsset(
                    context.assets,
                    "WorkSans-ExtraLight.ttf"
                )

            3 ->

                typeFace = Typeface.createFromAsset(
                    context.assets,
                    "WorkSans-Light.ttf"
                )

            4 ->

                typeFace = Typeface.createFromAsset(
                    context.assets,
                    "WorkSans-Regular.ttf"
                )

            5 ->

                typeFace = Typeface.createFromAsset(
                    context.assets,
                    "WorkSans-Medium.ttf"
                )

            6 ->

                typeFace = Typeface.createFromAsset(
                    context.assets,
                    "WorkSans-SemiBold.ttf"
                )

            7 ->

                typeFace = Typeface.createFromAsset(
                    context.assets,
                    "WorkSans-Bold.ttf"
                )

            8 ->

                typeFace = Typeface.createFromAsset(
                    context.assets,
                    "WorkSans-ExtraBold.ttf"
                )

            9 ->

                typeFace = Typeface.createFromAsset(
                    context.assets,
                    "WorkSans-Black.ttf"
                )

            else ->

                typeFace = Typeface.createFromAsset(context.assets, "WorkSans-Light.ttf")
        }

        return typeFace
    }


    /**
     * Check user permission
     *
     * @param context
     * Application context
     * @param permissions
     * List of permissions
     * @return true if has permission
     */
    fun hasPermissions(context: Context?, vararg permissions: String): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            && context != null && permissions != null
        ) {

            for (permission in permissions) {

                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {

                    return false
                }
            }
        }

        return true
    }

    /**
     * Get number of phone
     *
     * @param number
     * string phone number
     * @return number
     */
    private fun convertMobileToDomesticFormatAndValidate(number: String?): String? {
        var number: String? = number ?: return null

        if (number != "") {

            if (number!!.length >= 10) {

                // remove all non numeric characters
                number = number.replace("[^\\d.]".toRegex(), "")

                // if starts with 614 replace with 04
                if (number.startsWith("614")) {

                    number = String.format("04%s", number.substring(3))
                } else if (number.startsWith("6104")) { // if starts with 6104
                    // replace with 04

                    number = String.format("04%s", number.substring(4))
                }
            }
            if (number.length != 10 || !number.startsWith("04")) {

                number = ""
            }
        }

        return number
    }

    fun convertMobileAndEncrypt(number: String?): String? {
        var number = number

        number = convertMobileToInternationalFormatAndValidate(number)
        if (number == null || number == "") {

            return null
        }

        number = String.format("VouchifySecureSalt08%s", number)
        return sha256(number)
    }

    private fun sha256(number: String?): String? {

        val digest: MessageDigest
        try {

            digest = MessageDigest.getInstance("SHA-256")
            digest.update(number!!.toByteArray(charset("UTF-8")))
            //			number = MyBase64.encode(digest.digest());
        } catch (e1: Exception) {
            // TODO Auto-generated catch block
            e1.printStackTrace()
        }

        return number
    }

    /**
     *
     * convertMobileToInternationalFormatAndValidate
     */
    fun convertMobileToInternationalFormatAndValidate(
        number: String?
    ): String? {
        var number = number

        number = convertMobileToDomesticFormatAndValidate(number)
        if (number == null || number.isEmpty()) {

            return null
        }

        number = number.substring(1)
        return String.format("+61%s", number)
    }

    /**
     *
     */
    //	public static JsonObject addUserAuth(EventBaseActivity act, JsonObject object) {
    //
    //		if (object == null) {
    //
    //			object = new JsonObject();
    //		}
    //
    //		if (act.getUser() == null) {
    //
    //			return null;
    //		}
    //
    //		// if (act.getUser().getSessionTkn() != null &&
    //		// !act.getUser().getSessionTkn().equals("")) {
    //		//
    //		// object.addProperty(Constants.KEY_SESSION_TOKEN,
    //		// act.getUser().getSessionTkn());
    //		// } else {
    //		//
    //		// object.addProperty(Constants.KEY_SESSION_TOKEN,
    //		// CustomPreferences.getPreferences(Constants.PREF_SESSION_TOKEN, ""));
    //		// }
    //
    //		object.addProperty(Constants.KEY_USER_ID, act.getUser().getUserId());
    //		return object;
    //	}
    //
    /**
     * Check application is installed or not
     *
     * @param uri
     * package uri
     * @param context
     * [Context]
     * @return true if installed
     */
    fun isAppInstalled(uri: String, context: Context): Boolean {

        val pm = context.packageManager
        var installed: Boolean
        try {

            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES)
            installed = true
        } catch (e: PackageManager.NameNotFoundException) {

            installed = false
        }

        return installed
    }
}