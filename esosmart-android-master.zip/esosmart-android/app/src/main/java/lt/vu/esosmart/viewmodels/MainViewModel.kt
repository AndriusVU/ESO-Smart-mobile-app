package lt.vu.esosmart.viewmodels

import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.App
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import java.lang.ref.WeakReference
import javax.inject.Inject

class MainViewModel:BaseViewModel() {

    companion object{
        val TAG = "MainViewModel"
    }

    @Inject
    lateinit var mPrefs: Prefs

    var deleteUserStatus:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mDeleteUserTask:DeleteUserTask? = null

    init {
        App.component.inject(this)
    }

    fun doDeleteUser(){
        mDeleteUserTask = DeleteUserTask(this, deleteUserStatus)
        mDeleteUserTask?.execute(mPrefs.userToken?:"")
    }

    fun cancel(){
        mDeleteUserTask?.cancel(true)
        mDeleteUserTask = null
    }

    fun isInProgress():Boolean{
        return mDeleteUserTask!=null
    }


    private class DeleteUserTask internal constructor(model: MainViewModel, status:MutableLiveData<*>? = null):BaseTask<String>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: String?): BaseApi.ApiResponse? {
            val response = model.get()?.mBackendService?.doDeleteUser(param!!)
            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mDeleteUserTask = null
        }
    }
}