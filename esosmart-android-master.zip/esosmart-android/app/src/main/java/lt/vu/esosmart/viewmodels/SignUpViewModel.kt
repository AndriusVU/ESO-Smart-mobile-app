package lt.vu.esosmart.viewmodels

import android.util.Log
import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import lt.vu.esosmart.data.LoginRequestData
import lt.vu.esosmart.data.RegisterRequestData
import java.lang.ref.WeakReference

class SignUpViewModel:BaseViewModel() {

    companion object{
        val TAG = "SignUpViewModel"
    }

    var registerStatus:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    var loginStatus:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mRegisterTask:RegisterTask? = null
    private var mLoginTask:LoginTask? = null

    fun doRegister(formData: RegisterRequestData){
        mRegisterTask = RegisterTask(this, registerStatus)
        mRegisterTask?.execute(formData)
    }

    fun cancelRegister(){
        mRegisterTask?.cancel(true)
        mRegisterTask = null
    }

    fun doLogin(formData: LoginRequestData){
        mLoginTask = LoginTask(this, loginStatus)
        mLoginTask?.execute(formData)
    }
    fun cancelLogin(){
        mLoginTask?.cancel(true)
        mLoginTask = null
    }

    fun isInProgress():Boolean{
        return mRegisterTask!=null
    }


    private class RegisterTask internal constructor(model: SignUpViewModel, status:MutableLiveData<*>? = null):BaseTask<RegisterRequestData>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: RegisterRequestData?): BaseApi.ApiResponse? {

            val response = model.get()?.mBackendService?.doRegister(param!!)

            if(response is BaseApi.ApiSuccessResponse){
                Log.d(TAG, response.response)
            }

            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mRegisterTask = null
        }
    }
    private class LoginTask internal constructor(model: SignUpViewModel, status:MutableLiveData<*>? = null):BaseTask<LoginRequestData>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: LoginRequestData?): BaseApi.ApiResponse? {

            val response = model.get()?.mBackendService?.doLogin(param!!)

            if(response is BaseApi.ApiSuccessResponse){
                Log.d(TAG, response.response)
            }

            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mLoginTask = null
        }
    }
}