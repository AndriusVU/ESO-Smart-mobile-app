package lt.vu.esosmart.adapter

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import lt.vu.esosmart.fragment.userUsage.UserUsagetPeriod
import lt.vu.esosmart.fragment.userUsage.UserUsageChartFragment

class UserUsagePagerAdapter(fragment: Fragment):FragmentStateAdapter(fragment) {
    override fun getItemCount(): Int {
        return 3
    }

    override fun createFragment(position: Int): Fragment {

        val f = UserUsageChartFragment()

        val args = Bundle()

        when(position){
            0 -> args.putSerializable("period", UserUsagetPeriod.LAST_DAY)
            1 -> args.putSerializable("period", UserUsagetPeriod.LAST_WEEK)
            2 -> args.putSerializable("period", UserUsagetPeriod.LAST_MONTH)
        }

        f.arguments = args
        return f
    }
}