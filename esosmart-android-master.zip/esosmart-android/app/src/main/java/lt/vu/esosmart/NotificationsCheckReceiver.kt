package lt.vu.esosmart

import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.MutableLiveData
import lt.kryptis.helpers.TextHelpers
import lt.vu.esosmart.activity.MainActivity
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.MarkAsReadRequestData
import lt.vu.esosmart.data.NotificationsData
import lt.vu.esosmart.data.NotificationsRequestData
import lt.vu.esosmart.viewmodels.NotificationViewModel
import java.lang.ref.WeakReference

class NotificationsCheckReceiver:BroadcastReceiver() {

    companion object {
        val TAG = "AlarmReceiver"
    }

    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d(TAG, "onReceive")

        App.component.prefs().userToken?.let {
            GetTask().execute(context)
        }

        context?.let {

        }




    }

    private class MarkAsReadTask():AsyncTask<Int, Void?, BaseApi.ApiResponse?>(){
        override fun doInBackground(vararg p0: Int?): BaseApi.ApiResponse? {
            val id = p0[0]!!
            App.component.prefs().userToken?.let {
                return App.component.backendService().doMarkAsRead(
                    MarkAsReadRequestData(
                        id, it
                    )
                )
            }
            return null
        }
    }
    private class GetTask():AsyncTask<Context, Void?, BaseApi.ApiResponse?>(){

        var context:Context? = null

        override fun doInBackground(vararg p0: Context?): BaseApi.ApiResponse? {
            context = p0[0]

            Log.d(TAG, ""+ App.component.prefs().userToken)

            App.component.prefs().userToken?.let {
                val resp = App.component.backendService().doGetNotifications(NotificationsRequestData(it))
                return resp
            }

            return null
        }

        override fun onPostExecute(result: BaseApi.ApiResponse?) {
            super.onPostExecute(result)

            context?.let {context ->
                if(result is BaseApi.ApiSuccessResponse){
                    (result.data as NotificationsData).items.filter { it.read_at == null }.forEach {
                        //Log.d(TAG, it.description)


                        val intent = Intent(context, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        }
                        intent.putExtra("navigate_on_start", R.id.notificationsFragment)
                        intent.putExtra("notification_id", it.id)

                        val pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_CANCEL_CURRENT)


                        val builder = NotificationCompat.Builder(context, context.getString(R.string.eso_notification_channel_id))
                            .setSmallIcon(R.drawable.ic_launcher_foreground)
                            .setStyle(NotificationCompat.BigTextStyle().bigText(
                                TextHelpers.htmlToCharSequence(it.description)
                            ))
                            .setContentTitle(it.subject)
                            .setContentText(TextHelpers.htmlToCharSequence(it.description))
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                            .setContentIntent(pendingIntent)
                            .setAutoCancel(true)

                        with(NotificationManagerCompat.from(context)){
                            notify(it.id, builder.build())
                        }
                        MarkAsReadTask().execute(it.id)
                    }
                }
            }
            context = null
        }
    }
}