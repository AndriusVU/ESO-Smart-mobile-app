package lt.vu.esosmart.data

data class EnergyPrices(
    val items:List<EnergyPrice>
)

data class EnergyPrice(
    val id:Int,
    val date_from:String,
    val date_to:String,
    val price:Float,
    val transfer_distribution_price:Float
) {
}