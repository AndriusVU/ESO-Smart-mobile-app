package lt.vu.esosmart.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import kotlinx.android.synthetic.main.fragment_signup_complete.*
import lt.kryptis.helpers.IntentHelpers
import lt.vu.esosmart.App
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.activity.MainActivity
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.UserData
import lt.vu.esosmart.viewmodels.LoginViewModel
import javax.inject.Inject

class SignupCompleteFragment:BaseFragment() {

    companion object{
        val TAG = "SignupCompleteFragment"
    }

    @Inject
    lateinit var mPrefs: Prefs


    lateinit private var loginModel: LoginViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        App.component.inject(this)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view : View = inflater.inflate(R.layout.fragment_signup_complete, container, false)


        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loginModel = ViewModelProvider(this).get(LoginViewModel::class.java)
        loginModel.loginStatus.observe(viewLifecycleOwner, object : BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showProgress(false)
                showError(response.error)

                when(response.code){
                    404 -> {

                    }
                    else -> {
                    }
                }
                btnAgain.visibility = View.VISIBLE
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)

                if(response.data is UserData){
                    mPrefs.userData = response.data
                }
            }
        })

        btnContinue.setOnClickListener {
            MainActivity.start(requireContext())
            requireActivity().finish()
        }
        btnActivateRepeat.setOnClickListener {
            IntentHelpers.openUrl(getString(R.string.register_repeat_activation_url), requireContext())
        }
        btnAgain.setOnClickListener{
            btnAgain.visibility = View.GONE

            mPrefs.userToken?.let {
                loginModel.doLogin(it)
            }
        }

        mPrefs.userToken?.let {
            loginModel.doLogin(it)
        }
    }

    /**
     * Shows the progress UI and hides the register form.
     */
    fun showProgress(show: Boolean) {
        registerProgressbar.visibility = if (show) View.VISIBLE else View.GONE
        btnContinue.visibility = if (show) View.GONE else View.VISIBLE
    }
}