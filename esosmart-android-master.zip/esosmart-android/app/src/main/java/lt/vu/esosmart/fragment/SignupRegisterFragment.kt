package lt.vu.esosmart.fragment

import android.os.Bundle
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import kotlinx.android.synthetic.main.fragment_signup_register.*
import lt.vu.esosmart.App
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.LoginData
import lt.vu.esosmart.data.LoginRequestData
import lt.vu.esosmart.data.RegisterData
import lt.vu.esosmart.data.RegisterRequestData
import lt.vu.esosmart.viewmodels.SignUpViewModel
import javax.inject.Inject

class SignupRegisterFragment:BaseFragment() {

    companion object{
        val TAG = "SignupRegisterFragemnt"
    }

    @Inject
    lateinit var mPrefs: Prefs


    lateinit private var model: SignUpViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        App.component.inject(this)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view : View = inflater.inflate(R.layout.fragment_signup_register, container, false)


        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        model = ViewModelProvider(this).get(SignUpViewModel::class.java)
        model.registerStatus.observe(viewLifecycleOwner, object : BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showProgress(false, ProgressLocation.REGISTER)
                showError(response.error)
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true, ProgressLocation.REGISTER)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false, ProgressLocation.REGISTER)

                if(response.data is RegisterData){
                    mPrefs.userToken = response.data.token
                    findNavController().navigate(
                        SignupRegisterFragmentDirections.actionSignupRegisterFragmentToSignupCompleteFragment()
                    )
                }
            }
        })

        model.loginStatus.observe(viewLifecycleOwner, object : BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showProgress(false, ProgressLocation.LOGIN)
                showError(response.error)
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true, ProgressLocation.LOGIN)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false, ProgressLocation.LOGIN)

                if(response.data is LoginData){
                    findNavController().navigate(
                        SignupRegisterFragmentDirections.actionSignupRegisterFragmentToLoginCompleteFragment()
                    )
                }
            }
        })

        btnSignUp.setOnClickListener {

            var valid = true;

            if(etFullName.text.isEmpty()){
                etFullName.setError(getString(R.string.not_empty_error));
                valid = false;
            }else{
                etFullName.setError(null);
            }
            if(etAddress.text.isEmpty()){
                etAddress.setError(getString(R.string.not_empty_error));
                valid = false;
            }else{
                etAddress.setError(null);
            }
            if(etEmail.text.isEmpty()){
                etEmail.setError(getString(R.string.not_empty_error));
                valid = false;
            }else if(!Patterns.EMAIL_ADDRESS.matcher(etEmail.text).matches()){
                etEmail.setError(getString(R.string.not_email_error));
                valid = false;
            }else{
                etEmail.setError(null)
            }
//            if(etPhone.text.isEmpty()){
//                etPhone.setError(getString(R.string.not_empty_error));
//                valid = false;
//            }else{
//                etPhone.setError(null)
//            }

            if(valid){
                model.doRegister(
                    RegisterRequestData(
                        etFullName.text.toString(),
                        etAddress.text.toString(),
                        etEmail.text.toString(),
                        etPhone.text.toString()

                    )
                )
            }

        }
        btnLoginUp.setOnClickListener {
            var valid = true;
            if (etLoginEmail.text.isEmpty()) {
                etLoginEmail.setError(getString(R.string.not_empty_error));
                valid = false;
            } else if (!Patterns.EMAIL_ADDRESS.matcher(etLoginEmail.text).matches()) {
                etLoginEmail.setError(getString(R.string.not_email_error));
                valid = false;
            } else {
                etLoginEmail.setError(null)
            }


            if(valid){

                model.doLogin(
                    LoginRequestData(
                        etLoginEmail.text.toString()
                    )
                )
            }
        }
    }

    /**
     * Shows the progress UI and hides the register form.
     */
    fun showProgress(show: Boolean, location: ProgressLocation) {

        when(location){
            ProgressLocation.REGISTER -> {
                registerProgressbar.visibility = if (show) View.VISIBLE else View.GONE
                btnSignUp.visibility = if (show) View.GONE else View.VISIBLE
            }
            ProgressLocation.LOGIN -> {
                loginProgressbar.visibility = if (show) View.VISIBLE else View.GONE
                btnLoginUp.visibility = if (show) View.GONE else View.VISIBLE
            }
        }
        formWrap.isClickable = !show

    }

    enum class ProgressLocation(val location: String) {
        REGISTER("register"),
        LOGIN("login"),
    }
}