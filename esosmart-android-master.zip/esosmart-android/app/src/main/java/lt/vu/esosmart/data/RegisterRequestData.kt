package lt.vu.esosmart.data

data class RegisterRequestData(
    val fullName:String,
    val address:String,
    val email:String,
    val phone:String
) {
}