package lt.vu.esosmart.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.holder_plan_item.view.*
import lt.vu.esosmart.BuildConfig
import lt.vu.esosmart.R
import lt.vu.esosmart.data.Plan
import lt.vu.esosmart.listener.ItemClickListener

class PlansRecyclerViewAdapter(val items:List<Plan>):RecyclerView.Adapter<PlansRecyclerViewAdapter.ViewHolder>() {


    private var mClickListener:ItemClickListener? = null

    override fun getItemCount() = items.size;

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.holder_plan_item, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.setData(items[position]);

        holder.item.setOnClickListener {
            mClickListener?.onItemClick(position)
        }
    }



    fun setClickListener(clickListener: ItemClickListener){
        mClickListener = clickListener
    }

    inner class ViewHolder(val item: View) : androidx.recyclerview.widget.RecyclerView.ViewHolder(item){
        private var mData: Plan? = null;
        init {
        }

        fun setData(data: Plan){
            mData = data;

            itemView.tv_title.text = data.title
            itemView.tv_subtitle.text = data.description

            if(data.icon?.isNotBlank()?:false){
                Glide.with(itemView.iconImage)
                    .load(BuildConfig.ASSETS_BASE + data.icon)
                    .apply(RequestOptions().centerInside().placeholder(R.drawable.ic_plan))
                    .into(item.iconImage)
            }

            data.date_from?.let {

                itemView.tv_subtitle.visibility = View.VISIBLE
                itemView.tv_subtitle.text = itemView.context.getString(R.string.plan_choose_update_date).format(it.getDateOnly())

            }?:run{
                itemView.tv_subtitle.visibility = View.GONE
            }
        }
    }
}