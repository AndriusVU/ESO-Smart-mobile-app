package lt.vu.esosmart.Utillies

import android.content.SharedPreferences
import com.google.gson.Gson
import lt.vu.esosmart.data.UserData
import lt.vu.esosmart.data.UserPlan
import javax.inject.Inject
import javax.inject.Singleton


@Singleton
class Prefs @Inject constructor(
    val mPrefs:SharedPreferences,
    val gson: Gson
) {

    var userToken: String?
        get() {
            if(mPrefs.contains(USERTOKEN)){
                return mPrefs.getString(USERTOKEN, "")
            }
            return null
        }
        set(value) {
            value?.let {
                mPrefs.edit().putString(USERTOKEN, value).apply()
            }?:run{
                mPrefs.edit().remove(USERTOKEN).apply()
            }
        }
    var userPlan:UserPlan?
        get(){
            mPrefs.getString(USERPLAN, null)?.let {
                try{
                    return gson.fromJson(it, UserPlan::class.java)
                }catch (e:Exception){
                    e.printStackTrace()
                }
            }
            return null
        }
        set(plan){
            plan?.let {
                mPrefs.edit().putString(USERPLAN, gson.toJson(plan)).apply()
            }?:run{
                mPrefs.edit().remove(USERPLAN).apply()
            }
        }


    var isFirstRun: Boolean
        get() = mPrefs.getBoolean(ISFIRSTRUN, true)
        set(isFirstRun) = mPrefs.edit().putBoolean(ISFIRSTRUN, isFirstRun).apply()

    var isAnon: Boolean
        get() = mPrefs.getBoolean(ISANON, false)
        set(isFirstRun) = mPrefs.edit().putBoolean(ISANON, isFirstRun).apply()

    var deviceToken: String
        get() = mPrefs.getString(DEVICETOKEN, "")?:""
        set(deviceToken) = mPrefs.edit().putString(DEVICETOKEN, deviceToken).apply()

    var isReceivedMessage: Boolean
        get() = mPrefs.getBoolean(ISRECEIVEDMESSAGE, false)
        set(isReceivedMessage) = mPrefs.edit().putBoolean(ISRECEIVEDMESSAGE, isReceivedMessage).apply()


    var userData:UserData? = null


    fun cleanupUserData(){
        isFirstRun = true
        isAnon = false
        userPlan = null
        userToken = null
        userData = null
    }




    companion object {

        private val USERTOKEN = "USERTOKEN"
        private val USERPLAN = "USERPLAN"
        private val ISFIRSTRUN = "isFirstRun"
        private val ISANON = "isAnon"
        private val DEVICETOKEN = "deviceToken"
        private val ISRECEIVEDMESSAGE = "isReceivedMessage"

//        private var instance: Prefs? = null
//
//        fun getInstance(context: Context): Prefs? {
//            if (instance == null) {
//                synchronized(Prefs::class.java) {
//                    if (instance == null) {
//                        instance = Prefs(context.applicationContext)
//                    }
//                }
//            }
//            return instance
//        }
    }


}