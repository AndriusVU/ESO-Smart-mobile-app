package lt.vu.esosmart.data

data class LoginData(
    val ok:Boolean
)