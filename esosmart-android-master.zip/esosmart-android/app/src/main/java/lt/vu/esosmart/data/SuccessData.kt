package lt.vu.esosmart.data

import java.io.FileDescriptor

data class SuccessData(
    val ok:Boolean
)