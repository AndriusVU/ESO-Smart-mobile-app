package lt.vu.esosmart.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import lt.vu.esosmart.R
import lt.vu.esosmart.core.BaseActivity
import lt.vu.esosmart.core.BaseActivityFragment
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.fragment.SignupCompleteFragment
import lt.vu.esosmart.fragment.SignupRegisterFragment
import lt.vu.esosmart.fragment.SignupTypeFragment

class SignupActivity : BaseActivityFragment() {

    companion object{
        val TAG = "SignupActivity"
        fun start(context: Context) {
            context.startActivity(Intent(context, SignupActivity::class.java))
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

    }
}
