package lt.vu.esosmart.core

import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

abstract class BaseActivity: AppCompatActivity() {
    fun showError(error:String){
        Toast.makeText(this, error, Toast.LENGTH_LONG).show()
    }
}