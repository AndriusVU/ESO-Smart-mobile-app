package lt.vu.esosmart.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import kotlinx.android.synthetic.main.fragment_login_complete.*
import lt.vu.esosmart.App
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseFragment
import javax.inject.Inject

class LoginCompleteFragment:BaseFragment() {

    companion object{
        val TAG = "SignupCompleteFragment"
    }

    @Inject
    lateinit var mPrefs: Prefs


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        App.component.inject(this)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view : View = inflater.inflate(R.layout.fragment_login_complete, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        btnActivateRepeat.setOnClickListener {
            findNavController().navigate(
                LoginCompleteFragmentDirections.actionLoginCompleteFragmentToSignupTypeFragment()
            )
        }
    }
}