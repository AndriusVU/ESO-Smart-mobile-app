package lt.vu.esosmart.viewmodels

import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import lt.vu.esosmart.data.Date
import lt.vu.esosmart.data.EnergyUsage
import java.lang.ref.WeakReference

class ProjectedViewModel:BaseViewModel() {

    companion object{
        val TAG = "ProjectedViewModel"
    }

    var status:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mTask:GetTask? = null

    var energyUsages:Array<EnergyUsage>? = null

    fun doGetEnergyUsages(date:String){
        mTask = GetTask(this, status)
        mTask?.execute(date)
    }

    fun hasPrices():Boolean{
        return energyUsages != null
    }

    fun cancel(){
        mTask?.cancel(true)
        mTask = null
    }

    fun isInProgress():Boolean{
        return mTask!=null
    }


    private class GetTask internal constructor(model: ProjectedViewModel, status:MutableLiveData<*>? = null):BaseTask<String>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: String?): BaseApi.ApiResponse? {

            val response = model.get()?.mBackendService?.doGetEnergyUsage(param!!)

            if(response is BaseApi.ApiSuccessResponse){
                model.get()?.energyUsages = response.data as Array<EnergyUsage>
            }

            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mTask = null
        }
    }

}