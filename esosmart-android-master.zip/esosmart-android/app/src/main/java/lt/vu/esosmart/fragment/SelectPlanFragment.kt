package lt.vu.esosmart.fragment


import android.app.AlertDialog
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.app_bar_main.view.*
import kotlinx.android.synthetic.main.fragment_select_plan.*
import lt.vu.esosmart.R
import lt.vu.esosmart.adapter.PlansRecyclerViewAdapter
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.Plan
import lt.vu.esosmart.data.PlanZone
import lt.vu.esosmart.data.UserPlan
import lt.vu.esosmart.listener.ItemClickListener
import lt.vu.esosmart.viewmodels.PlanViewModel
import lt.vu.esosmart.widget.DividerItemDecoration

class SelectPlanFragment: BaseFragment(){

    companion object{
        val TAG = "HomeChoosePlanFragment"
    }

    lateinit var model:PlanViewModel;

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_select_plan, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        model = ViewModelProvider(this).get(PlanViewModel::class.java)
        model.planStatus.observe(viewLifecycleOwner, object: BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
            }
            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)
                initPlans()
            }
        })

        if(model.hasPlans()){
            initPlans()
        }else{
            model.doGetPlans()
        }

        tv_source.movementMethod = LinkMovementMethod.getInstance()
    }

    private fun initPlans(){
        model.plans?.let {
            plansRecyclerView.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(activity);
            plansRecyclerView.addItemDecoration(DividerItemDecoration(context, LinearLayout.VERTICAL))
            val adapter = PlansRecyclerViewAdapter(it.items)
            adapter.setClickListener(object : ItemClickListener{
                override fun onItemClick(position: Int) {

                    val planData = adapter.items.get(position)
                    showPlanZones(planData)
                }
            })
            plansRecyclerView.adapter = adapter
        }
    }

    private fun showPlanZones(plan:Plan){

        //jei zona yra tik viena, tai iskart ja ir parenkam
        if(plan.zones.size == 1){
            selectPlanAndZone(plan, plan.zones.first())
            return
        }

        //jei yra daugiau, tai duodam pasirinkima

        val zones:Array<String> = plan.zones.map {
            it.title
        }.toTypedArray()

        AlertDialog.Builder(context)
            .setTitle(R.string.plan_choose_zone)
            .setNegativeButton(R.string.general_cancel){ _, _ -> }
            .setItems(zones) { _, which ->
                selectPlanAndZone(
                    plan, plan.zones[which]
                )
            }
            .create().show()
    }

    private fun selectPlanAndZone(plan:Plan, zone:PlanZone){
        requireView().findNavController().navigate(
            SelectPlanFragmentDirections.actionSelectPlanFragmentToPlanOverviewFragment(
                UserPlan(plan, zone)
            )
        )
    }

    override fun onStart() {
        super.onStart()
        requireActivity().nav_view.setCheckedItem(R.id.nav_my_plan)
        requireActivity().toolbar.tollbarTitle.text= getString(R.string.plan_choose_title)
    }

    /**
     * Shows the progress UI and hides the register form.
     */
    fun showProgress(show: Boolean = true) {
        registerProgressbar.visibility = if (show) View.VISIBLE else View.GONE
        plansRecyclerView.visibility = if (show) View.GONE else View.VISIBLE
    }
}