package lt.vu.esosmart.service

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.google.gson.reflect.TypeToken
import lt.vu.esosmart.App
import lt.vu.esosmart.data.RegisterData
import okhttp3.Response
import java.io.IOException
import javax.inject.Inject

class BackendCallback<T>constructor(
    val gson:Gson
) {

    companion object{
        val TAG = "BackendCallback"
    }

    var mSuccess: ((response: T)->Unit)? = null
    var mFail: ((msg:String)->Unit)? = null

    fun onFail(callback:(msg:String)->Unit):BackendCallback<T>{
        mFail = callback
        return this;
    }
    fun onSuccess(callback:(response: T)->Unit):BackendCallback<T>{
        mSuccess = callback
        return this;
    }


    internal fun onResponse(response: Response){
        when(response.code){
            200 -> {

                val jsonString = response.body?.string()?:"null"

                if(jsonString.isNotEmpty()){
                    try{

//                        val data = gson.fromJson<T>(jsonString,  object: T::class.java)
//                        mSuccess?.invoke(data);
                    }catch (e:JsonSyntaxException){
                        mFail?.invoke("json error:" + e.message)
                    }
                }else{
                    mFail?.invoke("response body is empty")
                }

            }
            else -> mFail?.invoke(response.code.toString() + ":" + response.body?.string()?:"")
        }
    }
    internal fun onFailure(e: IOException){
        mFail?.invoke(
            e.localizedMessage?:"unknown IO onFailure"
        )
    }

}