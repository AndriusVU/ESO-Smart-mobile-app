package lt.vu.esosmart.activity

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.View
import androidx.lifecycle.ViewModelProvider
import kotlinx.android.synthetic.main.activity_splash.*
import lt.vu.esosmart.App
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.BaseActivity
import lt.vu.esosmart.data.RegisterData
import lt.vu.esosmart.data.UserData
import lt.vu.esosmart.viewmodels.LoginViewModel
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import javax.inject.Inject


class SplashActivity : BaseActivity() {

    companion object{
        val TAG = "SplashActivity"
        fun start(context: Context) {
            context.startActivity(Intent(context, SplashActivity::class.java))
        }
    }

    @Inject
    lateinit var mPrefs: Prefs


    lateinit private var loginModel: LoginViewModel

    var confirmationHash:String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        App.component.inject(this)
        supportActionBar?.hide()

        confirmationHash = intent?.data?.getQueryParameter("hash")

        //mPrefs.isFirstRun = false
        //mPrefs.userToken = "2d260b293b025018f21b81c5afd82298"



        loginModel = ViewModelProvider(this).get(LoginViewModel::class.java)
        loginModel.loginStatus.observe(this, object : BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
                showProgress(false)

                when(response.code){
                    404-> {
                        mPrefs.userToken = null
                        nextAction()
                    }
                    else -> {
                        btnAgain.visibility = View.VISIBLE
                    }
                }
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)
                if(response.data is UserData){
                    mPrefs.userData = response.data
                }
                nextAction()
            }
        })

        loginModel.confirmStatus.observe(this, object : BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
                showProgress(false)

                nextAction()
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)
                if(response.data is RegisterData){
                    mPrefs.userToken = response.data.token
                }
                nextAction()
            }
        })




        btnAgain.setOnClickListener {
            loginModel.doLogin(mPrefs.userToken!!)
            btnAgain.visibility = View.GONE

        }

        if(!loginModel.isInProgress()){
            nextAction()
        }


        //sendBroadcast(Intent(this, NotificationsCheckReceiver::class.java))
    }

    private fun showProgress(show:Boolean = true){
        if(show){
            registerProgressbar.visibility = View.VISIBLE
        }else{
            registerProgressbar.visibility = View.GONE
        }
    }

    private fun nextAction(){

        if(!mPrefs.isFirstRun){

            //val hash = intent?.data?.getQueryParameter("hash")

            if(confirmationHash != null){
                loginModel.doConfirm(confirmationHash!!)
                confirmationHash = null
                return
            }else if(mPrefs.userData != null || mPrefs.isAnon){
                MainActivity.start(this)
            }else if(mPrefs.userToken !=null ){
                loginModel.doLogin(mPrefs.userToken!!)
                return
            }else{
                SignupActivity.start(this)
            }
        }else{
            WalkthroughActivity.start(this)
        }
        finish()
    }


    private fun getUserData(){

//        val ref = db.collection("users").document(mAuth?.currentUser!!.uid)
//
//        ref.get().addOnSuccessListener {
//            val userInfo = it.toObject(UserModel::class.java)
//            MApplication.currentUser = userInfo
//            MApplication.currentUser!!.active = true
//            FirestoreUtil.updateUser(MApplication.currentUser!!){
//
//            }
//
//            val intent = Intent(this, MainActivity::class.java)
//            startActivity(intent)
//            finish()
//
//        }.addOnFailureListener {it
//            Log.e("Error : ", it.localizedMessage)
//            val intent = Intent(this, AuthActivity::class.java)
//            startActivity(intent)
//            finish()
//        }


    }

    private fun getHashKey(context: Context) {
        try {
            val info = context.packageManager.getPackageInfo(
                context.packageName, PackageManager.GET_SIGNATURES
            )
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                Log.e("MY_KEY_HASH:", Base64.encodeToString(md.digest(), Base64.DEFAULT))
            }
        } catch (e: PackageManager.NameNotFoundException) {
        } catch (e: NoSuchAlgorithmException) {
        }

    }
}
