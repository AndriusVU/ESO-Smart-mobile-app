package lt.vu.esosmart.fragment


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.lifecycle.ViewModelProvider
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.app_bar_main.view.*
import kotlinx.android.synthetic.main.fragment_notifications.*
import kotlinx.android.synthetic.main.fragment_notifications.registerProgressbar
import lt.kryptis.helpers.DateHelper
import lt.vu.esosmart.R
import lt.vu.esosmart.adapter.NotificationRecyclerViewAdapter
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.*
import lt.vu.esosmart.listener.ItemClickListener
import lt.vu.esosmart.viewmodels.NotificationViewModel
import lt.vu.esosmart.widget.DividerItemDecoration

class NotificationsFragment: BaseFragment(){

    companion object{
        val TAG = "NotificationsFragment"
    }

    lateinit var notificationViewModel: NotificationViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_notifications, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        notificationViewModel = ViewModelProvider(this).get(NotificationViewModel::class.java)
        notificationViewModel.status.observe(viewLifecycleOwner, object: BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
            }
            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)

                init(
                    (response.data as NotificationsData)
                )
            }
        })

        notificationViewModel.notificationsData?.let {
            init(it)
        }?:run{
            notificationViewModel.doGetNotifications()
        }
    }

    private fun init(data:NotificationsData){

        notificationsRecyclerView.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(activity);
        notificationsRecyclerView.addItemDecoration(DividerItemDecoration(context, LinearLayout.VERTICAL))
        val adapter = NotificationRecyclerViewAdapter(data.items)
        adapter.setClickListener(object : ItemClickListener{
            override fun onItemClick(position: Int) {

                if(data.items.get(position).read_at == null){
                    notificationViewModel.markAsRead(
                        data.items.get(position)
                    )
                    data.items.get(position).read_at = Date(DateHelper.formatDate(java.util.Date(), "yyyy-MM-dd HH:mm:ss.SSS"))
                }
            }
        })
        notificationsRecyclerView.adapter = adapter

//        model.plans?.let {
//            plansRecyclerView.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(activity);
//            plansRecyclerView.addItemDecoration(DividerItemDecoration(context, LinearLayout.VERTICAL))

//        }
    }



    override fun onStart() {
        super.onStart()
        requireActivity().nav_view.setCheckedItem(R.id.nav_notification)
        requireActivity().toolbar.tollbarTitle.text= getString(R.string.menu_notification)
    }

    /**
     * Shows the progress UI and hides the register form.
     */
    fun showProgress(show: Boolean = true) {
        registerProgressbar.visibility = if (show) View.VISIBLE else View.GONE
        notificationsRecyclerView.visibility = if (show) View.GONE else View.VISIBLE
    }
}