package lt.vu.esosmart.data

import java.io.FileDescriptor


data class NotificationsData(
    val items:Array<NotificationData>
)

data class NotificationData(
    val id:Int,
    val subject:String,
    val message:String,
    val description:String,
    val created_at:Date,
    var read_at:Date?
)