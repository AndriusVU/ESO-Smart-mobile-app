package lt.vu.esosmart.data


data class EnergyUsage(
    val time:String,
    val forecast_usage:Float,
    val planned_production:Float,
    val planned_production_wind:Float
)

data class EnergyHistoricalUsage(
    val year:Int,
    val month:Int,
    val hour:String,
    val energy_usage:Float,
    val production:Float,
    val production_wind:Float
)