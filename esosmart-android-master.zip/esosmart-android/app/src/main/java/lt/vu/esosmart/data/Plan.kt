package lt.vu.esosmart.data

import android.os.Parcelable
import android.util.Log
import kotlinx.android.parcel.Parcelize
import lt.vu.esosmart.Utillies.Utilities
import java.util.*

enum class PriceType(val id:String){
    DED("ded"),
    ALL("all"),
    NIGHT("night"),
    MORNING("morning"),
    DAY("day"),
    EVENING("evening")
}

@Parcelize
data class UserPlan(
    val plan:Plan,
    val zone:PlanZone
):Parcelable

@Parcelize
data class Plan(
    val id:Int,
    val title:String,
    val description:String,
    val date_from:Date?,
    val date_to:Date?,
    val icon:String?,
    val zones:List<PlanZone>
):Parcelable {
    fun getZoneById(id:Int):PlanZone?{
        return zones.firstOrNull {
            it.id == id
        }
    }
}

data class Plans(
    val items:List<Plan>
)

@Parcelize
data class PlanZone(
    val id:Int,
    val title:String,
    val prices:List<ZonePrice>
):Parcelable{

    companion object{
        val cal = Calendar.getInstance()
    }

    fun getPriceByTimestamp(time:Long):Float{
        cal.timeInMillis = time

        if(isSingleZone()){
            return getAllPrice();
        }else{

            val h = cal.get(Calendar.HOUR_OF_DAY)

            when(cal.get(Calendar.DAY_OF_WEEK)){
                Calendar.SATURDAY, Calendar.SUNDAY -> {
                    //savaitgalis
                    if(isFourZone()){
                        if(Utilities.dayHours.contains(h)) return getDayPrice()
                        else return getNightPrice()
                    }else{
                        return getNightPrice()
                    }
                }
                else -> {
                    //iprasta diena
                    if(isFourZone()){
                        when(h){
                            in Utilities.morningHours -> return getMorningPrice()
                            in Utilities.workHours -> return getDayPrice()
                            in Utilities.eveningHours -> return getEveningPrice()
                            else -> return getNightPrice()
                        }
                    }else{
                        if(Utilities.dayHours.contains(h)) return getDayPrice()
                        else return getNightPrice()
                    }
                }
            }
        }

        return 0f
    }

    fun isFourZone():Boolean{
        return prices.find { it.id == PriceType.MORNING.id } != null
    }
    fun isSingleZone():Boolean{
        return prices.find { it.id == PriceType.ALL.id } != null
    }

    fun getDayPrice():Float { return getPrice(PriceType.DAY) }
    fun getAllPrice():Float { return getPrice(PriceType.ALL) }
    fun getNightPrice():Float { return getPrice(PriceType.NIGHT) }
    fun getMorningPrice():Float { return getPrice(PriceType.MORNING) }
    fun getEveningPrice():Float { return getPrice(PriceType.EVENING) }
    fun getDedPrice():Float { return getPrice(PriceType.DED) }

    fun getPrice(type:PriceType):Float{
        return prices.find { it.id == type.id }?.price?:0f
    }


}

@Parcelize
data class ZonePrice(
    val id:String,
    val title:String,
    val price:Float
):Parcelable