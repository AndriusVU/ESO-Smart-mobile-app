package lt.vu.esosmart.viewmodels

import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import lt.vu.esosmart.data.EnergyHistoricalUsage
import java.lang.ref.WeakReference

class HistoricalViewModel:BaseViewModel() {

    companion object{
        val TAG = "HistoricalViewModel"
    }

    var status:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mTask:GetTask? = null

    var historicalEnergyUsages:Array<EnergyHistoricalUsage>? = null

    fun doGetEnergyHistoricalUsages(year:String){
        mTask = GetTask(this, status)
        mTask?.execute(year)
    }

    fun hasPrices():Boolean{
        return historicalEnergyUsages != null
    }

    fun cancel(){
        mTask?.cancel(true)
        mTask = null
    }

    fun isInProgress():Boolean{
        return mTask!=null
    }


    private class GetTask internal constructor(model: HistoricalViewModel, status:MutableLiveData<*>? = null):BaseTask<String>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: String?): BaseApi.ApiResponse? {

            val response = model.get()?.mBackendService?.doGetEnergyHistoricalUsage(param!!)

            if(response is BaseApi.ApiSuccessResponse){
                model.get()?.historicalEnergyUsages = response.data as Array<EnergyHistoricalUsage>
            }

            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mTask = null
        }
    }

}