package lt.vu.esosmart.viewmodels

import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import lt.vu.esosmart.data.EnergyPrices
import java.lang.ref.WeakReference

class EnergyPriceViewModel:BaseViewModel() {

    companion object{
        val TAG = "EnergyPriceViewModel"
    }

    var status:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mGetEnergyPricesTask:GetEnergyPricesTask? = null

    var energyPrices:EnergyPrices? = null

    fun doGetEnergyPrices(){
        mGetEnergyPricesTask = GetEnergyPricesTask(this, status)
        mGetEnergyPricesTask?.execute()
    }

    fun hasPrices():Boolean{
        return energyPrices != null
    }

    fun cancel(){
        mGetEnergyPricesTask?.cancel(true)
        mGetEnergyPricesTask = null
    }

    fun isInProgress():Boolean{
        return mGetEnergyPricesTask!=null
    }


    private class GetEnergyPricesTask internal constructor(model: EnergyPriceViewModel, status:MutableLiveData<*>? = null):BaseTask<String>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: String?): BaseApi.ApiResponse? {

            val response = model.get()?.mBackendService?.doGetEnergyPrices(param)

            if(response is BaseApi.ApiSuccessResponse){
                model.get()?.energyPrices = response.data as EnergyPrices
            }

            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mGetEnergyPricesTask = null
        }
    }

}