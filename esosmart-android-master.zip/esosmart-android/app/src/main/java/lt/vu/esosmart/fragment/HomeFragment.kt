package lt.vu.esosmart.fragment


import android.os.Bundle
import android.text.Html
import android.text.method.LinkMovementMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.text.HtmlCompat
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.findNavController
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.app_bar_main.view.*
import kotlinx.android.synthetic.main.fragment_home.*
import lt.kryptis.helpers.DateHelper
import lt.kryptis.helpers.TextHelpers
import lt.vu.esosmart.App
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.*
import lt.vu.esosmart.viewmodels.EnergyPriceViewModel
import java.text.SimpleDateFormat
import java.util.*
import java.util.Date
import java.util.concurrent.TimeUnit
import java.util.logging.SimpleFormatter
import javax.inject.Inject
import kotlin.time.hours

class HomeFragment: BaseFragment(){
    companion object{
        val TAG = "HomeFragment"
    }
    @Inject
    lateinit var mPrefs: Prefs

    lateinit var energyPriceViewModel: EnergyPriceViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.component.inject(this)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_home, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        energyPriceViewModel = ViewModelProvider(this).get(EnergyPriceViewModel::class.java)
        energyPriceViewModel.status.observe(viewLifecycleOwner, object: BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
                showProgress(false)
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)

                mPrefs.userPlan?.let {
                    if(response.data is EnergyPrices){
                        initChart(response.data.items, it)
                    }
                }


            }
        })

        tv_ded_desc.visibility = View.GONE
        tv_desc.movementMethod = LinkMovementMethod.getInstance()

        mPrefs.userPlan?.let {
            if(it.zone.getDedPrice() > -1){
                tv_ded_desc.text =TextHelpers.htmlToSpanned(getString(R.string.price_ded_description, it.zone.getDedPrice()))
                tv_ded_desc.visibility = View.VISIBLE
            }
        }
    }



    override fun onStart() {
        super.onStart()
        requireActivity().nav_view.setCheckedItem(R.id.nav_my_and_market_price)
        requireActivity().toolbar.tollbarTitle.text = getString(R.string.menu_my_and_market_price)


        mPrefs.userPlan?.let { userPlan ->
            energyPriceViewModel.energyPrices?.let {
                initChart(it.items, userPlan)
            }?:run{
                energyPriceViewModel.doGetEnergyPrices()
            }
        }?:run{
            requireView().findNavController().navigate(
                HomeFragmentDirections.actionHomeFragmentToMyPlanFragment()
            )
        }
    }

    private fun initChart(energyPrices: List<EnergyPrice>, userPlan:UserPlan){

        val energyPricesEntries = arrayListOf<BarEntry>()
        val myPriceEntries = arrayListOf<Entry>()

        energyPrices.forEachIndexed { index, energyPrice ->

            if(index == 24) return@forEachIndexed

            val timestamp = DateHelper.strDateToTimestamp(energyPrice.date_from)
            //val hourTimesamp = TimeUnit.MILLISECONDS.toHours(timestamp).toFloat()
            val hourIndex = index.toFloat()

            energyPricesEntries.add(
                BarEntry(
                    hourIndex,
                    floatArrayOf(energyPrice.transfer_distribution_price, energyPrice.price)
                )
            )


            if(index == 0){
                myPriceEntries.add(
                    Entry(-1f, userPlan.zone.getPriceByTimestamp(timestamp))
                )
            }

            myPriceEntries.add(
                Entry(hourIndex, userPlan.zone.getPriceByTimestamp(timestamp))
            )

            if(index == 23){
                myPriceEntries.add(
                    Entry(24f, userPlan.zone.getPriceByTimestamp(timestamp))
                )
            }
        }

        val energyPricesDataset = BarDataSet(energyPricesEntries, "")
        energyPricesDataset.setColors(
            intArrayOf(
                R.color.colorChart2, R.color.colorChart1
            ), requireContext())
        energyPricesDataset.stackLabels = arrayOf(
            getString(R.string.transfer_distribution_price),
            getString(R.string.energy_price)
        )
        energyPricesDataset.setDrawValues(false)

        val myPriceDataSet = LineDataSet(myPriceEntries, getString(R.string.my_price))
        myPriceDataSet.setColor(requireContext().getColor(R.color.colorChart3))
        myPriceDataSet.setDrawCircles(false)
        myPriceDataSet.setDrawValues(false)
        myPriceDataSet.lineWidth = 2f


        val combineData = CombinedData()
        combineData.setData(BarData(energyPricesDataset))
        combineData.setData(LineData(myPriceDataSet))
        combineData.isHighlightEnabled = false


        val chart = combinedChart
        chart.description.isEnabled = false

        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.setDrawGridLines(false)
        chart.xAxis.granularity = 1f

        chart.xAxis.valueFormatter = object : ValueFormatter(){
            private val mFormat = SimpleDateFormat("HH:00", Locale("lt"))
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return "%2.0f:00".format(value)

            }
        }
        chart.xAxis.axisMinimum = -0.5f
        chart.xAxis.axisMaximum = 23.5f


        chart.axisLeft.axisMinimum = 0f
        chart.axisRight.isEnabled = false

        chart.legend.setWordWrapEnabled(true)
        chart.legend.verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
        chart.legend.horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT

        chart.isScaleXEnabled = true
        chart.setPinchZoom(true)
        chart.isDragEnabled = true
        chart.setTouchEnabled(true)


        chart.data = combineData
        chart.invalidate()
    }

    /**
     * Shows the progress UI and hides the register form.
     */
    fun showProgress(show: Boolean = true) {
        //progressbar.visibility = if (show) View.VISIBLE else View.GONE
    }
}