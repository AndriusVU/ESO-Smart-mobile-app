package lt.vu.esosmart.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.app_bar_main.view.*
import kotlinx.android.synthetic.main.fragment_user_usage.*
import lt.vu.esosmart.R
import lt.vu.esosmart.adapter.UserUsagePagerAdapter
import lt.vu.esosmart.core.BaseFragment

class UserUsageFragment:BaseFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_user_usage, container, false)
        return view
    }

    override fun onStart() {
        super.onStart()
        requireActivity().nav_view.setCheckedItem(R.id.nav_my_usage)
        requireActivity().toolbar.tollbarTitle.text= getString(R.string.menu_my_usage)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        pager.adapter = UserUsagePagerAdapter(this)

        TabLayoutMediator(tabLayout, pager){ tab, position ->
            tab.text = when(position){
                0 -> getString(R.string.my_usage_last_day_tab)
                1 -> getString(R.string.my_usage_last_week_tab)
                2 -> getString(R.string.my_usage_last_month_tab)
                else -> "???"
            }
        }.attach()
    }
}