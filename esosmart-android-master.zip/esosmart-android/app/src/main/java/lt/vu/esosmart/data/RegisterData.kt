package lt.vu.esosmart.data

data class RegisterData(
    val token:String,
    val id:Int

)