package lt.vu.esosmart.fragment.historicalAndProjected

import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter
import kotlinx.android.synthetic.main.fragment_projected.*
import lt.kryptis.helpers.DateHelper
import lt.vu.esosmart.R
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.*
import lt.vu.esosmart.viewmodels.ProjectedViewModel
import java.util.Date

class ProjectedFragment:BaseFragment() {

    companion object{
        val TAG = "ProjectedFragment"
    }

    lateinit var projectedViewModel: ProjectedViewModel


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_projected, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        projectedViewModel = ViewModelProvider(this).get(ProjectedViewModel::class.java)
        projectedViewModel.status.observe(viewLifecycleOwner, object: BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
                showProgress(false)
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)

                initChart(
                    response.data as Array<EnergyUsage>
                )

            }
        })

        tv_top_desc.movementMethod = LinkMovementMethod.getInstance()

        projectedViewModel.energyUsages?.let {
            initChart(it)
        }?:run{
            projectedViewModel.doGetEnergyUsages(DateHelper.formatDate(Date()))
        }
    }

    private fun initChart(energyUsages: Array<EnergyUsage>){

        val forecast_usageEntries = arrayListOf<Entry>()
        val planned_productionEntries = arrayListOf<Entry>()
        val planned_production_windEntries = arrayListOf<Entry>()


        energyUsages.forEach{

            val timeParts = it.time.split(":")
            val h = timeParts[0].toFloat()

            forecast_usageEntries.add(Entry(h, it.forecast_usage))
            planned_productionEntries.add(Entry(h, it.planned_production))
            planned_production_windEntries.add(Entry(h, it.planned_production_wind))
        }

        val forecast_usageDataset = LineDataSet(forecast_usageEntries, getString(R.string.projected_forecast_usage))
        forecast_usageDataset.setColor(requireContext().getColor(R.color.colorChart1))
        forecast_usageDataset.setDrawCircles(false)
        forecast_usageDataset.setDrawValues(false)
        forecast_usageDataset.lineWidth = 2f

        val planned_productionDataset = LineDataSet(planned_productionEntries, getString(R.string.projected_planned_production))
        planned_productionDataset.setColor(requireContext().getColor(R.color.colorChart2))
        planned_productionDataset.setDrawCircles(false)
        planned_productionDataset.setDrawValues(false)
        planned_productionDataset.lineWidth = 2f

        val planned_production_windDataset = LineDataSet(planned_production_windEntries, getString(R.string.projected_planned_production_wind))
        planned_production_windDataset.setColor(requireContext().getColor(R.color.colorChart3))
        planned_production_windDataset.setDrawCircles(false)
        planned_production_windDataset.setDrawValues(false)
        planned_production_windDataset.lineWidth = 2f


        val lineData = LineData(forecast_usageDataset, planned_productionDataset, planned_production_windDataset)
        lineData.isHighlightEnabled = false


        val chart = lineChart
        chart.description.isEnabled = false

        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.setDrawGridLines(false)
        chart.xAxis.granularity = 1f
        chart.xAxis.valueFormatter = object : ValueFormatter(){
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return "%02.0f:00".format(value)
            }
        }

        chart.axisLeft.axisMinimum = 0f
        chart.axisRight.isEnabled = false

        chart.legend.form = Legend.LegendForm.LINE

        chart.legend.setWordWrapEnabled(true)
        chart.legend.verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
        chart.legend.horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT

//        chart.legend.orientation = Legend.LegendOrientation.VERTICAL
//        chart.legend.verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
//        chart.legend.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
//        chart.legend.yOffset = 10f

        chart.isScaleXEnabled = true
        chart.setPinchZoom(true)
        chart.isDragEnabled = true
        chart.setTouchEnabled(true)

        chart.data = lineData
        chart.invalidate()
    }

    /**
     * Shows the progress UI and hides the register form.
     */
    fun showProgress(show: Boolean = true) {
        registerProgressbar.visibility = if (show) View.VISIBLE else View.GONE
    }
}