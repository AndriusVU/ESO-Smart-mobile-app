package lt.vu.esosmart.di.component

import android.content.Context
import android.content.SharedPreferences
import dagger.Component
import lt.vu.esosmart.App
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.activity.MainActivity
import lt.vu.esosmart.activity.SignupActivity
import lt.vu.esosmart.activity.SplashActivity
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.di.module.ApplicationModule
import lt.vu.esosmart.di.module.NetModule
import lt.vu.esosmart.fragment.*
import lt.vu.esosmart.fragment.userUsage.UserUsageChartFragment
import lt.vu.esosmart.service.BackendService
import lt.vu.esosmart.viewmodels.CompareViewModel
import lt.vu.esosmart.viewmodels.MainViewModel
import lt.vu.esosmart.viewmodels.NotificationViewModel
import lt.vu.esosmart.viewmodels.UserUsageViewModel
import javax.inject.Singleton

@Singleton
@Component(modules = arrayOf(ApplicationModule::class, NetModule::class))
interface ApplicationComponent {
    fun app():App
    fun context():Context
    fun preferences(): SharedPreferences
    fun backendService():BackendService;
    fun prefs():Prefs


    fun inject(viewModel: BaseViewModel)
    fun inject(viewModel: UserUsageViewModel)
    fun inject(viewModel: CompareViewModel)
    fun inject(viewModel: NotificationViewModel)
    fun inject(viewModel: MainViewModel)

    fun inject(apiResponse: BaseApi.ApiSuccessResponse)

    fun inject(activity: SignupActivity)
    fun inject(activity: SplashActivity)
    fun inject(activity: MainActivity)

    fun inject(fragment: SignupRegisterFragment)
    fun inject(fragment: SignupCompleteFragment)
    fun inject(fragment: LoginCompleteFragment)
    fun inject(fragment: PlanOverviewFragment)
    fun inject(fragment: HomeFragment)
    fun inject(fragment: SignupTypeFragment)
    fun inject(fragment: UserUsageChartFragment)

}