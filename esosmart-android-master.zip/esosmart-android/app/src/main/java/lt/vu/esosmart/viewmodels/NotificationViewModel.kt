package lt.vu.esosmart.viewmodels

import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.App
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import lt.vu.esosmart.data.*
import java.lang.ref.WeakReference
import javax.inject.Inject

class NotificationViewModel:BaseViewModel() {

    companion object{
        val TAG = "NotificationViewModel"
    }

    @Inject
    lateinit var mPrefs: Prefs

    var status:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()
    var markAsReadStatus:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mTask:GetTask? = null

    var notificationsData:NotificationsData? = null

    init {
        App.component.inject(this)
    }

    fun doGetNotifications(){
        mTask = GetTask(this, status)
        mTask?.execute(NotificationsRequestData(mPrefs.userToken?:""))
    }
    fun markAsRead(notification:NotificationData){
        GetMarkAsReadTask(this, markAsReadStatus).execute(
            MarkAsReadRequestData(notification.id, mPrefs.userToken?:"")
        )
    }

    fun hasData():Boolean{
        return notificationsData != null
    }

    fun cancel(){
        mTask?.cancel(true)
        mTask = null
    }

    fun isInProgress():Boolean{
        return mTask!=null
    }


    private class GetTask internal constructor(model: NotificationViewModel, status:MutableLiveData<*>? = null):BaseTask<NotificationsRequestData>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: NotificationsRequestData?): BaseApi.ApiResponse? {

            val response = model.get()?.mBackendService?.doGetNotifications(param!!)

            if(response is BaseApi.ApiSuccessResponse){
                model.get()?.notificationsData = response.data as NotificationsData
            }

            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mTask = null
        }
    }

    private class GetMarkAsReadTask internal constructor(model: NotificationViewModel, status:MutableLiveData<*>? = null):BaseTask<MarkAsReadRequestData>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: MarkAsReadRequestData?): BaseApi.ApiResponse? {

            val response = model.get()?.mBackendService?.doMarkAsRead(param!!)
            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mTask = null
        }
    }
}