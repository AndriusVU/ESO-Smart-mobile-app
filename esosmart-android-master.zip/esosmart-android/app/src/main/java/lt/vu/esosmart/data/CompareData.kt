package lt.vu.esosmart.data

data class CompareData(
    val my_total:Float,
    val my_average:Float,
    val others_average:Float,
    val energy_group:EnergyGroup?
) {
}