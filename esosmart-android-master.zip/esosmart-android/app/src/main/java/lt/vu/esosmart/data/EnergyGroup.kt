package lt.vu.esosmart.data

data class EnergyGroup(
    val id:Int,
    val interval_from:Int,
    val interval_to:Int,
    val title:String
) {
}