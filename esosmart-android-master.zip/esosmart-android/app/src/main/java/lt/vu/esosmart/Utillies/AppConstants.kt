package lt.vu.esosmart.Utillies


object AppConstants {
    const val USER_NAME = "USER_NAME"
    const val USER_ID = "USER_ID"
    const val CHANNEL_ID = "channel_id"
    const val CHANNEL_NAME = "channel_name"
    const val SEVER_KEY = "AAAAONSoOHs:APA91bFCEHSFCsKsnnR0peA-4PbkUtBJruQfKrsTYECTVwz6QMTgpwRgQ10YSSUhhmBpxuPMRj6lEAS2ql7Oq6Kf5swA96yrzq5fr0Nt1X21OwE4FzAOg0M2EhBZYsCf7tLPMq30vJGO"
    const val NOTIFICATION_TYPE = "NOTIFICATION_TYPE"
}