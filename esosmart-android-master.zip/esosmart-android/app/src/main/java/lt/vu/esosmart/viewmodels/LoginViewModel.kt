package lt.vu.esosmart.viewmodels

import android.util.Log
import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import lt.vu.esosmart.data.UserData
import java.lang.Exception
import java.lang.ref.WeakReference

class LoginViewModel:BaseViewModel() {

    companion object{
        val TAG = "LoginViewModel"
    }

    var loginStatus:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    var confirmStatus:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mLoginTask:LoginTask? = null
    private var mConfirmTask:ConfirmTask? = null
    private var userData:UserData? = null

    fun doLogin(token: String){

        Log.d(TAG, "Do login with: " + token)

        mLoginTask = LoginTask(this, loginStatus)
        mLoginTask?.execute(token)
    }

    fun doConfirm(hash:String){
        Log.d(TAG, "Do confirm with: " + hash)

        mConfirmTask = ConfirmTask(this, confirmStatus)
        mConfirmTask?.execute(hash)
    }

    fun isInProgress():Boolean{
        return mLoginTask!=null || mConfirmTask != null
    }

    fun getLoginData(json:String):UserData?{
        try{
            val data = gson.fromJson(json, UserData::class.java)
            return data
        }catch (e:Exception){
            e.printStackTrace()
        }
        return null;
    }


    private class LoginTask internal constructor(model: LoginViewModel, status:MutableLiveData<*>? = null):BaseTask<String>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: String?): BaseApi.ApiResponse? {
            val response = model.get()?.mBackendService?.doAuth(param!!)
            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mLoginTask = null
        }
    }

    private class ConfirmTask internal constructor(model: LoginViewModel, status:MutableLiveData<*>? = null):BaseTask<String>(status){
        private val model = WeakReference(model)
        override fun doRequest(param: String?): BaseApi.ApiResponse? {
            val response = model.get()?.mBackendService?.doConfirm(param!!)
            return response
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            model.get()?.mConfirmTask = null
        }
    }

}