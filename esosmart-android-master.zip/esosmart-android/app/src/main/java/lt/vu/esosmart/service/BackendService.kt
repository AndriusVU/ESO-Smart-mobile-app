package lt.vu.esosmart.service

import android.content.Context
import com.google.gson.Gson
import lt.vu.esosmart.BuildConfig
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.data.*
import okhttp3.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BackendService @Inject constructor(
    okHttpClient: OkHttpClient,
    context: Context,
    gson: Gson
):BaseApi(okHttpClient, context, gson) {
    companion object {
        val TAG = "BackendService"
        val endpoint = BuildConfig.BACKEND_URL
    }

    override fun getRequiredHeaders(): Headers.Builder {
        return super.getRequiredHeaders()
            .removeAll("Authorization")
            .add("Authorization", Credentials.basic("beta", "beta"))
    }

    fun doRegister(data: RegisterRequestData):ApiResponse{
        val response = DoRegisterRequest(endpoint).doRequest(data, RegisterData::class.java)
        return response
    }

    fun doLogin(data: LoginRequestData):ApiResponse{
        val response = DoLoginRequest(endpoint).doRequest(data, LoginData::class.java)
        return response
    }

    fun doAuth(token:String):ApiResponse{
        val response = DoAuthRequest(endpoint).doRequest(token, UserData::class.java)
        return response
    }

    fun doConfirm(hash:String):ApiResponse{
        val response = DoConfirmRequest(endpoint).doRequest(hash, RegisterData::class.java)
        return response
    }

    fun doDeleteUser(token:String):ApiResponse{
        val response = DoDeleteUserRequest(endpoint).doRequest(token, SuccessData::class.java)
        return response
    }

    fun doGetPlans():ApiResponse{
        val response = DoGetPlansRequest(endpoint).doRequest(cls = Plans::class.java, requestData = null)
        return response
    }

    fun doGetEnergyPrices(date:String?):ApiResponse{
        val response = DoGetEnergyPricesRequest(endpoint).doRequest(date, EnergyPrices::class.java)
        return response
    }


    fun doGetEnergyUsage(date:String):ApiResponse{
        val response = DoGetEnergyUsageRequest(endpoint).doRequest(date, Array<EnergyUsage>::class.java)
        return response
    }
    fun doGetEnergyGroup(token:String):ApiResponse{
        val response = DoGetUserEnergyGroupRequest(endpoint).doRequest(token, EnergyGroup::class.java)
        return response
    }

    fun doGetEnergyHistoricalUsage(year:String):ApiResponse{
        val response = DoGetEnergyHistoricalUsageRequest(endpoint).doRequest(year, Array<EnergyHistoricalUsage>::class.java)
        return response
    }
    fun doGetUserUsage(data:UserUsageRequestData):ApiResponse{
        val response = DoGetUserUsageRequest(endpoint).doRequest(data, Array<UserUsage>::class.java)
        return response
    }
    fun doGetUserCompare(data:CompareRequestData):ApiResponse{
        val response = DoGetUserCompareRequest(endpoint).doRequest(data, CompareData::class.java)
        return response
    }

    fun doGetNotifications(data:NotificationsRequestData):ApiResponse{
        val response = DoGetNotificationsRequest(endpoint).doRequest(data, NotificationsData::class.java)
        return response
    }
    fun doMarkAsRead(data:MarkAsReadRequestData):ApiResponse{
        val response = DoMarkNotificationAsReadRequest(endpoint).doRequest(data, SuccessData::class.java)
        return response
    }
    inner class DoRegisterRequest(endpoint:String):BaseApiRequest<RegisterRequestData, RegisterData>(endpoint){
        override val pathSegment: String = "users/register"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data: RegisterRequestData): RequestBody {
            val nameParts = data.fullName.split(" ")
            return FormBody.Builder()
                .add("email", data.email)
                .add("first_name", nameParts.first())
                .add("last_name", nameParts.last())
                .add("phone", data.phone)
                .add("object_address", data.address)
                .build()
        }
    }

    inner class DoLoginRequest(endpoint:String):BaseApiRequest<LoginRequestData, LoginData>(endpoint){
        override val pathSegment: String = "users/login"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data: LoginRequestData): RequestBody {
            return FormBody.Builder()
                .add("email", data.email)
                .build()
        }
    }

    inner class DoAuthRequest(endpoint:String):BaseApiRequest<String, UserData>(endpoint){
        override val pathSegment: String = "users/auth"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data: String): RequestBody {
            return FormBody.Builder()
                .add("token", data)
                .build()
        }
    }

    inner class DoConfirmRequest(endpoint:String):BaseApiRequest<String, RegisterData>(endpoint){
        override val pathSegment: String = "users/confirm"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data: String): RequestBody {
            return FormBody.Builder()
                .add("hash", data)
                .build()
        }
    }

    inner class DoGetPlansRequest(endpoint:String):BaseApiRequest<Void?, Plans>(endpoint){
        override val pathSegment: String = "energy/plans"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:Void?): RequestBody {
            return FormBody.Builder()
                .build()
        }
    }

    inner class DoGetEnergyPricesRequest(endpoint:String):BaseApiRequest<String?, EnergyPrices>(endpoint){
        override val pathSegment: String = "energy/prices"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:String?): RequestBody {

            val b = FormBody.Builder()

            data?.let {
                b.add("date", it)
            }

            return b.build()
        }
    }

    inner class DoGetEnergyUsageRequest(endpoint:String):BaseApiRequest<String, Array<EnergyUsage>>(endpoint){
        override val pathSegment: String = "energy/usage"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:String): RequestBody {

            val b = FormBody.Builder()
            b.add("date", data)
            return b.build()
        }
    }

    inner class DoGetEnergyHistoricalUsageRequest(endpoint:String):BaseApiRequest<String, Array<EnergyHistoricalUsage>>(endpoint){
        override val pathSegment: String = "energy/historical"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:String): RequestBody {

            val b = FormBody.Builder()
            b.add("year", data)
            return b.build()
        }
    }

    inner class DoGetUserUsageRequest(endpoint:String):BaseApiRequest<UserUsageRequestData, Array<UserUsage>>(endpoint){
        override val pathSegment: String = "users/energy"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:UserUsageRequestData): RequestBody {

            val b = FormBody.Builder()
            b.add("token", data.token)
            b.add("period", data.period.id)
            data.date?.let {
                b.add("date", it)
            }
            return b.build()
        }
    }

    inner class DoGetUserCompareRequest(endpoint:String):BaseApiRequest<CompareRequestData, CompareData>(endpoint){
        override val pathSegment: String = "users/compare"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:CompareRequestData): RequestBody {

            val b = FormBody.Builder()
            b.add("token", data.token)
            b.add("period", data.period.id)
            return b.build()
        }
    }

    inner class DoGetNotificationsRequest(endpoint:String):BaseApiRequest<NotificationsRequestData, NotificationsData>(endpoint){
        override val pathSegment: String = "users/messages"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:NotificationsRequestData): RequestBody {

            val b = FormBody.Builder()
            b.add("token", data.token)
            return b.build()
        }
    }

    inner class DoMarkNotificationAsReadRequest(endpoint:String):BaseApiRequest<MarkAsReadRequestData, SuccessData>(endpoint){
        override val pathSegment: String = "messages/mark_as_read"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:MarkAsReadRequestData): RequestBody {

            val b = FormBody.Builder()
            b.add("token", data.token)
            b.add("id", data.id.toString())
            return b.build()
        }
    }

    inner class DoDeleteUserRequest(endpoint:String):BaseApiRequest<String, SuccessData>(endpoint){
        override val pathSegment: String = "users/delete"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:String): RequestBody {

            val b = FormBody.Builder()
            b.add("token", data)
            return b.build()
        }
    }

    inner class DoGetUserEnergyGroupRequest(endpoint:String):BaseApiRequest<String, EnergyGroup>(endpoint){
        override val pathSegment: String = "users/energy_group"
        override val requestMethod: String = METHOD_POST

        override fun getRequestBody(data:String): RequestBody {

            val b = FormBody.Builder()
            b.add("token", data)
            return b.build()
        }
    }
}