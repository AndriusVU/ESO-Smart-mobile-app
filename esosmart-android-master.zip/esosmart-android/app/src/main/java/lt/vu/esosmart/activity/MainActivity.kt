package lt.vu.esosmart.activity

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.core.os.bundleOf
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import lt.kryptis.helpers.IntentHelpers
import lt.vu.esosmart.App
import lt.vu.esosmart.BuildConfig
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseActivityFragment
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.UserData
import lt.vu.esosmart.viewmodels.MainViewModel
import javax.inject.Inject

class MainActivity : BaseActivityFragment(), NavigationView.OnNavigationItemSelectedListener {

    companion object{
        val TAG = "MainActivity"
        fun start(context: Context) {
            context.startActivity(Intent(context, MainActivity::class.java))
        }
    }


    @Inject
    lateinit var mPrefs: Prefs;

    lateinit var mainViewModel: MainViewModel
    private lateinit var menu : Menu

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        App.component.inject(this)

        mainViewModel = ViewModelProvider(this).get(MainViewModel::class.java)
        mainViewModel.deleteUserStatus.observe(this, object : BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
                showProgress(false)
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)
                logout()
            }
        })

        initViews()


        intent.extras?.let {
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment)?.findNavController()?.navigate(
                it.getInt("navigate_on_start", R.id.homeFragment)
            )
        }
    }

    private fun initViews(){

        supportActionBar?.show()
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val actionbar: ActionBar? = supportActionBar
        actionbar?.apply {
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowTitleEnabled(false)
        }


        val toggle = ActionBarDrawerToggle(
            this, drawer_layout, toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawer_layout.addDrawerListener(toggle)
        toggle.syncState()



        val tvUserName = nav_view.getHeaderView(0).findViewById<TextView>(R.id.tvUserName)
        val tvEmail = nav_view.getHeaderView(0).findViewById<TextView>(R.id.tvEmail)

        tvUserName.text = mPrefs.userData?.getFullname()?:"anonymous"
        tvEmail.text =  (mPrefs.userData?.email?:"anonymous@anonymous") + " (" + (mPrefs.userData?.role?.joinToString(", ")?:"v0") + ")"

        nav_view.setNavigationItemSelectedListener(this)

        //version
        version_text.text = "v. " + BuildConfig.VERSION_NAME

        //nav menu items

        //nav_view.menu.getItem(R.id.nav_delete).isVisible = false

        mPrefs.userData?.let {
            if(it.isV1() || it.isV2()){

            }else{
                nav_view.menu.findItem(R.id.nav_my_usage).isVisible = false
                nav_view.menu.findItem(R.id.nav_notification).isVisible = false
            }

            nav_view.menu.findItem(R.id.nav_logout).isVisible = false

        }?:run{
            nav_view.menu.findItem(R.id.nav_delete).isVisible = false
            nav_view.menu.findItem(R.id.nav_notification).isVisible = false
            nav_view.menu.findItem(R.id.nav_my_usage).isVisible = false
        }


    }



    override fun onBackPressed() {
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {

        menuInflater.inflate(R.menu.main, menu)

        this.menu = menu
        return false
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.


        when (item.itemId) {
            R.id.nav_my_and_market_price -> {
                nav_host_fragment.findNavController().navigate(R.id.homeFragment)
            }
            R.id.nav_my_plan -> {

                mPrefs.userPlan?.let {

                    nav_host_fragment.findNavController().navigate(
                        R.id.planOverviewFragment,
                        bundleOf("userPlan" to it)
                    )

                }?:run{
                    nav_host_fragment.findNavController().navigate(R.id.myPlanFragment)
                }
            }
            R.id.nav_historical_and_projected_data -> {
                nav_host_fragment.findNavController().navigate(R.id.historicalAndProjectedFragment)
            }
            R.id.nav_my_usage -> {
                nav_host_fragment.findNavController().navigate(R.id.userUsageFragment)
            }
            R.id.nav_logout ->{
                logout()
            }
            R.id.nav_notification -> {
                nav_host_fragment.findNavController().navigate(R.id.notificationsFragment)
            }
            R.id.nav_help -> {
                IntentHelpers.openEmail(getString(R.string.contact_email), this, getString(R.string.contact_subject), getString(R.string.contact_body))
            }
            R.id.nav_delete -> {
                AlertDialog.Builder(this)
                    .setTitle(R.string.general_attention)
                    .setMessage(R.string.home_delete_confirm)
                    .setNegativeButton(R.string.general_cancel){ _, _ -> }
                    .setPositiveButton(R.string.general_yes){ _, _ ->
                        mainViewModel.doDeleteUser()
                    }
                    .create().show()
            }
        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun logout(){
        mPrefs.cleanupUserData()
        SplashActivity.start(this)
        finish()
    }

    private fun showProgress(show:Boolean = true){
//        if(show){
//            progressbar.visibility = View.VISIBLE
//        }else{
//            progressbar.visibility = View.GONE
//        }
    }
}
