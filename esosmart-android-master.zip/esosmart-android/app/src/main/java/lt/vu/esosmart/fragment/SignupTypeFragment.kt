package lt.vu.esosmart.fragment


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController

import kotlinx.android.synthetic.main.fragment_signup_register.*
import kotlinx.android.synthetic.main.fragment_signup_type.*
import lt.vu.esosmart.App
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.activity.MainActivity
import lt.vu.esosmart.core.BaseFragment
import javax.inject.Inject

class SignupTypeFragment:BaseFragment() {

    companion object{
        val TAG = "SignupTypeFragment"
    }

    @Inject
    lateinit var mPrefs: Prefs;

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view : View = inflater.inflate(R.layout.fragment_signup_type, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        App.component.inject(this)

        btnTypeAuto.setOnClickListener {
            findNavController().navigate(
               SignupTypeFragmentDirections.actionSignupTypeFragmentToSignupRegisterFragment()
            )
        }
        btnTypeManual.setOnClickListener {
            mPrefs.isAnon = true
            MainActivity.start(requireContext())
            requireActivity().finish()
        }
    }
}