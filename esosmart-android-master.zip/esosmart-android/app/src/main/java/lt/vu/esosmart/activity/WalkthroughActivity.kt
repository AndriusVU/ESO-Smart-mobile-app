package lt.vu.esosmart.activity

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import lt.vu.esosmart.App
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.adapter.SliderAdapter

class WalkthroughActivity : AppCompatActivity() {

    companion object{
        fun start(context: Context) {
            context.startActivity(Intent(context, WalkthroughActivity::class.java))
        }
    }

    private var mSlideViewPager : ViewPager? = null
    private var mDotsLayout: LinearLayout? = null
    private var mContinueButton: Button? = null

    private var mDots = arrayOfNulls<TextView>(4)
    private var sliderAdapter: SliderAdapter? = null

    private var mCurrentPage: Int = 0
    private var mTotalPages:Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_walkthrough)

        supportActionBar?.hide()

        mSlideViewPager = findViewById(R.id.slide_viewpager)
        mDotsLayout = findViewById(R.id.dots_layout)
        mContinueButton = findViewById(R.id.btnContinue)

        sliderAdapter = SliderAdapter(this)

        mTotalPages = sliderAdapter!!.count

        mSlideViewPager?.adapter = sliderAdapter

        addDotsIndicator(0)

        mSlideViewPager?.addOnPageChangeListener(viewListener)
        mContinueButton?.setOnClickListener{
            App.component.prefs().isFirstRun = false
            SignupActivity.start(this)
            finish()
        }


    }

    override fun onBackPressed() {
        // do something
    }

    fun addDotsIndicator(position: Int) {

        mDots = arrayOfNulls(mTotalPages)
        mDotsLayout?.removeAllViews() //without this multiple number of dots will be created

        for (i in mDots.indices) {
            mDots[i] = TextView(this)
            mDots[i]?.text = Html.fromHtml("&#8226;") //code for the dot icon like thing
            mDots[i]?.textSize = 35f
            mDots[i]?.setPadding(5,0,5,0)
            mDots[i]?.setTextColor(Color.parseColor("#80ffffff"))

            mDotsLayout?.addView(mDots[i])
        }

        if (mDots.isNotEmpty()) {
            mDots[position]?.setTextColor(Color.parseColor("#ffffff")) //setting currently selected dot to white
        }
    }

    internal var viewListener: ViewPager.OnPageChangeListener = object : ViewPager.OnPageChangeListener {
        override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

        }

        override fun onPageSelected(position: Int) {

            addDotsIndicator(position)

            mCurrentPage = position

            Log.d("WalkthroughActivity", "total:" + (mTotalPages-1))

            if (mCurrentPage == mTotalPages-1){
                mContinueButton?.visibility = View.VISIBLE
            }else{
                mContinueButton?.visibility = View.GONE
            }


        }

        override fun onPageScrollStateChanged(state: Int) {

        }
    }
}
