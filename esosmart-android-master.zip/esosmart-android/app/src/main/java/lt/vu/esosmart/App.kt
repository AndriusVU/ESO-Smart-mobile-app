package lt.vu.esosmart

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import lt.vu.esosmart.di.component.ApplicationComponent
import lt.vu.esosmart.di.module.ApplicationModule
import lt.vu.esosmart.di.component.DaggerApplicationComponent

class App:Application() {

    companion object {
        lateinit var component:ApplicationComponent
    }

    override fun onCreate() {
        super.onCreate()
        component = DaggerApplicationComponent.builder().applicationModule(ApplicationModule(this)).build()


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            notificationManager?.createNotificationChannel(
                NotificationChannel(
                    getString(R.string.eso_notification_channel_id),
                    getString(R.string.general_eso_notification_channel),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
        }


        val alarmManager = getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        alarmManager?.let {

            val alarmIntent = Intent(this, NotificationsCheckReceiver::class.java)

            PendingIntent.getService(this, 1, alarmIntent, PendingIntent.FLAG_NO_CREATE)?.let {
                alarmManager.cancel(it)
            }

            val alarmPendingInten = PendingIntent.getBroadcast(this, 1, alarmIntent, 0)

            val interval = AlarmManager.INTERVAL_FIFTEEN_MINUTES

            alarmManager.setInexactRepeating(
                AlarmManager.ELAPSED_REALTIME,
                SystemClock.elapsedRealtime() + interval,
                interval,
                alarmPendingInten
            )

        }

    }
}