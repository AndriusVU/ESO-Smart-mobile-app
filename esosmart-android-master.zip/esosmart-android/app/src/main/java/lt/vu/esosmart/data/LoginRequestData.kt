package lt.vu.esosmart.data

data class LoginRequestData(
    val email:String
) {
}