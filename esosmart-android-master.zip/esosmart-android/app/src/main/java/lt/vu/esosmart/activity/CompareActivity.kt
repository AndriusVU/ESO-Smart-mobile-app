package lt.vu.esosmart.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import kotlinx.android.synthetic.main.activity_compare.*
import lt.kryptis.helpers.TextHelpers
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Utilities
import lt.vu.esosmart.core.*
import lt.vu.esosmart.data.CompareData
import lt.vu.esosmart.fragment.userUsage.UserUsagetPeriod
import lt.vu.esosmart.viewmodels.CompareViewModel

class CompareActivity : BaseActivityFragment() {

    companion object{
        val TAG = "CompareActivity"
        fun start(context: Context, period:UserUsagetPeriod) {

            val i = Intent(context, CompareActivity::class.java)
            i.putExtra("period", period)
            context.startActivity(i)
        }
    }

    lateinit var period:UserUsagetPeriod

    lateinit var compareViewModel: CompareViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_compare)

        if(intent.hasExtra("period")){
            period = intent.getSerializableExtra("period") as UserUsagetPeriod
        }else{
            period = UserUsagetPeriod.LAST_DAY
        }

        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        toolbar.title = when(period){
            UserUsagetPeriod.LAST_DAY -> getString(R.string.compare_last_day)
            UserUsagetPeriod.LAST_WEEK -> getString(R.string.compare_last_week)
            UserUsagetPeriod.LAST_MONTH -> getString(R.string.compare_last_month)
            else -> getString(R.string.my_usage_consumed_day)
        }

        compareViewModel = ViewModelProvider(this).get(CompareViewModel::class.java)

        compareViewModel.status.observe(this, object: BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
                showProgress(false)
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)


                compareViewModel.compareData?.let {
                    initChart(it)
                }

            }
        })

        compareViewModel.compareData?.let {
            initChart(it)
            showProgress(false)
        }?:run{
            showProgress(true)
            compareViewModel.doGetCompareData(period)
        }



    }

    fun initChart(compareData:CompareData){

        val my_totalEntries = arrayListOf<BarEntry>()
        my_totalEntries.add(BarEntry(1f, compareData.my_total))

        val my_averageEntries = arrayListOf<BarEntry>()
        my_averageEntries.add(BarEntry(2f, compareData.my_average))

        val others_averageEntries = arrayListOf<BarEntry>()
        others_averageEntries.add(BarEntry(3f, compareData.others_average))



        val my_totalDataset = BarDataSet(my_totalEntries, getString(R.string.compare_my_total))
        my_totalDataset.setColors(getColor(R.color.colorChart1))
        val my_averageDataset = BarDataSet(my_averageEntries, getString(R.string.compare_my_average))
        my_averageDataset.setColors(getColor(R.color.colorChart2))

        val others_averageDataset = BarDataSet(others_averageEntries, getString(R.string.compare_others_average))
        others_averageDataset.setColors(getColor(R.color.colorChart4))



        val barData = BarData(my_totalDataset, my_averageDataset, others_averageDataset)
        barData.isHighlightEnabled = true
        barData.setValueFormatter(object: ValueFormatter(){
            override fun getFormattedValue(value: Float): String {
                return getString(R.string.general_float_format, value)
            }
        })


        val chart = barChart
        chart.description.isEnabled = false

        chart.xAxis.isEnabled = false
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.setDrawGridLines(false)
        chart.xAxis.valueFormatter = object : ValueFormatter(){
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return "-"
            }
        }

        chart.axisLeft.axisMinimum = 0f
        chart.axisLeft.valueFormatter = object : ValueFormatter(){
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return "%.0f".format(Math.abs(value))
            }
        }

        chart.axisRight.isEnabled = false

        chart.legend.isWordWrapEnabled = true
        chart.legend.form = Legend.LegendForm.LINE

        chart.isScaleXEnabled = true
        chart.setPinchZoom(true)
        chart.isDragEnabled = true
        chart.setTouchEnabled(true)

        chart.data = barData
        chart.invalidate()

        chart.setOnChartValueSelectedListener(object:OnChartValueSelectedListener{
            override fun onValueSelected(e: Entry?, h: Highlight?) {
                when(e?.x){
                    1.0f -> {
                        Utilities.showAlertDialog(
                            this@CompareActivity,
                            "",
                            getString(
                                R.string.compare_last_footnote,
                                getLastOfPeriod()
                            ),
                            "Gerai",
                            "", null, null, true)
                    }
                    2.0f -> {
                        Utilities.showAlertDialog(
                            this@CompareActivity,
                            "",
                            getString(
                                R.string.compare_avg_footnote,
                                getPeriodDuration(),
                                getOfPeriod()
                            ),
                            "Gerai",
                            "", null, null, true)
                    }
                    3.0f -> {

                        compareData.energy_group?.let { energyGroup ->
                            if(energyGroup.interval_to > 10000){
                                Utilities.showAlertDialog(
                                    this@CompareActivity,
                                    "",
                                    getString(
                                        R.string.compare_other_avg_footnote,
                                        "nuo " + energyGroup.interval_from,
                                        getPeriodDuration(),
                                        getOfPeriod()
                                    ),
                                    "Gerai",
                                    "", null, null, true)
                            }else{
                                Utilities.showAlertDialog(
                                    this@CompareActivity,
                                    "",
                                    getString(
                                        R.string.compare_other_avg_footnote,
                                        "nuo " + energyGroup.interval_from + " iki " + energyGroup.interval_to,
                                        getPeriodDuration(),
                                        getOfPeriod()
                                    ),
                                    "Gerai",
                                    "", null, null, true)
                            }
                        }





                    }
                }
            }

            override fun onNothingSelected() {
            }
        })

        //infografikas

        val avg = compareData.my_average
        val total = compareData.my_total
        val other = compareData.others_average

        val avgComp = total / avg - 1
        val othersComp = total / other - 1

        //tv_left_title.text = "%.0f%%".format(avgComp * 100)
        tv_left_desc.text = TextHelpers.htmlToCharSequence( getString(
            getPeriodAvgStringId(),
            getPeriodName(),
            avgComp*100,
            getMoreOrLessName(avgComp)
        ))

        tv_right_desc.text = TextHelpers.htmlToCharSequence( getString(
            getPeriodOtherStringId(),
            getPeriodName(),
            othersComp*100,
            getMoreOrLessName(othersComp)
        ))

    }

    private fun getPeriodAvgStringId():Int{
        return when(period){
            UserUsagetPeriod.LAST_MONTH -> R.string.compare_avg_text_v2
            else -> R.string.compare_avg_text_v1
        }
    }
    private fun getPeriodOtherStringId():Int{
        return when(period){
            UserUsagetPeriod.LAST_MONTH -> R.string.compare_other_text_v2
            else -> R.string.compare_other_text_v1
        }
    }
    private fun getPeriodName():String{
        return when(period){
            UserUsagetPeriod.LAST_DAY -> getString(R.string.compare_period_day)
            UserUsagetPeriod.LAST_WEEK -> getString(R.string.compare_period_week)
            else -> getString(R.string.compare_period_month)
        }
    }
    private fun getPeriodDuration():String{
        return when(period){
            UserUsagetPeriod.LAST_DAY -> getString(R.string.compare_avg_last_7_days)
            UserUsagetPeriod.LAST_WEEK -> getString(R.string.compare_avg_last_4_week)
            else -> getString(R.string.compare_avg_last_12_month)
        }
    }
    private fun getOfPeriod():String{
        return when(period){
            UserUsagetPeriod.LAST_DAY -> getString(R.string.compare_footnote_of_day)
            UserUsagetPeriod.LAST_WEEK -> getString(R.string.compare_footnote_of_week)
            else -> getString(R.string.compare_footnote_of_month)
        }
    }

    private fun getLastOfPeriod():String{

        return when(period){
            UserUsagetPeriod.LAST_DAY -> getString(R.string.compare_sum_last_day)
            UserUsagetPeriod.LAST_WEEK -> getString(R.string.compare_sum_last_week)
            else -> getString(R.string.compare_sum_last_month)
        }
    }

    private fun getMoreOrLessName(v: Float):String{
        if(v > 0) return getString(R.string.compare_more)
        else if(v < 0) return getString(R.string.compare_less)
        return getString(R.string.compare_eq)
    }

    /**
     * Shows the progress UI and hides the register form.
     */
    fun showProgress(show: Boolean = true) {
        registerProgressbar.visibility = if (show) View.VISIBLE else View.GONE

        tv_chartScale.visibility = if (show) View.INVISIBLE else View.VISIBLE
        cl_infoWrap.visibility = if (show) View.INVISIBLE else View.VISIBLE
        barChart.visibility = if (show) View.INVISIBLE else View.VISIBLE

    }
}
