package lt.vu.esosmart.data

data class UserUsage(
    val time:String,
    val consumed:Float,
    val supplied:Float
) {
}