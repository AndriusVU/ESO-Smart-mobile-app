package lt.vu.esosmart.viewmodels

import androidx.lifecycle.MutableLiveData
import lt.vu.esosmart.App
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.core.SingleLiveEvent
import lt.vu.esosmart.data.UserUsage
import lt.vu.esosmart.data.UserUsageRequestData
import lt.vu.esosmart.fragment.userUsage.UserUsagetPeriod
import java.lang.ref.WeakReference
import javax.inject.Inject

class UserUsageViewModel:BaseViewModel() {

    companion object{
        val TAG = "MyUsageViewModel"
    }

    @Inject
    lateinit var mPrefs: Prefs

    init {
        App.component.inject(this)
    }

    var status:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()
    var energyGroupstatus:SingleLiveEvent<BaseApi.ApiResponse> = SingleLiveEvent()

    private var mTask:RequestTask? = null

    var userUsage:Array<UserUsage>? = null

    fun doGetUserUsages(period:UserUsagetPeriod, date:String? = null){
        mTask = RequestTask(status){
            val resp = mBackendService.doGetUserUsage(UserUsageRequestData(mPrefs.userToken?:"", period, date))
            if(resp is BaseApi.ApiSuccessResponse){
                userUsage = resp.data as Array<UserUsage>
            }
            resp
        }
        mTask?.execute()
    }

    fun hasPrices():Boolean{
        return userUsage != null
    }

    fun cancel(){
        mTask?.cancel(true)
        mTask = null
    }

    fun isInProgress():Boolean{
        return mTask!=null
    }
}