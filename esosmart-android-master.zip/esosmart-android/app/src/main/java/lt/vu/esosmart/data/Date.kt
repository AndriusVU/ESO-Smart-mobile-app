package lt.vu.esosmart.data

import android.os.Parcelable
import android.util.Log
import kotlinx.android.parcel.IgnoredOnParcel
import kotlinx.android.parcel.Parcelize
import java.text.SimpleDateFormat
import java.util.*

@Parcelize
data class Date(
    val date:String
): Parcelable {

    companion object{
        val mDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale("lt-LT"))
    }

    fun getDateOnly():String{
        val dateParts = date.split(" ")
        return dateParts.get(0)
    }

    @IgnoredOnParcel
    var _timestamp:Long? = null;
    fun getTimestamp():Long{
        if(_timestamp == null){
            _timestamp = mDateFormat.parse(date)?.time?:0L
        }
        return _timestamp!!
    }
}