package lt.vu.esosmart.fragment


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.app_bar_main.view.*
import kotlinx.android.synthetic.main.fragment_myplan.*
import lt.vu.esosmart.R

class MyPlanFragment: Fragment(){

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_myplan, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btnChoosePlan.setOnClickListener {
            it.findNavController().navigate(
                MyPlanFragmentDirections.actionMyPlanFragmentToSelectPlanFragment()
            )
        }
        btnChoosePrice.setOnClickListener {
            it.findNavController().navigate(
                MyPlanFragmentDirections.actionMyPlanFragmentToEnterPriceFragment()
            )
        }
    }



    override fun onStart() {
        super.onStart()
        requireActivity().nav_view.setCheckedItem(R.id.nav_my_plan)
        requireActivity().toolbar.tollbarTitle.text = getString(R.string.menu_my_plan)
    }
}