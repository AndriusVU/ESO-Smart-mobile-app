package lt.vu.esosmart.fragment.userUsage

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter
import kotlinx.android.synthetic.main.fragment_user_usage_chart.*
import lt.kryptis.helpers.DateHelper
import lt.vu.esosmart.App
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.Utillies.Utilities
import lt.vu.esosmart.activity.CompareActivity
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.UserUsage
import lt.vu.esosmart.viewmodels.UserUsageViewModel
import java.util.*
import javax.inject.Inject


enum class UserUsagetPeriod(val id:String){
    LAST_DAY("day"),
    LAST_WEEK("week"),
    LAST_MONTH("month"),
}

class UserUsageChartFragment():BaseFragment() {
    companion object{
        val TAG = "UserUsageChartFragment"
    }
    var period:UserUsagetPeriod = UserUsagetPeriod.LAST_DAY
    lateinit var userUsageViewModel: UserUsageViewModel

    @Inject
    lateinit var mPrefs: Prefs

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        if(requireArguments().containsKey("period")){
            period = requireArguments().getSerializable("period") as UserUsagetPeriod
        }

        val view : View = inflater.inflate(R.layout.fragment_user_usage_chart, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        App.component.inject(this)

        userUsageViewModel = ViewModelProvider(this).get(UserUsageViewModel::class.java)
        userUsageViewModel.status.observe(viewLifecycleOwner, object: BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
                showProgress(false)
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)

                initChart(
                    response.data as Array<UserUsage>
                )

            }
        })

        val histYear = DateHelper.formatDate(Date(), "yyyy").toInt()-1
        val histMonth = DateHelper.formatDate(Date(), "MM").toInt()


        userUsageViewModel.userUsage?.let {
            initChart(it)
        }?:run{
            userUsageViewModel.doGetUserUsages(period)
        }

        val today = Calendar.getInstance()
        today.add(Calendar.DATE, -1)

        when(period){
            UserUsagetPeriod.LAST_DAY -> {
                tv_title.setText(
                    "%s %d d.".format(
                        getString(
                            resources.getIdentifier(
                                "general_genitive_month_" + (today.get(Calendar.MONTH)+1),
                                "string",
                                requireActivity().packageName
                            )
                        ),
                        today.get(Calendar.DAY_OF_MONTH)
                    )
                )
                tv_desc.setText(R.string.my_usage_desc)
            }
            UserUsagetPeriod.LAST_WEEK -> {
                val weekBefore = Calendar.getInstance()
                weekBefore.add(Calendar.DATE, -7)
                tv_title.setText(
                    "%s %d d. - %s %d d.".format(
                        getString(
                            resources.getIdentifier(
                                "general_genitive_month_" + (weekBefore.get(Calendar.MONTH)+1),
                                "string",
                                requireActivity().packageName
                            )
                        ),
                        weekBefore.get(Calendar.DAY_OF_MONTH),
                        getString(
                            resources.getIdentifier(
                                "general_genitive_month_" + (today.get(Calendar.MONTH)+1),
                                "string",
                                requireActivity().packageName
                            )
                        ),
                        today.get(Calendar.DAY_OF_MONTH)
                    )
                )
                tv_desc.setText(R.string.my_usage_hourly_desc)
            }
            UserUsagetPeriod.LAST_MONTH -> {
                val monthBefore = Calendar.getInstance()
                monthBefore.add(Calendar.DATE, -30)
                tv_title.setText(
                    "%s %d d. - %s %d d.".format(
                        getString(
                            resources.getIdentifier(
                                "general_genitive_month_" + (monthBefore.get(Calendar.MONTH)+1),
                                "string",
                                requireActivity().packageName
                            )
                        ),
                        monthBefore.get(Calendar.DAY_OF_MONTH),
                        getString(
                            resources.getIdentifier(
                                "general_genitive_month_" + (today.get(Calendar.MONTH)+1),
                                "string",
                                requireActivity().packageName
                            )
                        ),
                        today.get(Calendar.DAY_OF_MONTH)
                    )
                )
                tv_desc.setText(R.string.my_usage_hourly_desc)
            }
        }





        btnCompare.visibility = View.GONE
        mPrefs.userData?.let {
            if(it.isV2()){
                btnCompare.visibility = View.VISIBLE
                btnCompare.setOnClickListener {
                    CompareActivity.start(requireContext(), period)
                }
            }
        }



    }

    private fun initChart(energyUsages: Array<UserUsage>){

        val usageEntries = arrayListOf<BarEntry>()
        //val suppliedEntries = arrayListOf<Entry>()


        energyUsages.forEach{

            val timeParts = it.time.split(":")
            val h = timeParts[0].toInt()

            val isDay = Utilities.dayHours.contains(h)





            if(mPrefs.userPlan?.zone?.isFourZone()?:false){
                val dayUsage:Float
                val nightUsage:Float
                val morningUsage:Float
                val eveningUsage:Float

                if(Utilities.morningHours.contains(h)){
                    morningUsage = it.consumed
                    dayUsage = 0f
                    eveningUsage = 0f
                    nightUsage = 0f
                }else if(Utilities.workHours.contains(h)){
                    morningUsage = 0f
                    dayUsage = it.consumed
                    eveningUsage = 0f
                    nightUsage = 0f
                }else if(Utilities.eveningHours.contains(h)){
                    morningUsage = 0f
                    dayUsage = 0f
                    eveningUsage = it.consumed
                    nightUsage = 0f
                }else{
                    morningUsage = 0f
                    dayUsage = 0f
                    eveningUsage = 0f
                    nightUsage = it.consumed
                }

                usageEntries.add(
                    BarEntry(
                        h.toFloat(), floatArrayOf(morningUsage, dayUsage, eveningUsage, nightUsage, -it.supplied)
                    )
                )

            }else if(mPrefs.userPlan?.zone?.isSingleZone()?:false){
                usageEntries.add(
                    BarEntry(
                        h.toFloat(), floatArrayOf(it.consumed, -it.supplied)
                    )
                )
            }else{
                val dayUsage:Float
                val nightUsage:Float

                if(Utilities.dayHours.contains(h)){
                    dayUsage = it.consumed
                    nightUsage = 0f
                }else{
                    dayUsage = 0f
                    nightUsage = it.consumed
                }

                usageEntries.add(
                    BarEntry(
                        h.toFloat(), floatArrayOf(dayUsage, nightUsage, -it.supplied)
                    )
                )
            }
        }

        val usageDataset = BarDataSet(usageEntries, "")
        usageDataset.setDrawValues(false)



        if(mPrefs.userPlan?.zone?.isFourZone()?:false){
            usageDataset.setColors(
                intArrayOf(
                    R.color.colorChart1, R.color.colorChart2, R.color.colorChart3, R.color.colorChart5, R.color.colorChart4
                ), requireContext())

            usageDataset.stackLabels = arrayOf(
                getString(R.string.my_usage_consumed_morning),
                getString(R.string.my_usage_consumed_day),
                getString(R.string.my_usage_consumed_evening),
                getString(R.string.my_usage_consumed_night),
                getString(R.string.my_usage_supplied)
            )
        }else if(mPrefs.userPlan?.zone?.isSingleZone()?:false){
            usageDataset.setColors(
                intArrayOf(
                    R.color.colorChart1, R.color.colorChart4
                ), requireContext())

            usageDataset.stackLabels = arrayOf(
                getString(R.string.my_usage_consumed),
                getString(R.string.my_usage_supplied)
            )
        }else{
            usageDataset.setColors(
                intArrayOf(
                    R.color.colorChart1, R.color.colorChart2, R.color.colorChart4
                ), requireContext())

            usageDataset.stackLabels = arrayOf(
                getString(R.string.my_usage_consumed_day),
                getString(R.string.my_usage_consumed_night),
                getString(R.string.my_usage_supplied)
            )
        }



        val barData = BarData(usageDataset)
        barData.isHighlightEnabled = false


        val chart = barChart
        chart.description.isEnabled = false

        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.setDrawGridLines(false)
        //chart.xAxis.granularity = 1f

        chart.xAxis.valueFormatter = object : ValueFormatter(){
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return "%2.0f:00".format(value)
            }
        }

        chart.axisLeft.valueFormatter = object :ValueFormatter(){
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return "%.02f".format(Math.abs(value))
            }
        }

        chart.axisRight.isEnabled = false

        chart.legend.setWordWrapEnabled(true)
        chart.legend.verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
        chart.legend.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER

        chart.legend.form = Legend.LegendForm.LINE

        chart.isScaleXEnabled = true
        chart.setPinchZoom(true)
        chart.isDragEnabled = true
        chart.setTouchEnabled(true)

        chart.data = barData
        chart.invalidate()
    }

    /**
     * Shows the progress UI and hides the register form.
     */
    fun showProgress(show: Boolean = true) {
        registerProgressbar.visibility = if (show) View.VISIBLE else View.GONE
    }
}