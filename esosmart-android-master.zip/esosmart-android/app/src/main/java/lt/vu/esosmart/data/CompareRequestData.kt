package lt.vu.esosmart.data

import lt.vu.esosmart.fragment.userUsage.UserUsagetPeriod

data class CompareRequestData(
    val token:String,
    val period:UserUsagetPeriod
) {
}