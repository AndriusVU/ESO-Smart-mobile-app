package lt.vu.esosmart.fragment.historicalAndProjected

import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import kotlinx.android.synthetic.main.fragment_historical.tv_top_desc
import kotlinx.android.synthetic.main.fragment_projected.lineChart
import kotlinx.android.synthetic.main.fragment_projected.registerProgressbar
import lt.kryptis.helpers.DateHelper
import lt.kryptis.helpers.TextHelpers
import lt.vu.esosmart.R
import lt.vu.esosmart.core.BaseApi
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.core.BaseViewModel
import lt.vu.esosmart.data.EnergyHistoricalUsage
import lt.vu.esosmart.viewmodels.HistoricalViewModel
import java.util.*

class HistoricalFragment:BaseFragment() {

    lateinit var historicalViewModel: HistoricalViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_historical, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        historicalViewModel = ViewModelProvider(this).get(HistoricalViewModel::class.java)
        historicalViewModel.status.observe(viewLifecycleOwner, object: BaseViewModel.StatusObserver{
            override fun onError(response: BaseApi.ApiErrorResponse) {
                showError(response.error)
                showProgress(false)
            }

            override fun onProgress(response: BaseApi.ApiProgressResponse) {
                showProgress(true)
            }

            override fun onSuccess(response: BaseApi.ApiSuccessResponse) {
                showProgress(false)

                initChart(
                    response.data as Array<EnergyHistoricalUsage>
                )

            }
        })

        val histYear = DateHelper.formatDate(Date(), "yyyy").toInt()-1
        val histMonth = DateHelper.formatDate(Date(), "MM").toInt()


        historicalViewModel.historicalEnergyUsages?.let {
            initChart(it)
        }?:run{
            historicalViewModel.doGetEnergyHistoricalUsages(
                histYear.toString()
            )
        }

        Log.d("HistoricalFragment", getString(R.string.historical_top_desc, histYear, histMonth))

        tv_top_desc.setText(
            TextHelpers.htmlToSpanned(
                getString(R.string.historical_top_desc, histYear, histMonth)
            )
        )
        tv_top_desc.movementMethod = LinkMovementMethod.getInstance()
    }

    private fun initChart(energyUsages: Array<EnergyHistoricalUsage>){

        val usageEntries = arrayListOf<Entry>()
        val productionEntries = arrayListOf<Entry>()
        val production_windEntries = arrayListOf<Entry>()


        energyUsages.forEach{

            val timeParts = it.hour.split(":")
            val h = timeParts[0].toFloat()

            usageEntries.add(Entry(h, it.energy_usage))
            productionEntries.add(Entry(h, it.production))
            production_windEntries.add(Entry(h, it.production_wind))
        }
 
        val usageDataset = LineDataSet(usageEntries, getString(R.string.projected_forecast_usage))
        usageDataset.setColor(requireContext().getColor(R.color.colorChart1))
        usageDataset.setDrawCircles(false)
        usageDataset.setDrawValues(false)
        usageDataset.lineWidth = 2f

        val productionDataset = LineDataSet(productionEntries, getString(R.string.projected_planned_production))
        productionDataset.setColor(requireContext().getColor(R.color.colorChart2))
        productionDataset.setDrawCircles(false)
        productionDataset.setDrawValues(false)
        productionDataset.lineWidth = 2f

        val production_windDataset = LineDataSet(production_windEntries, getString(R.string.projected_planned_production_wind))
        production_windDataset.setColor(requireContext().getColor(R.color.colorChart3))
        production_windDataset.setDrawCircles(false)
        production_windDataset.setDrawValues(false)
        production_windDataset.lineWidth = 2f


        val lineData = LineData(usageDataset, productionDataset, production_windDataset)
        lineData.isHighlightEnabled = false


        val chart = lineChart
        chart.description.isEnabled = false

        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.xAxis.setDrawGridLines(false)
        chart.xAxis.granularity = 1f

        chart.xAxis.valueFormatter = object : ValueFormatter(){
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return "%02.0f:00".format(value)
            }
        }

        chart.axisLeft.axisMinimum = 0f
        chart.axisRight.isEnabled = false

        chart.legend.form = Legend.LegendForm.LINE
        chart.legend.setWordWrapEnabled(true)
        chart.legend.verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
        chart.legend.horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT

        chart.isScaleXEnabled = true
        chart.setPinchZoom(true)
        chart.isDragEnabled = true
        chart.setTouchEnabled(true)

        chart.data = lineData
        chart.invalidate()
    }

    /**
     * Shows the progress UI and hides the register form.
     */
    fun showProgress(show: Boolean = true) {
        registerProgressbar.visibility = if (show) View.VISIBLE else View.GONE
    }
}