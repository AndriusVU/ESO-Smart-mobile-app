package lt.vu.esosmart.core;

import android.os.AsyncTask
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import lt.vu.esosmart.App
import lt.vu.esosmart.data.RegisterData
import lt.vu.esosmart.service.BackendService
import java.lang.ref.WeakReference
import javax.inject.Inject


open class BaseViewModel : ViewModel(){
    @Inject
    lateinit var mBackendService: BackendService
    @Inject
    lateinit var gson: Gson

    init {
        App.component.inject(this)
    }


    interface StatusObserver:Observer<BaseApi.ApiResponse>{
        override fun onChanged(t: BaseApi.ApiResponse?) {
            when(t){
                is BaseApi.ApiSuccessResponse -> onSuccess(t)
                is BaseApi.ApiErrorResponse -> onError(t)
                is BaseApi.ApiProgressResponse -> onProgress(t)
                else -> onElse(t)
            }
        }

        fun onSuccess(response:BaseApi.ApiSuccessResponse){}
        fun onError(response: BaseApi.ApiErrorResponse)
        fun onProgress(response: BaseApi.ApiProgressResponse)
        fun onElse(response: BaseApi.ApiResponse?){}
    }

    open protected class BaseTask<T>(status:MutableLiveData<*>? = null):AsyncTask<T, BaseApi.ApiResponse, BaseApi.ApiResponse>(){

        val status = WeakReference(status)

        open protected fun publishProgress(progress:Int){
            publishProgress(BaseApi.ApiProgressResponse(progress))
        }

        override fun doInBackground(vararg params: T?): BaseApi.ApiResponse {
            publishProgress(0)
            return doRequest(params.getOrNull(0))?:BaseApi.SUCCESS_RETURN
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            status.get()?.value = result
        }
        override fun onProgressUpdate(vararg values: BaseApi.ApiResponse?) {
            super.onProgressUpdate(*values)
            values.get(0)?.let {
                status.get()?.value = it
            }
        }
        override fun onCancelled() {
            super.onCancelled()
            status.get()?.value = BaseApi.CANCEL_RETURN
        }

        open fun doRequest(param:T?):BaseApi.ApiResponse?{
            return null
        }
    }
    open protected class RequestTask(status:MutableLiveData<*>? = null, val callback: ()->BaseApi.ApiResponse?):AsyncTask<Void, BaseApi.ApiResponse, BaseApi.ApiResponse>(){

        val status = WeakReference(status)

        open protected fun publishProgress(progress:Int){
            publishProgress(BaseApi.ApiProgressResponse(progress))
        }

        override fun doInBackground(vararg params: Void?): BaseApi.ApiResponse {
            publishProgress(0)
            return callback.invoke()?:BaseApi.SUCCESS_RETURN
        }

        override fun onPostExecute(result: BaseApi.ApiResponse) {
            super.onPostExecute(result)
            status.get()?.value = result
        }
        override fun onProgressUpdate(vararg values: BaseApi.ApiResponse?) {
            super.onProgressUpdate(*values)
            values.get(0)?.let {
                status.get()?.value = it
            }
        }
        override fun onCancelled() {
            super.onCancelled()
            status.get()?.value = BaseApi.CANCEL_RETURN
        }
    }
}