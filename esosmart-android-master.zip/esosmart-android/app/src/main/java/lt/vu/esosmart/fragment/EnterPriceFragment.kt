package lt.vu.esosmart.fragment


import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.app_bar_main.view.*
import kotlinx.android.synthetic.main.fragment_enter_price.*
import lt.vu.esosmart.App
import lt.vu.esosmart.R
import lt.vu.esosmart.Utillies.Prefs
import lt.vu.esosmart.core.BaseFragment
import lt.vu.esosmart.data.*
import javax.inject.Inject

class EnterPriceFragment: Fragment(){

    companion object{
        val TAG = "EnterPriceFragment"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_enter_price, container, false)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        btnContinue.setOnClickListener {

            var valid = true

            var price = getPriceFromInput(etPriceDed)
            if(price < 0f){
                etPriceDed.setError(getString(R.string.price_choose_wrond_value))
                valid = false
            }else{
                etPriceDed.setError(null)
            }
            etPriceDed.setText(getString(R.string.general_float_format, price))

            price = getPriceFromInput(etPriceDay)
            if(price < 0.01f || price > 200f){
                etPriceDay.setError(getString(R.string.price_choose_wrond_value))
                valid = false
            }else{
                etPriceDay.setError(null)
            }

            etPriceDay.setText(getString(R.string.general_float_format, price))

            price = getPriceFromInput(etPriceNight)
            if(price < 0.01f || price > 200f){
                etPriceNight.setError(getString(R.string.price_choose_wrond_value))
                valid = false
            }else{
                etPriceNight.setError(null)
            }

            etPriceNight.setText(getString(R.string.general_float_format, price))

            if(valid){
                setPriceAndFinish()
            }
        }
    }

    private fun getPriceFromInput(input:EditText):Float{
        try{

            var inputText = input.text.toString()
            inputText = inputText.replace(",", ".")
            return inputText.toFloat()
        }catch (e:Exception){
            return 0f
        }
    }


    private fun setPriceAndFinish(){

        val prices = mutableListOf<ZonePrice>()

        prices.add(ZonePrice(PriceType.DED.id, getString(R.string.price_name_ded), getPriceFromInput(etPriceDed)))

        var zoneName:String;
        if(etPriceDay.text.toString() == etPriceNight.text.toString()){
            prices.add(ZonePrice(PriceType.ALL.id, getString(R.string.price_name_all), getPriceFromInput(etPriceDay)))
            zoneName = getString(R.string.price_zone_1_name)
        }else{
            prices.add(ZonePrice(PriceType.DAY.id, getString(R.string.price_name_day), getPriceFromInput(etPriceDay)))
            prices.add(ZonePrice(PriceType.NIGHT.id, getString(R.string.price_name_night), getPriceFromInput(etPriceNight)))
            zoneName = getString(R.string.price_zone_2_name)
        }


        val zone = PlanZone(
            0,
            zoneName,
            prices
        )
        val plan = Plan(
            0,
            getString(R.string.price_choose_plan_name),
            "", null, null, null, listOf(zone)
        )

        requireView().findNavController().navigate(
            EnterPriceFragmentDirections.actionEnterPriceFragmentToPlanOverviewFragment(
                UserPlan(plan, zone)
            )
        )

    }


    override fun onStart() {
        super.onStart()
        requireActivity().nav_view.setCheckedItem(R.id.nav_my_plan)
        requireActivity().toolbar.tollbarTitle.text= getString(R.string.home_enter_price)
    }

}