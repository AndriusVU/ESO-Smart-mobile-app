package lt.vu.esosmart.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.app_bar_main.view.*
import kotlinx.android.synthetic.main.fragment_historical_and_projected.*
import lt.vu.esosmart.R
import lt.vu.esosmart.adapter.HistoricalAndProjectedPagerAdapter
import lt.vu.esosmart.core.BaseFragment

class HistoricalAndProjectedFragment:BaseFragment() {

    lateinit var mHistoricalAndProjectedPagerAdapter:HistoricalAndProjectedPagerAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view : View = inflater.inflate(R.layout.fragment_historical_and_projected, container, false)
        return view
    }

    override fun onStart() {
        super.onStart()
        requireActivity().nav_view.setCheckedItem(R.id.nav_historical_and_projected_data)
        requireActivity().toolbar.tollbarTitle.text= getString(R.string.menu_historical_projected_data)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        mHistoricalAndProjectedPagerAdapter = HistoricalAndProjectedPagerAdapter(this)
        pager.adapter = mHistoricalAndProjectedPagerAdapter

        TabLayoutMediator(tabLayout, pager){ tab, position ->
            tab.text = when(position){
                0 -> getString(R.string.projected_tab)
                1 -> getString(R.string.historical_tab)
                else -> "???"
            }
        }.attach()
    }
}