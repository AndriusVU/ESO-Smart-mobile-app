package lt.kryptis.helpers

import android.os.Build
import android.text.Html
import android.text.Spanned

/**
 * Created by evaldas.inciura on 2018-04-24.
 */
class TextHelpers {
    companion object {
        fun urlBase(url:String):String{
            return url.replace("https*://".toRegex(), "");
        }
        @SuppressWarnings("deprecation")
        fun htmlToSpanned(html:String):Spanned{
            val source = html.replace("\\r\\n", "")

            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
                return Html.fromHtml(source, Html.FROM_HTML_MODE_LEGACY)
            }else{
                return Html.fromHtml(source)
            }
        }

        fun htmlToCharSequence(html:String):CharSequence{
            return trimTrailingWhitespace(htmlToSpanned(html))
        }

        fun trimTrailingWhitespace(source: CharSequence?): CharSequence {

            if (source == null)
                return ""

            var i = source.length

            // loop back to the first non-whitespace character
            while (--i >= 0 && Character.isWhitespace(source[i])) {
            }

            return source.subSequence(0, i + 1)
        }
    }
}