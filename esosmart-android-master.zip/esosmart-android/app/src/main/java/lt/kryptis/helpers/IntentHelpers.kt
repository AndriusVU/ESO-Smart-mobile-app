package lt.kryptis.helpers

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.app.ShareCompat
import lt.vu.esosmart.R
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Created by evaldas.inciura on 26/01/2018.
 */
class IntentHelpers {

    companion object {

        fun getPhoneNumberIntent(number: String) = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number))

        fun openPhoneNumber(number: String, context: Context){
            context.startActivity(getPhoneNumberIntent(number))
        }

        fun getEmailIntent(email: String, subject:String? = null, body:String? = null):Intent{

            val intent = Intent(Intent.ACTION_SENDTO)
            intent.setData(Uri.parse("mailto:" + email))
            intent.putExtra(Intent.EXTRA_SUBJECT, subject)
            intent.putExtra(Intent.EXTRA_TEXT, body)
            return intent
        }

        fun openEmail(email: String, context: Context, subject:String? = null, body:String? = null){
            val intent = getEmailIntent(email, subject, body)
            if(intent.resolveActivity(context.packageManager) != null){
                context.startActivity(intent)
            }else{
                Toast.makeText(context, context.getString(R.string.contact_error), Toast.LENGTH_LONG).show()
            }

        }

        fun getAddressIntent(address:String) = Intent(Intent.ACTION_VIEW, Uri.parse(String.format("geo:0,0?q=%s", URLEncoder.encode(address, StandardCharsets.UTF_8.toString()))))
        fun openAddress(address: String, context: Context){
            context.startActivity(getAddressIntent(address))
        }

        fun getCoordinatesIntent(lat: String, lng:String) = Intent(Intent.ACTION_VIEW, Uri.parse(String.format("geo:%s,%s", lat, lng)))
        fun openCoordinates(lat: String, lng:String, context: Context){
            context.startActivity(getCoordinatesIntent(lat, lng))
        }

        fun getPdfIntent(url:String):Intent{
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
            return intent
        }
        fun openPdf(pdfUrl:String, context: Context){
            context.startActivity(getPdfIntent(pdfUrl))
        }


        fun getShareUrlIntent(url:String, title:String? = null):Intent{
            val intent = Intent(android.content.Intent.ACTION_SEND)
            intent.setType("text/plain")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT)
            title?.let{
                intent.putExtra(Intent.EXTRA_SUBJECT, title);
            }

            intent.putExtra(Intent.EXTRA_TEXT, url);
            return intent
        }
        fun openShareUrl(url:String, context: Context, title:String? = null){
            context.startActivity(getShareUrlIntent(url, title))
        }


        fun getUrlIntent(url:String):Intent{
            return Intent(Intent.ACTION_VIEW, Uri.parse(
                    if(url.startsWith("http"))
                        url
                    else
                        "http://" + url
            ))
        }

        fun openUrl(url:String, context: Context){
            context.startActivity(getUrlIntent(url))
        }
    }

}