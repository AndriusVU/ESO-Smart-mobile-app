package lt.kryptis.helpers

import android.content.Context
import android.net.ConnectivityManager

object NetworkHelper {
    fun isNetworkAvailable(context:Context):Boolean{
        return true
//        val cm = context.getSystemService(ConnectivityManager::class.java)
//
//        cm.activeNetworkInfo
//        //return activeNetworkInfo != null && activeNetworkInfo.isConnected();
//
//        return cm.activeNetwork != null && cm.activeNetwork.c
    }
}