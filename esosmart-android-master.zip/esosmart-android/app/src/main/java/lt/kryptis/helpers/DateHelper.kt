package lt.kryptis.helpers

import java.text.SimpleDateFormat
import java.util.*

class DateHelper {
    companion object{
        val mISODateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale("lt-LT"))

        fun formatDate(date:Date, format:String = "yyyy-MM-dd"):String{
            return SimpleDateFormat(format, Locale("lt")).format(date)
        }
        fun isDST():Boolean{
            return Calendar.getInstance().get(Calendar.DST_OFFSET) == 0
        }

        fun strDateToTimestamp(date:String):Long{
            return mISODateFormat.parse(date)?.time?:0L
        }
    }
}