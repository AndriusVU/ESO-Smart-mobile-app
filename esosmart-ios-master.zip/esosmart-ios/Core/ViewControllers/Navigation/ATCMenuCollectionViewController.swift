//
//  ATCMenuCollectionViewController.swift
//  ShoppingApp
//
//  Created by Florian Marcu on 3/19/18.
//  Copyright © 2018 iOS App Templates. All rights reserved.
//

import UIKit
import MessageUI

protocol ATCMenuCollectionViewCellConfigurable {
    func configure(item: ATCNavigationItem);
}

public struct ATCMenuUIConfiguration {
    var itemFont: UIFont = UIFont.systemFont(ofSize: 16, weight: .medium)
    var tintColor: UIColor = UIColor(hexString: "#555555")
    var itemHeight: CGFloat = 45.0
    var backgroundColor: UIColor = .white
}

public struct ATCMenuConfiguration {
    let user: ATCUser?
    let cellClass: UICollectionViewCell.Type?
    let headerHeight: CGFloat
    let items: [ATCNavigationItem]
    let uiConfig: ATCMenuUIConfiguration
}

class ATCMenuCollectionViewController: ATCGenericCollectionViewController {

    fileprivate var lastSelectedIndexPath: IndexPath?

    var user: ATCUser?

    let cellClass: UICollectionViewCell.Type?
    let headerHeight: CGFloat
    let menuConfiguration: ATCMenuConfiguration

    init(menuConfiguration: ATCMenuConfiguration, collectionVCConfiguration: ATCGenericCollectionViewControllerConfiguration) {
        self.user = menuConfiguration.user
        self.cellClass = menuConfiguration.cellClass
        self.headerHeight = menuConfiguration.headerHeight
        self.menuConfiguration = menuConfiguration

        super.init(configuration: collectionVCConfiguration)
        if let cellClass = cellClass {
            self.use(adapter: ATCMenuItemRowAdapter(cellClassType: cellClass, uiConfig: menuConfiguration.uiConfig), for: "ATCNavigationItem")
        }
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView?.backgroundColor = menuConfiguration.uiConfig.backgroundColor
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if let collectionView = collectionView {
            collectionView.contentInset.top = max((collectionView.frame.height - collectionView.contentSize.height) / 3.0, 0)
        }
    }
}

extension ATCMenuCollectionViewController {
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let menuItem = self.genericDataSource?.object(at: indexPath.row) as? ATCNavigationItem else {
            return
        }
        if menuItem.type == .logout {
            NotificationCenter.default.post(name: kLogoutNotificationName, object: nil)
            self.drawerController()?.toggleMenu()
            return
        } else if menuItem.type == .email {
            if MFMailComposeViewController.canSendMail() {
                let mail = MFMailComposeViewController()
                mail.mailComposeDelegate = self
                mail.setToRecipients(["vuapp@eso.lt"])
                mail.setSubject("Klausimai dėl EsoSmart programėlės")

                present(mail, animated: true)
            } else {
                let dialogMessage = UIAlertController(title: "Pagalba", message: "Jūsų telefone nesukonfiguruota pašto programėlė, tad prašome siųsti laišką į vuapp@eso.lt", preferredStyle: .alert)

                let ok = UIAlertAction(title: "Gerai", style: .default)
                dialogMessage.addAction(ok)
                self.present(dialogMessage, animated: true, completion: nil)
            }
        } else if menuItem.type == .delete {
            let dialogMessage = UIAlertController(title: "Patvirtinkite", message: "Ar tikrai norite ištrinti savo paskyrą?", preferredStyle: .alert)

            let ok = UIAlertAction(title: "Taip", style: .destructive, handler: { alert  in
                if let token = Prefs.userToken {
                    
                    EsoAPIProvider.deleteUser(token: token) { (isDeleted) in
                        if isDeleted {
                            Prefs.clearData()
                            let dialogMessage = UIAlertController(title: "Ištrynimas", message: "Jūsų užklausa ištrinti paskyrą perduota administratoriui, kuris ją panaikins", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "Gerai", style: .default, handler: { alert in
                                Prefs.userToken = nil
                                NotificationCenter.default.post(name: kLogoutNotificationName, object: nil)
                                self.drawerController()?.toggleMenu()
                                return
                            })
                            dialogMessage.addAction(ok)
                            self.present(dialogMessage, animated: true, completion: nil)
                        } else {
                            let dialogMessage = UIAlertController(title: "Ištrynimas", message: "Ištrinti nepavyko, pamėginkite vėliau", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "Gerai", style: .default)
                            dialogMessage.addAction(ok)
                            self.present(dialogMessage, animated: true, completion: nil)
                        }
                    } failure: { (errCode, errDesc) in
                        AlertHelper.showError(view: self, error: errCode, message: errDesc)
                        
                        if(errCode == 404){
                            Prefs.clearData()
                            let dialogMessage = UIAlertController(title: "Ištrynimas", message: "Jūsų užklausa ištrinti paskyrą perduota administratoriui, kuris ją panaikins", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "Gerai", style: .default, handler: { alert in
                                Prefs.userToken = nil
                                NotificationCenter.default.post(name: kLogoutNotificationName, object: nil)
                                self.drawerController()?.toggleMenu()
                                return
                            })
                            dialogMessage.addAction(ok)
                            self.present(dialogMessage, animated: true, completion: nil)
                        }
                    }

                    
                    EsoAPIProvider.deleteUser(token: token) { isDeleted in

                    }
                }else{
                    NotificationCenter.default.post(name: kLogoutNotificationName, object: nil)
                    self.drawerController()?.toggleMenu()
                }
            })
            let cancel = UIAlertAction(title: "Ne", style: .cancel)
            dialogMessage.addAction(ok)
            dialogMessage.addAction(cancel)
            self.present(dialogMessage, animated: true, completion: nil)
        } else {
            let vc = menuItem.viewController
            self.drawerController()?.navigateTo(viewController: vc)
        }
    }
}

extension ATCMenuCollectionViewController {
    fileprivate func drawerController() -> ATCDrawerController? {
        return (self.parent as? ATCDrawerController)
    }
}

extension ATCMenuCollectionViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
}
