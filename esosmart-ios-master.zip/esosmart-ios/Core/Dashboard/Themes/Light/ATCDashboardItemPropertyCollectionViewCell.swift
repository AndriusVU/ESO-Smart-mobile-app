//
//  ATCDashboardItemPropertyCollectionViewCell.swift
//  DashboardApp
//
//  Created by Florian Marcu on 8/4/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCDashboardItemPropertyCollectionViewCell: UICollectionViewCell {
    @IBOutlet var valueLabel: UILabel!
    @IBOutlet var keyLabel: UILabel!
    @IBOutlet var borderView: UIView!
    @IBOutlet var containerView: UIView!
}
