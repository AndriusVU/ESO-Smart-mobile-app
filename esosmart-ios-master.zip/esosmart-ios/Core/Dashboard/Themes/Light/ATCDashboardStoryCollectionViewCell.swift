//
//  ATCDashboardStoryCollectionViewCell.swift
//  DashboardApp
//
//  Created by Florian Marcu on 8/7/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCDashboardStoryCollectionViewCell: UICollectionViewCell {
    @IBOutlet var containerView: UIView!
    @IBOutlet var storyImageView: UIImageView!
    @IBOutlet var imageContainerView: UIView!
    @IBOutlet var nameLabel: UILabel!
}
