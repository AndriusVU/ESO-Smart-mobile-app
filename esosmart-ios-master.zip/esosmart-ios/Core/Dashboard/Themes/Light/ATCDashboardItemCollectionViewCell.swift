//
//  ATCDashboardItemCollectionViewCell.swift
//  DashboardApp
//
//  Created by Florian Marcu on 8/4/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCDashboardItemCollectionViewCell: UICollectionViewCell {
    @IBOutlet var containerView: UIView!
    @IBOutlet var itemImageView: UIImageView!
    @IBOutlet var itemTitleLabel: UILabel!
    @IBOutlet var itemDescriptionLabel: UILabel!
    @IBOutlet var itemValueLabel: UILabel!
}
