//
//  ATCDashboardCategoryCollectionViewCell.swift
//  DashboardApp
//
//  Created by Florian Marcu on 7/31/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCDashboardCategoryCollectionViewCell: UICollectionViewCell {
    @IBOutlet var categoryContainerView: UIView!
    @IBOutlet var iconContainerView: UIView!
    @IBOutlet var iconImageView: UIImageView!
    @IBOutlet var categoryLabel: UILabel!
}
