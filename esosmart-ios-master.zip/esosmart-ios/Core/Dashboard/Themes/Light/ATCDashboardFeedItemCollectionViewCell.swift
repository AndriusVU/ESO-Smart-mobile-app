//
//  ATCDashboardFeedItemCollectionViewCell.swift
//  DashboardApp
//
//  Created by Florian Marcu on 8/1/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCDashboardFeedItemCollectionViewCell: UICollectionViewCell {
    @IBOutlet var itemContainerView: UIView!
    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var valueLabel: UILabel!
    @IBOutlet var itemTitleLabel: UILabel!
    @IBOutlet var badgeView: UIView!

}
