//
//  ATCOrderCollectionViewCell.swift
//  DashboardApp
//
//  Created by Florian Marcu on 7/29/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCOrderCollectionViewCell: UICollectionViewCell {
    @IBOutlet var orderContainerView: UIView!
    @IBOutlet var orderImageView: UIImageView!
    @IBOutlet var orderTitleView: UILabel!
    @IBOutlet var orderDescriptionLabel: UILabel!
    @IBOutlet var orderPriceLabel: UILabel!
}
