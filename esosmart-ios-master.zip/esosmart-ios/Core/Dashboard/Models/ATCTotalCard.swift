//
//  ATCTotalCard.swift
//  DashboardApp
//
//  Created by Florian Marcu on 7/28/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCTotalCard: ATCGenericBaseModel {
    var totalTitle: String
    var numberText: String
    var iconPath: String
    var gradientStartColor: String
    var gradientEndColor: String

    init(totalTitle: String, numberText: String, iconPath: String, gradientStartColor: String, gradientEndColor: String) {
        self.totalTitle = totalTitle
        self.numberText = numberText
        self.iconPath = iconPath
        self.gradientStartColor = gradientStartColor
        self.gradientEndColor = gradientEndColor
    }

    required init(jsonDict: [String: Any]) {
        fatalError()
    }

    var description: String {
        return totalTitle
    }
}
