//
//  ATCDashboardConfigurationProtocol.swift
//  DashboardApp
//
//  Created by Florian Marcu on 7/28/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

protocol ATCDashboardConfigurationProtocol: ATCUIGenericConfigurationProtocol {
//    var homeImage: UIImage { get }
//    var categoriesImage: UIImage { get }
//    var ordersImage: UIImage { get }
//    var notificationsImage: UIImage { get }
//    var composeImage: UIImage { get }
//    var savedImage: UIImage { get }
//    var searchImage: UIImage { get }
}
