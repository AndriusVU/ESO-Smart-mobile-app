//
//  ATCDividerCollectionViewCell.swift
//  RestaurantApp
//
//  Created by Florian Marcu on 5/19/18.
//  Copyright © 2018 iOS App Templates. All rights reserved.
//

import UIKit

class ATCDividerCollectionViewCell: UICollectionViewCell {
    @IBOutlet var dividerLabel: UILabel!
}
