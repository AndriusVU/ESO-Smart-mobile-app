import UIKit

enum UsagePeriod: String {
    case day = "day"
    case week = "week"
    case month = "month"
}

class MyUsageTabController: UIViewController {
    var tabs:[UIViewController] = []

    override func viewDidLoad() {

        super.viewDidLoad()
        title = "Mano elektros suvartojimas"
        view.backgroundColor = .white
        tabs.append(createItem(.day))
        tabs.append(createItem(.week))
        tabs.append(createItem(.month))
        setUpViewPager()
    }
    
    private func createItem(_ period: UsagePeriod) -> MyUsageViewController {
        let vc = MyUsageViewController(nibName: "MyUsageViewController", bundle: nil)
        vc.pushAction = { [weak self] in
            let compareCV = CompareViewController(nibName: "CompareViewController", bundle: nil)
            compareCV.period = period
            self?.navigationController?.pushViewController(compareCV, animated: true)
        }
        vc.period = period
        return vc
    }

    func setUpViewPager(){
        let viewPager = WormTabStrip(frame: view.frame)
        self.view.addSubview(viewPager)
        viewPager.delegate = self
        viewPager.eyStyle.wormStyel = .line
        viewPager.eyStyle.isWormEnable = false
        viewPager.eyStyle.spacingBetweenTabs = 0
        viewPager.eyStyle.dividerBackgroundColor = .white
        viewPager.eyStyle.topScrollViewBackgroundColor = .white
        viewPager.eyStyle.dividerBackgroundColor = .white
        viewPager.eyStyle.tabItemSelectedColor = UIColor(hexString: "#b4cc01")
        viewPager.eyStyle.tabItemDefaultColor = .darkGray
        viewPager.currentTabIndex = 0
        viewPager.eyStyle.tabItemDefaultFont = UIFont(name: "Avenir", size: 12)!
        viewPager.eyStyle.tabItemSelectedFont = UIFont(name: "Avenir", size: 12)!
        viewPager.eyStyle.WormColor = UIColor(hexString: "#b4cc01")
        viewPager.Width = view.frame.size.width
        viewPager.buildUI()
    }
}

extension MyUsageTabController: WormTabStripDelegate {
    func wtsNumberOfTabs() -> Int {
        return 3
    }

    func wtsViewOfTab(index: Int) -> UIView {
        let view = tabs[index]
        return view.view
    }

    func wtsTitleForTab(index: Int) -> String {
        switch index {
        case 0:
            return "Praėjusios paros"
        case 1:
            return "Paskutinės savaitės"
        default:
            return "Paskutinio mėnesio"
        }
    }

    func wtsDidSelectTab(index: Int) {

    }

    func wtsReachedLeftEdge(panParam: UIPanGestureRecognizer) {

    }

    func wtsReachedRightEdge(panParam: UIPanGestureRecognizer) {

    }
}

