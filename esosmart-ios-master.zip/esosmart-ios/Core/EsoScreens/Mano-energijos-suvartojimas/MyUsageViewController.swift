//
//  MyUsageViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-29.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit
import Charts

class MyUsageViewController: UIViewController {

    var period: UsagePeriod = .day

    var pushAction: ()->() = {}
    private let ITEM_COUNT = 24
    
    private var userUsage:[UserUsage]? = nil
    
    private var loading:Bool = false

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subTitleLabel: UILabel!
    @IBOutlet weak var chartView: CombinedChartView!
    @IBOutlet weak var compareButton: UIButton!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Mano elektros suvartojimas"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        subTitleLabel.text = "Vidutinis valandinis energijos suvartojimas"


        compareButton.configure(color: UIColor(hexString: "#b4cc01"),
                                font: UIFont(name: "Avenir-Heavy", size: 18)!,
                                cornerRadius: 55/2,
                                borderColor: UIColor(hexString: "#b4cc01"),
        backgroundColor: UIColor.white,
        borderWidth: 1.0)

        switch period {
        case .day:
            titleLabel.text = getYesterdayLabel()
        case .week:
            titleLabel.text = getLastWeekLabel()
        case .month:
            titleLabel.text = getLastMonthLabel()
        }
        
        compareButton.isHidden = !(Prefs.userData?.isV2() ?? false)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if !loading && userUsage == nil{
            if let token = Prefs.userToken {
                
                showProgress(true)
                loading = true
                EsoAPIProvider.getUsage(token: token, period: period) { (userUsage) in
                    
                    if let userUsage = userUsage{
                        self.userUsage = userUsage
                        self.setChartData(userUsage)
                    }
                    self.showProgress(false)
                    
                } failure: { (errCode, errDesc) in
                    AlertHelper.showError(view: self, error: errCode, message: errDesc)
                    self.compareButton.isHidden = true
                }
            }
        }else{
            if let userUsage = userUsage{
                self.setChartData(userUsage)
            }
        }
        
    }

    func setChartData(_ userUsage:[UserUsage]) {
        let data = CombinedChartData()
        data.barData = generateBarData(userUsage)

        chartView.xAxis.axisMaximum = data.xMax + 0.25
        chartView.data = data

        chartView.rightAxis.enabled = false
        chartView.extraBottomOffset = 10

        let xAxis = chartView.xAxis
        xAxis.labelPosition = .bottom
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)
        xAxis.drawAxisLineEnabled = true
        xAxis.drawGridLinesEnabled = false
        xAxis.granularityEnabled = true
        xAxis.granularity = 1
        xAxis.labelCount = 6
        xAxis.axisMinimum = 0
        xAxis.axisMaximum = 24
        xAxis.valueFormatter = TimeValueFormatter()

        let leftAxis = chartView.leftAxis
        leftAxis.labelFont = UIFont.systemFont(ofSize: 10)
        leftAxis.drawAxisLineEnabled = true
        leftAxis.drawGridLinesEnabled = true
        leftAxis.valueFormatter = NegativeValueFormatter()

        let l = chartView.legend
        l.neededHeight = 40
        l.yEntrySpace = 0
        l.font = UIFont.systemFont(ofSize: 10)
        l.wordWrapEnabled = true
        l.horizontalAlignment = .center
        l.verticalAlignment = .bottom
        l.orientation = .horizontal
        l.drawInside = false

        chartView.notifyDataSetChanged()
    }

    func generateBarData(_ userUsages:[UserUsage]) -> BarChartData {
        var entries:[BarChartDataEntry] = []
        
        
        for userUsage in userUsages{
            
            let timeParts = userUsage.time.components(separatedBy: ":")
            let h = Int(timeParts.first ?? "0") ?? 0
            
            let dayUsage:Double
            let nightUsage:Double
            let morningUsage:Double
            let eveningUsage:Double
            
            let barChartDataEntry:BarChartDataEntry
            
            if Prefs.userPlan?.zone.isFourZone() ?? false{
                
                if ZoneHours.morningHours.contains(h){
                    morningUsage = userUsage.consumed
                    dayUsage = 0
                    nightUsage = 0
                    eveningUsage = 0
                }else if ZoneHours.workingHours.contains(h){
                    dayUsage = userUsage.consumed
                    morningUsage = 0
                    nightUsage = 0
                    eveningUsage = 0
                }else if ZoneHours.eveningHours.contains(h){
                    eveningUsage = userUsage.consumed
                    morningUsage = 0
                    nightUsage = 0
                    dayUsage = 0
                }else{
                    nightUsage = userUsage.consumed
                    morningUsage = 0
                    eveningUsage = 0
                    dayUsage = 0
                }
                
                barChartDataEntry = BarChartDataEntry(x: Double(h) + 0.5, yValues: [morningUsage, dayUsage, eveningUsage, nightUsage, -userUsage.supplied])
                
            }else if Prefs.userPlan?.zone.isSingleZone() ?? false{
                barChartDataEntry = BarChartDataEntry(x: Double(h) + 0.5, yValues: [userUsage.consumed, -userUsage.supplied])
            }else{
                if ZoneHours.dayHours.contains(h){
                    dayUsage = userUsage.consumed
                    nightUsage = 0
                }else{
                    dayUsage = 0
                    nightUsage = userUsage.consumed
                }
                barChartDataEntry = BarChartDataEntry(x: Double(h) + 0.5, yValues: [dayUsage, nightUsage, -userUsage.supplied])
            }
            entries.append(barChartDataEntry)
            

        }
        
        
        
        let set = BarChartDataSet(entries: entries, label: "")
        
        if Prefs.userPlan?.zone.isFourZone() ?? false{
            set.stackLabels = ["Suvartojimas ryte", "Suvartojimas dieną", "Suvartojimas vakare", "Suvartojimas naktį", "Gamyba"]
            set.colors = [UIColor.colorChart1, UIColor.colorChart2, UIColor.colorChart3, UIColor.colorChart5, UIColor.colorChart4]
        }else if Prefs.userPlan?.zone.isSingleZone() ?? false{
            set.stackLabels = ["Suvartojimas", "Gamyba"]
            set.colors = [UIColor.colorChart1, UIColor.colorChart4]
        }else{
            set.stackLabels = ["Suvartojimas dieną", "Suvartojimas naktį", "Gamyba"]
            set.colors = [UIColor.colorChart1,UIColor.colorChart2, UIColor.colorChart4]
        }
        
    

        set.valueTextColor = UIColor(red: 61/255, green: 165/255, blue: 255/255, alpha: 1)
        set.valueFont = UIFont(name: "Avenir", size: 10)!
        set.axisDependency = .left
        set.drawValuesEnabled = false
        set.highlightEnabled = false

        let groupSpace = 0.06
        let barSpace = 0.02 // x2 dataset
        let barWidth = 0.8 // x2 dataset
        // (0.45 + 0.02) * 2 + 0.06 = 1.00 -> interval per "group"

        let data = BarChartData(dataSet: set)
        data.barWidth = barWidth

        // make this BarData object grouped
        //data.groupBars(fromX: 0, groupSpace: groupSpace, barSpace: barSpace)

        return data
    }

    @IBAction func compareButtonTapped(_ sender: Any) {
        let viewController = CompareViewController(nibName: "CompareViewController", bundle: nil)
        switch period {
        case .day:
            viewController.title = "Praėjusios paros"
        case .week:
            viewController.title = "Praėjusios savaitės"
        case .month:
            viewController.title = "Praėjusio mėnesio"
        }
        pushAction()
    }

    func getYesterdayLabel() -> String {
        return getLabel(daysBehind: -1)
    }

    func getLastWeekLabel() -> String {
        return getLabel(daysBehind: -7) + " - " + getLabel(daysBehind: -1)
    }

    func getLastMonthLabel() -> String {
        return getLabel(daysBehind: -30) + " - " + getLabel(daysBehind: -1)
    }

    private func getLabel(daysBehind: Int) -> String {
        var dateComponents = DateComponents()
        dateComponents.setValue(daysBehind, for: .day) // -1 day
        let now = Date() // Current date
        let yesterday = Calendar.current.date(byAdding: dateComponents, to: now)! // Add the DateComponents
        let formatter = DateFormatter()
             formatter.locale = Locale(identifier: "lt_LT")
        formatter.setLocalizedDateFormatFromTemplate("MMMMd")
        let date = formatter.string(from: yesterday)
        return date.prefix(1).capitalized + date.dropFirst()
    }
    
    func showProgress(_ show:Bool = true) {
        chartView.isHidden = show
        indicator.isHidden = !show
    }
}

