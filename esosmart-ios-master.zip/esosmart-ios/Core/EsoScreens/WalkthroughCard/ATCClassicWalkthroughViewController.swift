//
//  ATCClassicWalkthroughViewController.swift
//  DashboardApp
//
//  Created by Florian Marcu on 8/13/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCClassicWalkthroughViewController: UIViewController {


    @IBOutlet weak var topImageView: UIImageView!
    @IBOutlet var containerView: UIView!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var subtitleLabel: UILabel!

    let model: ATCWalkthroughModel
    let uiConfig: ATCUIGenericConfigurationProtocol

    init(model: ATCWalkthroughModel,
         uiConfig: ATCUIGenericConfigurationProtocol,
         nibName nibNameOrNil: String?,
         bundle nibBundleOrNil: Bundle?) {
        self.model = model
        self.uiConfig = uiConfig
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    @IBOutlet weak var topImageWidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var bottomImageWidthConstraint: NSLayoutConstraint!

    override func viewDidLoad() {
        super.viewDidLoad()

        imageView.image = UIImage.localImage(model.icon, template: true)
        imageView.contentMode = .scaleAspectFit
        imageView.clipsToBounds = true
        imageView.tintColor = uiConfig.mainThemeBackgroundColor

        if let iconSecond = model.iconSecond {
            topImageView.image = UIImage.localImage(iconSecond, template: true)

            topImageView.translatesAutoresizingMaskIntoConstraints = false
            //imageView.translatesAutoresizingMaskIntoConstraints = false

            topImageWidthConstraint.isActive = false
            bottomImageWidthConstraint.isActive = false
            topImageView.topAnchor.constraint(equalTo: view.centerYAnchor, constant: -150).isActive = true
            topImageView.bottomAnchor.constraint(equalTo: imageView.topAnchor, constant: 100).isActive = true
            titleLabel.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 0).isActive = true
            //topImageView.heightAnchor.constraint(equalToConstant: 300).isActive = true
            //topImageView.widthAnchor.constraint(equalToConstant: view.frame.size.width / 1.5).isActive = true

            topImageView.contentMode = .scaleAspectFit

            topImageView.clipsToBounds = true
            topImageView.tintColor = uiConfig.mainThemeBackgroundColor

        }

        titleLabel.text = model.title
        titleLabel.font = uiConfig.boldLargeFont
        titleLabel.textColor = uiConfig.mainThemeBackgroundColor

        if let subtitleText = model.subtitle {
            subtitleLabel.attributedText = NSAttributedString(string: subtitleText)
            subtitleLabel.font = uiConfig.regularSemiLargeFont
            subtitleLabel.textColor = uiConfig.mainThemeBackgroundColor
        }

        containerView.backgroundColor = uiConfig.mainThemeForegroundColor
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        containerView.frame = self.view.bounds
    }
}
