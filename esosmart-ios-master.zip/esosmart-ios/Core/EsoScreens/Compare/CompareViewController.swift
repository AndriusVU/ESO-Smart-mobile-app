//
//  CompareViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-08-02.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit
import Charts

class CompareViewController: UIViewController {

    @IBOutlet weak var circleView: UIView!
    @IBOutlet weak var chartView: BarChartView!
    @IBOutlet var leftTextLabel: UILabel!
    @IBOutlet var rightTextLabel: UILabel!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    @IBOutlet weak var wrap: UIView!
    @IBOutlet weak var footnoteLabel: UILabel!
    
    var period: UsagePeriod = .day
    
    var compareData:CompareData? = nil

    override func viewDidLoad() {
        super.viewDidLoad()
        switch period {
        case .day:
            title = "Praėjusios paros"
        case .week:
            title = "Paskutinės savaitės"
        case .month:
            title =  "Paskutinio mėnesio"
        }
        circleView.layer.cornerRadius = 125
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)

        
        if let token = Prefs.userToken {
            
            showProgress()
            
            EsoAPIProvider.getCompare(token: token, period: period) { (compareData) in
                
                self.showProgress(false)
                
                self.compareData = compareData
                
                if let compareData = compareData{
                    self.loadChartData(compareData)
                    
                    
                    if compareData.my_average > 0{
                        let avgComp = ((compareData.my_total / compareData.my_average) - 1) * 100
                        self.leftTextLabel.text = String(format: self.getPeriodAvgStringId(), arguments: [
                            self.getPeriodName(), avgComp, self.getMoreOrLessName(avgComp)
                                                            
                        ])
                    }else{
                        self.leftTextLabel.text = "";
                    }
                    
                    if compareData.others_average > 0{
                        let othersComp = (compareData.my_total / compareData.others_average - 1) * 100
                        self.rightTextLabel.text = String(format: self.getPeriodOtherStringId(), arguments: [
                            self.getPeriodName(), othersComp, self.getMoreOrLessName(othersComp)
                                                            
                        ])
                    }
                    
                    if let energy_group = compareData.energy_group{
                        if energy_group.interval_to > 10000{
                            self.footnoteLabel.text = String(format: "Į jus panašūs namų ūkiai suvartoja %@ kwh/mėn.", "nuo \(energy_group.interval_from)")
                        }else{
                            self.footnoteLabel.text = String(format: "Į jus panašūs namų ūkiai suvartoja %@ kwh/mėn.", "nuo \(energy_group.interval_from) iki \(energy_group.interval_to)")
                        }
                        
                    }
                }
                
                
//                let avgComp = total / average - 1
//                let othersComp = total / otherAverage - 1
//
//                if let total = total, let average = average{
//                    let result = (total / average * 100)
//                    self.leftTextLabel.text = String(format: self.getPeriodAvgStringId(), arguments: [self.getPeriodName(), result, self.getMoreOrLessName(result)])
//                }

//                guard let total = total,
//                    let average = average, total != average, average != 0 else { return "" }
//
//                let result = Int(round(total / average * 100) - 100)
                
                
                
                
                /*
                self.leftNumberLabel.text = self.makeLeftNumber()
                self.leftTextLabel.text = self.makeLeftText()
                self.rightNumberLabel.text = self.makeRightNumber()
                self.rightTextLabel.text = self.makeRightText()
                */
            } failure: { (errCode, errDesc) in
                AlertHelper.showError(view: self, error: errCode, message: errDesc)
            }
        }
    }
    
    func showProgress(_ show:Bool = true) {
        wrap.isHidden = show
        indicator.isHidden = !show
    }

    func loadChartData(_ compareData:CompareData) {
        let l = chartView.legend
        l.neededHeight = 0
        l.yEntrySpace = 0
        l.font = UIFont.systemFont(ofSize: 12)
        l.wordWrapEnabled = true
        l.horizontalAlignment = .center
        l.verticalAlignment = .bottom
        l.orientation = .vertical
        l.drawInside = false
        chartView.extraBottomOffset = 10

        let firstLegend = LegendEntry.init(label: "Mano elektros suvartojimas", form: .default, formSize: CGFloat.nan, formLineWidth: CGFloat.nan, formLineDashPhase: CGFloat.nan, formLineDashLengths: nil, formColor: UIColor(hexString: "#44B69F"))
        let secondLegend = LegendEntry.init(label: "Mano vidutinis elektros suvartojimas", form: .default, formSize: CGFloat.nan, formLineWidth: CGFloat.nan, formLineDashPhase: CGFloat.nan, formLineDashLengths: nil, formColor: UIColor(hexString: "#3E93C6"))
        let thirdLegend = LegendEntry.init(label: "Į mane panašių namų ūkių vidutinis elektros suvartojimas", form: .default, formSize: CGFloat.nan, formLineWidth: CGFloat.nan, formLineDashPhase: CGFloat.nan, formLineDashLengths: nil, formColor: UIColor(hexString: "#6D2D8B"))
        l.setCustom(entries: [firstLegend, secondLegend, thirdLegend])


        let totalEntry = BarChartDataEntry(x: 0, y: compareData.my_total)
        let averageEntry = BarChartDataEntry(x: 1, y: compareData.my_average)
        let otherAverageEntry = BarChartDataEntry(x: 2, y: compareData.others_average)

        let set = BarChartDataSet(entries: [totalEntry, averageEntry, otherAverageEntry], label: "")
        set.colors = [UIColor(hexString: "#44B69F"),
                       UIColor(hexString: "#3E93C6"),
                       UIColor(hexString: "#6D2D8B")
        ]
        set.drawValuesEnabled = true
        set.highlightEnabled = true

        let data = BarChartData(dataSets: [set])
        //data.setValueFormatter(MyFormatter(format: ""))
        
        chartView.delegate = self
        
        chartView.data = data

        chartView.xAxis.drawGridLinesEnabled = false
        chartView.xAxis.drawLabelsEnabled = false
        chartView.rightAxis.enabled = false
        chartView.leftAxis.drawGridLinesEnabled = true
        chartView.leftAxis.axisMinimum = 0

        chartView.notifyDataSetChanged()
    }

//    func makeLeftNumber() -> String {
//        guard let total = total,
//            let average = average, total != average, average != 0 else { return "" }
//
//        let result = Int(round(total / average * 100) - 100)
//        let sign = total > average ? "+" : "-"
//        return sign + "\(result) %"
//    }
//
//    func makeLeftText() -> String {
//        guard let total = total,
//            let average = average, total != average, average != 0 else { return "" }
//
//        let sign = total > average ? "daugiau" : "mažiau"
//        return "Tiek \(sign) elektros nei jūsų vidurkis suvartojote"
//    }
//
//    func makeRightNumber() -> String {
//        guard let total = total,
//            let average = otherAverage, total != average, average != 0 else { return "" }
//
//        let result = Int(round(total / average * 100) - 100)
//        let sign = total > average ? "+" : ""
//        return sign + "\(result) %"
//    }
//
//    func makeRightText() -> String {
//        guard let total = total,
//            let average = otherAverage, total != average, average != 0 else { return "" }
//
//        let sign = total > average ? "daugiau" : "mažiau"
//        return "Tiek \(sign) suvartojote elektros nei į jus panašūs vartotojai"
//    }
    
    
    func getPeriodAvgStringId() -> String{
        switch period {
        case .month:
            return "Praėjusį %@ jūs suvartojote %.0f%% %@ elektros energijos palyginant su jūsų vidutiniu suvartojimu"
        default:
            return "Praėjusią %@ jūs suvartojote %.0f%% %@ elektros energijos palyginant su jūsų vidutiniu suvartojimu"
        }
    }
    func getPeriodOtherStringId() -> String{
        
        switch period {
        case .month:
            return "Praėjusį %@ jūs suvartojote %.0f%% %@ elektros energijos palyginant su panašiais namų ūkiais"
        default:
            return "Praėjusią %@ jūs suvartojote %.0f%% %@ elektros energijos palyginant su panašiais namų ūkiais"
        }
    }
    func getPeriodName() -> String{
        
        switch period {
        case .day:
            return "parą"
        case .week:
            return "savaitę"
        default:
            return "mėnesį"
        }
    }

    func getMoreOrLessName(_ v: Double) -> String{
        
        if v > 0{
            return "daugiau"
        }else if v < 0{
            return "mažiau"
        }else{
            return "lygiai"
        }
    }
    func getPeriodDuration() -> String{
        
        switch period {
        case .day:
            return "7 dienų"
        case .week:
            return "4 savaičių"
        default:
            return "12 mėnesių"
        }
    }
    func getOfPeriod() -> String{
        switch period {
        case .day:
            return "paros"
        case .week:
            return "savaitinis"
        default:
            return "mėnesinis"
        }
    }
    
    func getLastOfPeriod() -> String{
        switch period {
        case .day:
            return "Praėjusios paros 24 valandų"
        case .week:
            return "Paskutinių 7 parų"
        default:
            return "Paskutinių 30 parų"
        }
    }
}

extension CompareViewController:ChartViewDelegate{
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        
        if let energy_group = self.compareData?.energy_group{
            switch entry.x {
            case 0:
                AlertHelper.showAlert(
                    view: self,
                    message: String(
                        format: "%@ suminis elektros energijos suvartojimas",
                        arguments: [self.getLastOfPeriod()]
                    )
                )
                break;
            case 1:
                AlertHelper.showAlert(
                    view: self,
                    message: String(
                        format: "Jūsų paskutinių %@ vidutinis %@ elektros suvartojimas",
                        arguments: [self.getPeriodDuration(), self.getOfPeriod()]
                    )
                )
                break
            case 2:
                if energy_group.interval_to > 10000{
                    AlertHelper.showAlert(
                        view: self,
                        message: String(
                            format: "Į jus panašių namų ūkių, suvartojančių %@ kWh/mėn., paskutinių %@ vidutinis %@ elektros suvartojimas",
                            arguments: ["nuo \(energy_group.interval_from)", self.getPeriodDuration(), self.getOfPeriod()]
                        )
                    )
                }else{
                    AlertHelper.showAlert(
                        view: self,
                        message: String(
                            format: "Į jus panašių namų ūkių, suvartojančių %@ kWh/mėn., paskutinių %@ vidutinis %@ elektros suvartojimas",
                            arguments: ["nuo \(energy_group.interval_from) iki \(energy_group.interval_to)", self.getPeriodDuration(), self.getOfPeriod()]
                        )
                    )
                }
                
                break
            default:
                break
            }
            
            print(entry)
        }
    }
}
