//
//  ForecastViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-08-02.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit
import Charts

class ForecastViewController: UIViewController {
    let ITEM_COUNT = 24
    var period: FuturePast = .historical
    @IBOutlet weak var subTitleLabel: UILabel!
    @IBOutlet weak var chartView: LineChartView!
    @IBOutlet weak var bottomLabel: UILabel!
    @IBOutlet var activityIndicator: UIActivityIndicatorView!

    override func viewDidLoad() {
        super.viewDidLoad()
        activityIndicator.startAnimating()
        switch period {
        case .historical:
            let now = Date()
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "lt_LT")
            formatter.setLocalizedDateFormatFromTemplate("MMMMd")
            let string = formatter.string(from: now).split(separator: " ").first ?? ""
            
            EsoAPIProvider.getHistorical { historicalPrices in
                if let historicalPrices = historicalPrices {
                    self.setChartData(
                        historicalPrices.map { $0.energy_usage },
                        historicalPrices.map { $0.production },
                        historicalPrices.map { $0.production_wind}
                    );
                }
            } failure: { (errCode, errDesc) in
                AlertHelper.showError(view: self, error: errCode, message: errDesc)
                self.activityIndicator.stopAnimating()
            }
            
            subTitleLabel.text = "2019 metų \(string) vidutiniai nacionaliniai elektros energijos gamybos ir suvartojimo valandiniai duomenys, MW"

            
        default:
            
            EsoAPIProvider.getForecast { (forecastData) in
                if let forecastData = forecastData{
                    self.setChartData(
                        forecastData.map { $0.forecast_usage },
                        forecastData.map { $0.planned_production },
                        forecastData.map { $0.planned_production_wind }
                    );
                }
            } failure: { (errCode, errDesc) in
                AlertHelper.showError(view: self, error: errCode, message: errDesc)
                self.activityIndicator.stopAnimating()
            }

            
            subTitleLabel.text = "Prognozuojami šiandienos nacionaliniai elektros energijos gamybos ir suvartojimo valandiniai duomenys, MW"
        }
    }
    @IBAction func linkTapped(_ sender: Any) {
        if let url = URL(string: "https://www.litgrid.eu/index.php/sistemos-duomenys/79") {
            UIApplication.shared.open(url)
        }
    }

    func setChartData(_ usage:[Double], _ production:[Double], _ production_wind:[Double]) {
        let consumptionData = generateConsumptionData(items: usage)
        let productionData = generateProductionData(items: production)
        let windData = generateWindData(items: production_wind)

        chartView.xAxis.axisMaximum = max(consumptionData.xMax, productionData.xMax, windData.xMax) + 0.25

        let data = LineChartData(dataSets: [consumptionData, productionData, windData])
        chartView.data = data

        let xAxis = chartView.xAxis
        xAxis.labelPosition = .bottom
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)
        xAxis.drawAxisLineEnabled = true
        xAxis.drawGridLinesEnabled = false
        xAxis.granularity = 1
        xAxis.valueFormatter = TimeValueFormatter()

        let leftAxis = chartView.leftAxis
        leftAxis.labelFont = UIFont.systemFont(ofSize: 10)
        leftAxis.drawAxisLineEnabled = true
        leftAxis.drawGridLinesEnabled = true
        leftAxis.axisMinimum = 0
        chartView.rightAxis.enabled = false
        chartView.extraBottomOffset = 10

        let l = chartView.legend
        l.neededWidth = view.frame.size.width
        l.font = UIFont.systemFont(ofSize: 12)
        l.wordWrapEnabled = false
        l.horizontalAlignment = .center
        l.verticalAlignment = .bottom
        l.orientation = .vertical
        l.drawInside = false
        l.neededHeight = 90
        l.yEntrySpace = 7
        l.xOffset = 0

        activityIndicator.stopAnimating()
        chartView.notifyDataSetChanged()
    }

    func generateConsumptionData(items: [Double]) -> LineChartDataSet {
        var entries: [ChartDataEntry] = []
        for (index, item) in items.enumerated() {
            entries.append(ChartDataEntry(x: Double(index) + 0.5, y: item))
        }

        let set = LineChartDataSet(entries: entries, label: "Elektros energijos suvartojimas Lietuvoje")
        set.setColor(UIColor(hexString: "#3E93C6"))
        set.lineWidth = 2.5
        set.setCircleColor(UIColor(hexString: "#3E93C6"))
        set.circleRadius = 1
        set.circleHoleRadius = 2.5
        set.fillColor = UIColor(hexString: "#3E93C6")
        set.mode = .linear
        set.drawValuesEnabled = false
        set.valueFont = UIFont(name: "Avenir", size: 14)!
        set.valueTextColor = UIColor(hexString: "#EEA30C")
        set.highlightEnabled = false

        set.axisDependency = .left

        return set
    }

    func generateProductionData(items: [Double]) -> LineChartDataSet {
        var entries: [ChartDataEntry] = []
        for (index, item) in items.enumerated() {
            entries.append(ChartDataEntry(x: Double(index) + 0.5, y: item))
        }
        let set = LineChartDataSet(entries: entries, label: "Elektros energijos gamyba Lietuvoje")
        set.setColor(UIColor(hexString: "#44B69F"))
        set.lineWidth = 2.5
        set.setCircleColor(UIColor(hexString: "#44B69F"))
        set.circleRadius = 1
        set.circleHoleRadius = 2.5
        set.fillColor = UIColor(hexString: "#44B69F")
        set.mode = .linear
        set.drawValuesEnabled = false
        set.valueFont = UIFont(name: "Avenir", size: 14)!
        set.valueTextColor = UIColor(hexString: "#EEA30C")
        set.highlightEnabled = false

        set.axisDependency = .left

        return set
    }

    func generateWindData(items: [Double]) -> LineChartDataSet {
        var entries: [ChartDataEntry] = []
        for (index, item) in items.enumerated() {
            entries.append(ChartDataEntry(x: Double(index) + 0.5, y: item))
        }

        let set = LineChartDataSet(entries: entries, label: "Vėjo elektrinių gamyba Lietuvoje")
        set.setColor(UIColor(hexString: "#EEA30C"))
        set.lineWidth = 2.5
        set.setCircleColor(UIColor(hexString: "#EEA30C"))
        set.circleRadius = 1
        set.circleHoleRadius = 2.5
        set.fillColor = UIColor(hexString: "#EEA30C")
        set.mode = .linear
        set.drawValuesEnabled = false
        set.valueFont = UIFont(name: "Avenir", size: 14)!
        set.valueTextColor = UIColor(hexString: "#EEA30C")
        set.highlightEnabled = false

        set.axisDependency = .left

        return set
    }

}
