//
//  CompareSlidingTabController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-08-02.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit

enum FuturePast {
    case forecast, historical
}
class ForecastTabController: UIViewController, WormTabStripDelegate {
    var tabs:[UIViewController] = []
    func wtsNumberOfTabs() -> Int {
        return 2
    }

    func wtsViewOfTab(index: Int) -> UIView {
        let view = tabs[index]
        return view.view
    }

    func wtsTitleForTab(index: Int) -> String {
        if index == 0 {
            return "Prognozuojami duomenys"
        } else {
            return "Istoriniai duomenys"
        }
    }

    func setUpViewPager(){
        let frame =  CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        let viewPager = WormTabStrip(frame: frame)
        self.view.addSubview(viewPager)
        viewPager.delegate = self
        viewPager.eyStyle.wormStyel = .line
        viewPager.eyStyle.isWormEnable = false
        viewPager.eyStyle.spacingBetweenTabs = 0
        viewPager.eyStyle.dividerBackgroundColor = .white
        viewPager.eyStyle.topScrollViewBackgroundColor = .white
        viewPager.eyStyle.dividerBackgroundColor = .white
        viewPager.eyStyle.tabItemSelectedColor = UIColor(hexString: "#b4cc01")
        viewPager.eyStyle.tabItemDefaultColor = .darkGray
        viewPager.currentTabIndex = 0
        viewPager.eyStyle.tabItemDefaultFont = UIFont(name: "Avenir", size: 12)!
        viewPager.eyStyle.tabItemSelectedFont = UIFont(name: "Avenir", size: 12)!
        viewPager.eyStyle.WormColor = UIColor(hexString: "#b4cc01")
        viewPager.buildUI()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Elektros gamyba ir suvartojimas"

        tabs.append(createItem(.forecast))
        tabs.append(createItem(.historical))
        setUpViewPager()
        setupUI()
    }

    private func setupUI(){
        view.backgroundColor = .white

    }

    private func createItem(_ period: FuturePast) -> ForecastViewController {
        let vc = ForecastViewController(nibName: "ForecastViewController", bundle: nil)
        vc.period = period
        return vc
    }


    func wtsDidSelectTab(index: Int) {

    }

    func wtsReachedLeftEdge(panParam: UIPanGestureRecognizer) {

    }

    func wtsReachedRightEdge(panParam: UIPanGestureRecognizer) {

    }

}
