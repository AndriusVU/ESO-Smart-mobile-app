//
//  EnterPriceViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-28.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit

class EnterPriceViewController: UIViewController {

    @IBOutlet weak var dedTextField: BaseTextField!
    @IBOutlet weak var dayTextField: BaseTextField!
    @IBOutlet weak var nightTextField: BaseTextField!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var scrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Įveskite savo elektros tarifą"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
        self.hideKeyboardWhenTappedAround()
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name:UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name:UIResponder.keyboardWillHideNotification, object: nil)
    }

    @IBAction func continueButtonTapped(_ sender: Any) {
        
        if validate(input: dedTextField)
            && validate(input: dayTextField)
            && validate(input: nightTextField)
        {
            
            var priceParts = [PricePart]()
            priceParts.append(
                PricePart(id: PriceType.DED.rawValue, title: PriceType.DED.getTitle(), price: getPriceFromInput(dedTextField))
            )
            
            let dayPrice = getPriceFromInput(dayTextField)
            let nightPrice = getPriceFromInput(nightTextField)
            
            var zoneType:ZoneType = ZoneType.ZONE_1
            
            if(dayPrice == nightPrice || nightPrice == 0){
                priceParts.append(
                    PricePart(id: PriceType.ALL.rawValue, title: PriceType.ALL.getTitle(), price: getPriceFromInput(dayTextField))
                )
                zoneType = ZoneType.ZONE_1
            }else{
                priceParts.append(
                    PricePart(id: PriceType.DAY.rawValue, title: PriceType.DAY.getTitle(), price: getPriceFromInput(dayTextField))
                )
                priceParts.append(
                    PricePart(id: PriceType.NIGHT.rawValue, title: PriceType.NIGHT.getTitle(), price: getPriceFromInput(nightTextField))
                )
                zoneType = ZoneType.ZONE_2
            }
            
            let zone = Zone(id: zoneType.rawValue, title: zoneType.getTitle(), prices: priceParts)
            
            let plan = Plan(id: 0, title: "Individualus planas", description: "", zones: [zone])
            
            
            Prefs.userPlan = UserPlan(plan: plan, zone: zone)
            
            let viewController = FareViewController(nibName: "FareViewController", bundle: nil)
            navigationController?.setViewControllers([viewController], animated: true)
        }
        
        
//        guard let priceString = priceTextField.text, let price = Double(priceString) else { return }
//        UserDefaults.standard.set(price, forKey: "my-price")
//

    }
    
    private func validate(input:BaseTextField) -> Bool{
        var valid = true
        
        
        let price = getPriceFromInput(input)
        
        switch input {
            case dayTextField:
                valid = price > 0.001 && price < 100
            case nightTextField:
                valid = price > 0.0 && price < 100
            default:
                valid = true
        }
        
        if !valid{
            input.layer.borderColor = UIColor.red.cgColor
        }else{
            input.layer.borderColor = UIColor.colorPrimary.cgColor
        }
        
        input.text = String(format: "%0.2f", price)
        
        return valid
    }
    
    private func getPriceFromInput(_ input:BaseTextField) -> Double{
        if let price = Double(input.text ?? "0") {
            return price
        }else{
            return 0
        }
    }
    
    @objc func keyboardWillShow(notification:NSNotification){

        let userInfo = notification.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)

        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height + 20
        scrollView.contentInset = contentInset
    }

    @objc func keyboardWillHide(notification:NSNotification){

        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        scrollView.contentInset = contentInset
    }
}
