//
//  NotificationsViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-08-05.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit

struct Message {
    let id: Int
    let subject: String
    let body: String
    let date: Date
    let isRead: Bool
}

class NotificationsViewController: UIViewController {

    @IBOutlet var tableView: UITableView!

    var notifications: [Message] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Pranešimai"

        tableView.register(UINib(nibName: "NotificationTableViewCell", bundle: nil), forCellReuseIdentifier: "CustomCell")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 60

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSSSSS"
        dateFormatter.locale = Locale(identifier: "lt_LT")

        if let token = Prefs.userToken {
            EsoAPIProvider.getNotifications(token: token, completion: { items in
                if let items = items as? [Any] {
                    for item in items {
                        if let item = item as? [String: Any],
                            let message = item["message"] as? String,
                            let id = item["id"] as? Int,
                            let dateDic = item["created_at"] as? [String: Any],
                            let date = dateDic["date"] as? String,
                            let subject = item["subject"] as? String {

                            let message = Message(id: id, subject: subject, body: message, date: dateFormatter.date(from: date)!, isRead: true)
                            self.notifications.append(message)
                        }
                    }
                    self.tableView.reloadData()
                }
            })
        }
    }
}

extension NotificationsViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return notifications.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView
            .dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as? NotificationTableViewCell {

            let message = notifications[indexPath.row]
            cell.titleLabel.text = message.subject
            cell.bodyLabel.text = message.body

            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "lt_LT")
            formatter.setLocalizedDateFormatFromTemplate("MMMMd")
            cell.dateLabel.text = formatter.string(from: message.date)

            return cell
        } else {
            return UITableViewCell()
        }
    }


}
