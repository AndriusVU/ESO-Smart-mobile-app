//
//  FareViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-19.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit

class FareViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var changeButton: UIButton!
    @IBOutlet weak var secondaryTitleLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!

    private var userPlan:UserPlan? = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 40
    }
    
    override func viewDidAppear(_ animated: Bool) {
        userPlan = Prefs.userPlan
        
        if let userPlan = userPlan{
            title = "Planas " + (userPlan.plan.title ?? "ok")
            navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
            configure()
            tableView.reloadData()
            
        }else{
            let viewController = MyFareViewController(nibName: "MyFareViewController", bundle: nil)
            navigationController?.pushViewController(viewController, animated: true)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        

    }
    

    func configure() {
        if let iconUrl = userPlan?.plan.icon {
            if let url = URL(string: EsoAPI.imageUrlBase + iconUrl){
                do{
                    let data = try Data(contentsOf: url)
                    imageView?.image = UIImage(data: data)
                }catch{
                    print(error)
                }
            }

            
            
        }

        nameLabel.text = userPlan?.plan.title
        secondaryTitleLabel.text = "\(userPlan?.zone.title ?? "") tarifas"
    }

    @IBAction func continueTapped(_ sender: Any) {
        let viewController = PricesViewController(nibName: "PricesViewController", bundle: nil)
        navigationController?.setViewControllers([viewController], animated: false)
    }
    @IBAction func changeTapped(_ sender: Any) {
        let viewController = MyFareViewController(nibName: "MyFareViewController", bundle: nil)
        navigationController?.pushViewController(viewController, animated: true)
        
    }
}

extension FareViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return userPlan?.zone.prices.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: "PricePartCell")
        cell.textLabel?.font = UIFont(name: "Avenir", size: 16)!
        cell.detailTextLabel?.font = UIFont(name: "Avenir", size: 16)!
        cell.detailTextLabel?.textColor = cell.textLabel?.textColor

        cell.textLabel?.numberOfLines = 0

        cell.textLabel?.translatesAutoresizingMaskIntoConstraints = false
        cell.detailTextLabel?.translatesAutoresizingMaskIntoConstraints = false
        cell.textLabel?.leadingAnchor.constraint(equalTo: cell.leadingAnchor, constant: 15).isActive = true
        cell.textLabel?.widthAnchor.constraint(equalToConstant: cell.frame.size.width * 0.8).isActive = true
        cell.detailTextLabel?.widthAnchor.constraint(equalToConstant: cell.frame.size.width * 0.3).isActive = true
        cell.detailTextLabel?.trailingAnchor.constraint(equalTo: cell.trailingAnchor, constant: -15).isActive = true



        if let pricePart = userPlan?.zone.prices[indexPath.row] {
            cell.textLabel?.text = pricePart.title
            if let value = pricePart.price {
                
                switch pricePart.id {
                    case PriceType.DED.rawValue:
                        cell.detailTextLabel?.text = "\(value) Eur/mėn"
                    default:
                        cell.detailTextLabel?.text = "\(value) ct/kWh"
                }
                
            }
        }
        return cell
    }
}
