//
//  ATCSignUpScreenManager.swift
//  DashboardApp
//
//  Created by Florian Marcu on 8/10/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

protocol ATCSignUpScreenManagerDelegate: class {
    func signUpManagerDidCompleteSignUp(_ signUpManager: ATCSignUpScreenManager)
    func signUpManagerDidCompleteLoginUp(_ signUpManager: ATCSignUpScreenManager)
}



class ATCSignUpScreenManager: ATCSignUpScreenDelegate {
    let signUpScreen: ATCSignUpScreenProtocol
    let viewModel: ATCSignUpScreenViewModel
    let uiConfig: ATCOnboardingConfigurationProtocol
    let serverConfig: ATCOnboardingServerConfigurationProtocol

    weak var delegate: ATCSignUpScreenManagerDelegate?

    private class Constants {
        static let cornerRadius: CGFloat = 28
    }

    init(signUpScreen: ATCSignUpScreenProtocol,
         viewModel: ATCSignUpScreenViewModel,
         uiConfig: ATCOnboardingConfigurationProtocol,
         serverConfig: ATCOnboardingServerConfigurationProtocol) {
        self.signUpScreen = signUpScreen
        self.viewModel = viewModel
        self.uiConfig = uiConfig
        self.serverConfig = serverConfig
    }

    func signUpScreenDidLoadView(_ signUpScreen: ATCSignUpScreenProtocol) {
//        if let titleLabel = signUpScreen.titleLabel {
//            titleLabel.font = uiConfig.titleFont
//            titleLabel.text = viewModel.title
//            titleLabel.textColor = uiConfig.titleColor
//        }

//        if let subTitleLabel = signUpScreen.subTitleLabel {
//            subTitleLabel.font = uiConfig.subtitleFont
//            subTitleLabel.text = viewModel.subTitle
//            subTitleLabel.textColor = uiConfig.subtitleColor
//        }

        if let nameField = signUpScreen.nameTextField {
            nameField.configure(color: uiConfig.textFieldColor,
                                font: uiConfig.signUpTextFieldFont,
                                cornerRadius: Constants.cornerRadius,
                                borderColor: uiConfig.textFieldBorderColor,
                                backgroundColor: uiConfig.textFieldBackgroundColor,
                                borderWidth: 1.0)
            nameField.placeholder = viewModel.nameField
            nameField.clipsToBounds = true
        }

        if let addressField = signUpScreen.addressTextField {
            addressField.configure(color: uiConfig.textFieldColor,
                                font: uiConfig.signUpTextFieldFont,
                                cornerRadius: Constants.cornerRadius,
                                borderColor: uiConfig.textFieldBorderColor,
                                backgroundColor: uiConfig.textFieldBackgroundColor,
                                borderWidth: 1.0)
            addressField.placeholder = viewModel.addressField
            addressField.clipsToBounds = true
        }

        if let emailField = signUpScreen.emailTextField {
            emailField.configure(color: uiConfig.textFieldColor,
                                font: uiConfig.signUpTextFieldFont,
                                cornerRadius: Constants.cornerRadius,
                                borderColor: uiConfig.textFieldBorderColor,
                                backgroundColor: uiConfig.textFieldBackgroundColor,
                                borderWidth: 1.0)
            emailField.placeholder = viewModel.emailField
            emailField.clipsToBounds = true
        }

        if let phoneNumberTextField = signUpScreen.phoneNumberTextField {
            phoneNumberTextField.configure(color: uiConfig.textFieldColor,
                                           font: uiConfig.signUpTextFieldFont,
                                           cornerRadius: Constants.cornerRadius,
                                           borderColor: uiConfig.textFieldBorderColor,
                                           backgroundColor: uiConfig.textFieldBackgroundColor,
                                           borderWidth: 1.0)
            phoneNumberTextField.placeholder = viewModel.phoneField
            phoneNumberTextField.clipsToBounds = true
        }


        if let signUpButton = signUpScreen.signUpButton {
            signUpButton.setTitle(viewModel.signUpString, for: .normal)
            signUpButton.addTarget(self, action: #selector(didTapSignUpButton), for: .touchUpInside)
            signUpButton.configure(color: uiConfig.logoTintColor,
                                   font: uiConfig.signUpButtonFont,
                                   cornerRadius: Constants.cornerRadius,
                                   borderColor: uiConfig.logoTintColor,
                                   backgroundColor: .white,
                                   borderWidth: 1.0)
        }
        
        
        if let loginEmailTextField = signUpScreen.loginEmailTextField {
            loginEmailTextField.configure(color: uiConfig.textFieldColor,
                                font: uiConfig.signUpTextFieldFont,
                                cornerRadius: Constants.cornerRadius,
                                borderColor: uiConfig.textFieldBorderColor,
                                backgroundColor: uiConfig.textFieldBackgroundColor,
                                borderWidth: 1.0)
            loginEmailTextField.placeholder = viewModel.emailField
            loginEmailTextField.clipsToBounds = true
        }
        
        if let loginUpButton = signUpScreen.loginUpButton {
            //signUpButton.setTitle(viewModel.signUpString, for: .normal)
            loginUpButton.addTarget(self, action: #selector(didTapLoginUpButton), for: .touchUpInside)
            loginUpButton.configure(color: uiConfig.logoTintColor,
                                   font: uiConfig.signUpButtonFont,
                                   cornerRadius: Constants.cornerRadius,
                                   borderColor: uiConfig.logoTintColor,
                                   backgroundColor: .white,
                                   borderWidth: 1.0)
        }
    }
    
    private func validate(_ input:ATCTextField) -> Bool{
        var valid = true
        
        switch input {
        case signUpScreen.nameTextField, signUpScreen.addressTextField, signUpScreen.phoneNumberTextField:
            valid = !(input.text?.isEmpty ?? true)
        case signUpScreen.loginEmailTextField, signUpScreen.emailTextField:
            valid = isValidEmail(input.text ?? "")
        default:
            valid = true
        }
        
        if !valid{
            input.layer.borderColor = UIColor.red.cgColor
        }else{
            input.layer.borderColor = UIColor.colorPrimary.cgColor
        }
        
        return valid
    }

    @objc func didTapLoginUpButton() {
        
        if
            validate(signUpScreen.loginEmailTextField)
        {
            
            let email = signUpScreen.loginEmailTextField.text!
            
            self.showProgress(true)
            
            EsoAPIProvider.loginUser(email: email, completion: { success in
                if success {
                    self.delegate?.signUpManagerDidCompleteLoginUp(self)
                } else {
                    self.showLoginUpError()
                }
                
                self.showProgress(false)
                
            }, failure: { (errCode, errDesc) in
                
                self.showProgress(false)
                
                if let vu = self.signUpScreen as? ATCClassicSignUpViewController{
                    AlertHelper.showError(view: vu, error: errCode, message: errDesc)
                }
            })
            
        }else{
            showSignUpError()
        }
    }
    @objc func didTapSignUpButton() {
        
        if
            validate(signUpScreen.nameTextField)
            && validate(signUpScreen.addressTextField)
            //&& validate(signUpScreen.phoneNumberTextField)
            && validate(signUpScreen.emailTextField)
        {
            
            let email = signUpScreen.emailTextField.text!
            let name = signUpScreen.nameTextField.text!
            let address = signUpScreen.addressTextField.text!
            let phone = signUpScreen.phoneNumberTextField.text!
            
            
            self.showProgress(true)
            
            EsoAPIProvider.registerUser(name: name, address: address, email: email, phone: phone, completion: { token in
                if let token = token {
                    Prefs.userToken = token
                    self.delegate?.signUpManagerDidCompleteSignUp(self)
                } else {
                    self.showSignUpError()
                }
                
                self.showProgress(false)
                
            }, failure: { (errCode, errDesc) in
                
                self.showProgress(false)
                
                if let vu = self.signUpScreen as? ATCClassicSignUpViewController{
                    AlertHelper.showError(view: vu, error: errCode, message: errDesc)
                }
            })
            
        }else{
            showSignUpError()
        }
        
    }
    
    func showProgress(_ show:Bool) {
        self.signUpScreen.signUpButton.isEnabled = !show
        self.signUpScreen.loginUpButton.isEnabled = !show
        self.signUpScreen.spinner.isHidden = !show
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }

    fileprivate func showSignUpError() {
        let alert = UIAlertController(title: "Registracija nesėkminga. Patikrinkite visus duomenų laukelius ir bandykite iš naujo.", message: "", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.signUpScreen.display(alertController: alert)
    }
    
    fileprivate func showLoginUpError() {
        let alert = UIAlertController(title: "Prisijungimas nesėkmingas. Patikrinkite visus duomenų laukelius ir bandykite iš naujo.", message: "", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.signUpScreen.display(alertController: alert)
    }
}
