//
//  ConfirmationViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-17.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit
import MessageUI

class ConfirmationViewController: UIViewController {

    @IBOutlet weak var contentView: UIView!

    @IBOutlet weak var continueBtn: BaseButton!
    @IBOutlet weak var imageView: UIImageView!

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    @IBAction func onContinue(_ sender: Any) {
        ATCHostViewController.instance?.presentLoggedInViewControllers()
    }
    
    @IBAction func noMessageTapped(_ sender: Any) {
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients(["vuapp@eso.lt"])
            mail.setSubject("Negavau pranešimo")

            present(mail, animated: true)
        } else {
            let dialogMessage = UIAlertController(title: "Pagalba", message: "Jūsų telefone nesukonfiguruota pašto programėlė, tad prašome siųsti laišką į vuapp@eso.lt", preferredStyle: .alert)

            let ok = UIAlertAction(title: "Gerai", style: .default)
            dialogMessage.addAction(ok)
            self.present(dialogMessage, animated: true, completion: nil)
        }
    }
}

extension ConfirmationViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
}

extension UINavigationController {
    func fadeTo(_ viewController: UIViewController) {
        let transition: CATransition = CATransition()
        transition.duration = 0.3
        transition.type = .fade
        view.layer.add(transition, forKey: nil)
        pushViewController(viewController, animated: false)
    }
}

