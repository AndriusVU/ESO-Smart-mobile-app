//
//  FarePlansViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-19.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit


enum Timezone: String {
    case one = "Vienos laiko zonos"
    case two = "Dviejų laiko zonų"
    case three = "Keturių laiko zonų"
}

class FarePlansViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var pickerView: UIPickerView!

    var selectedPlan: Plan?

    var plans: [Plan]?
    var countedStadardPrice: Double?

    @IBOutlet weak var pickerContentBottom: NSLayoutConstraint!

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 90

        pickerView.dataSource = self
        pickerView.delegate = self

        title = "Tarifų planai"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        
        pickerContentBottom.constant = -280


        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSSSSS"
        dateFormatter.locale = Locale(identifier: "lt_LT")
        
        EsoAPIProvider.getPlans { (planItems) in
            if let items = planItems?.items{
                self.plans = items
                self.tableView.reloadData()
            }
            
        } failure: { (errCode, errDesc) in
            AlertHelper.showError(view: self, error: errCode, message: errDesc)
        }
    }

    @IBAction func toliauButtonTapped(_ sender: Any) {
        let selected = pickerView.selectedRow(inComponent: 0)
        if let selectedPlan = selectedPlan, let zone = selectedPlan.zones?[selected]{
            Prefs.userPlan = UserPlan(plan: selectedPlan, zone: zone)
            let viewController = FareViewController(nibName: "FareViewController", bundle: nil)
            navigationController?.setViewControllers([viewController], animated: false)
        } 

    }

}
extension FarePlansViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return plans?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "FarePlansCell")
        cell.textLabel?.font = UIFont(name: "Avenir", size: 18)!
        cell.detailTextLabel?.textColor = .gray
        cell.selectionStyle = .none

        if let plan = plans?[indexPath.row] {
            if let iconUrl = plan.icon {
                if let url = URL(string: EsoAPI.imageUrlBase + iconUrl){
                    do{
                        let data = try Data(contentsOf: url)
                        cell.imageView?.image = UIImage(data: data)
                        cell.imageView?.contentMode = .scaleAspectFit
                        
                    }catch{
                        print(error)
                    }
                }
                


                let itemSize = CGSize.init(width: 40, height: 40)
                UIGraphicsBeginImageContextWithOptions(itemSize, false, UIScreen.main.scale);
                let imageRect = CGRect.init(origin: CGPoint.zero, size: itemSize)
                cell.imageView?.image!.draw(in: imageRect)
                cell.imageView?.image! = UIGraphicsGetImageFromCurrentImageContext()!;
                UIGraphicsEndImageContext();
            }
            cell.textLabel?.text = plan.title
            
            if let date_from = plan.date_from{
                cell.detailTextLabel?.text = "Atnaujinta: " + date_from.getDateOnly()
            }

        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.visibleCells.forEach { cell in
            cell.accessoryType = .none
        }
        tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        
        selectedPlan = plans?[indexPath.row]
        pickerView.reloadAllComponents()

        UIView.animate(withDuration: 0.5) {
            self.pickerContentBottom.constant = 0
            self.view.layoutIfNeeded()
        }

    }
}

extension FarePlansViewController: UIPickerViewDataSource, UIPickerViewDelegate {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return selectedPlan?.zones?.count ?? 0
    }

    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        var label: UILabel
        if let view = view as? UILabel {
            label = view
        } else { label = UILabel() }

        label.font = UIFont(name: "Avenir",size: 22)!
        label.textAlignment = .center

        label.text = selectedPlan?.zones?[row].title
        return label
    }

    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 80
    }
}

