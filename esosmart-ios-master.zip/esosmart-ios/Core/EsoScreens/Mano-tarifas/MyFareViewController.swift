//
//  MyFareViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-19.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit

class MyFareViewController: UIViewController{

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(MyFareTableViewCell.self, forCellReuseIdentifier: MyFareTableViewCell.identifier)
        tableView.register(MyFareTableViewCellSplit.self, forCellReuseIdentifier: MyFareTableViewCellSplit.identifier)
        tableView.delegate = self
        tableView.dataSource = self
        //tableView.rowHeight = 90
        
        tableView.separatorStyle = .none
        
        title = "Mano tarifas"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
    }
}

extension MyFareViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 1{
            return 40
        }
        return 90
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 1 {
            if let cell = tableView.dequeueReusableCell(withIdentifier: MyFareTableViewCellSplit.identifier, for: indexPath) as? MyFareTableViewCellSplit {
                
                cell.textLabel?.text = "arba"
                cell.textLabel?.textAlignment = .center
                cell.textLabel?.textColor =  UIColor.colorPrimaryDark
                
                return cell
            }
        }else{
            if let cell = tableView.dequeueReusableCell(withIdentifier: MyFareTableViewCell.identifier, for: indexPath) as? MyFareTableViewCell {
                cell.selectionStyle = .none
                if indexPath.row == 0 {
                    cell.imageView?.image = UIImage.localImage("hand")
                    cell.textLabel?.text = "Pasirinkite savo elektros tarifų planą"
                } else if indexPath.row == 2 {
                    cell.imageView?.image = UIImage.localImage("pen")
                    cell.textLabel?.text = "Įveskite jums taikomą tarifą"
                }
                return cell
            }
        }
        

        return UITableViewCell()
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            let viewController = FarePlansViewController(nibName: "FarePlansViewController", bundle: nil)
            self.navigationController?.pushViewController(viewController, animated: true)
        } else if indexPath.row == 2 {
            let viewController = EnterPriceViewController(nibName: "EnterPriceViewController", bundle: nil)
            self.navigationController?.pushViewController(viewController, animated: true)
        }
    }
}
