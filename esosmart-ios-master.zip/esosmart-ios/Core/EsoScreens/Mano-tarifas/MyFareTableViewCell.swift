//
//  MyFareTableViewCell.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-19.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit

class MyFareTableViewCell: UITableViewCell {

    @IBOutlet weak var iconImageView: UIImageView!
    static let identifier = "MyFareTableViewCell"

    override func awakeFromNib() {
        

    }

}
