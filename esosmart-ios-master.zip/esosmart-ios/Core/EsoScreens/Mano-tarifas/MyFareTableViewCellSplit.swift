//
//  MyFareTableViewCellSplit.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-09-29.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit

class MyFareTableViewCellSplit: UITableViewCell {

    @IBOutlet weak var iconImageView: UIImageView!
    static let identifier = "MyFareTableViewCellSplit"

    override func awakeFromNib() {
        

    }

}
