//
//  ChartValueFormatter.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-19.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation
import Charts

class TimeValueFormatter: NSObject {
    private let dateFormatter = DateFormatter()
}

extension TimeValueFormatter: IAxisValueFormatter {

    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        let integer = Int(value)
        if integer == 24 {
            return "\(integer):00         ."
        } else if integer == 0 {
            return "00:00"
        } else if integer < 10 {
            return "0\(integer):00"
        } else {
            return "\(integer):00"
        }
    }
}

class NegativeValueFormatter: NSObject {
}

extension NegativeValueFormatter: IAxisValueFormatter {

    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return String(format: "%0.2f", abs(value))
    }

}
