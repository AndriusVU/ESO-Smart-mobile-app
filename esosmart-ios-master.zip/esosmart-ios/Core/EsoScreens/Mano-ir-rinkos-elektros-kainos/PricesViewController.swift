//
//  PricesViewController.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-19.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit
import Charts

class PricesViewController: UIViewController {

    private let ITEM_COUNT = 24
    @IBOutlet weak var dedLabel: UILabel!
    @IBOutlet var moreButton: UIButton!
    @IBOutlet weak var chartView: CombinedChartView!

    var chartPrices: [EnergyPrice] = []
    
    override func viewDidAppear(_ animated: Bool) {
        if let zone = Prefs.userPlan?.zone{
            setLineData(zone)
            dedLabel.isHidden = false
            dedLabel.text = String(format: "Jūsų pastovioji dedamoji %.2f Eur/mėn", arguments: [zone.getDedPrice()])
        }else{
            
            dedLabel.isHidden = true
            
            //let viewController = MyFareViewController(nibName: "MyFareViewController", bundle: nil)
            //navigationController?.pushViewController(viewController, animated: true)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Mano ir rinkos elektros kainos"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)

        moreButton.configure(color: UIColor(hexString: "#B4CC01"),
                             font: UIFont(name: "Avenir-heavy", size: 16)!,
                             cornerRadius: moreButton.frame.size.height/2,
                             borderColor: UIColor(hexString: "#B4CC01"),
                             backgroundColor: .white,
                             borderWidth: 1.0)

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSSSSS"
        dateFormatter.locale = Locale(identifier: "lt_LT")
        
        
        EsoAPIProvider.getPrices { (priceItems) in
            
            if let priceItems = priceItems{
                self.chartPrices = priceItems.items
                self.setChartData()
            }
        } failure: { (errCode, errDesc) in
            AlertHelper.showError(view: self, error: errCode, message: errDesc)
        }
    }

    var myPrice: Double = 0

    func setChartData() {
        let data = CombinedChartData()
        data.barData = generateBarData()

        chartView.xAxis.axisMaximum = data.xMax + 0.25
        chartView.leftAxis.axisMaximum = data.yMax + data.yMax / 10

        chartView.data = data
        chartView.doubleTapToZoomEnabled = false
        chartView.pinchZoomEnabled = false

        let xAxis = chartView.xAxis
        xAxis.labelPosition = .bottom
        xAxis.labelFont = UIFont.systemFont(ofSize: 10)
        xAxis.drawAxisLineEnabled = true
        xAxis.drawGridLinesEnabled = false
        xAxis.granularityEnabled = true
        xAxis.granularity = 1
        xAxis.labelCount = 6
        xAxis.axisMinimum = 0
        xAxis.axisMaximum = 24
        xAxis.valueFormatter = TimeValueFormatter()

        let leftAxis = chartView.leftAxis
        leftAxis.labelFont = UIFont.systemFont(ofSize: 10)
        leftAxis.drawAxisLineEnabled = true
        leftAxis.drawGridLinesEnabled = true
        leftAxis.axisMinimum = 0
        leftAxis.axisMaximum = 24
        chartView.rightAxis.enabled = false

        let l = chartView.legend
        l.font = UIFont.systemFont(ofSize: 10)
        l.wordWrapEnabled = true
        l.horizontalAlignment = .center
        l.verticalAlignment = .bottom
        l.orientation = .vertical
        l.drawInside = false
        
        if let zone = Prefs.userPlan?.zone{
            setLineData(zone)
        }else{
            
        }
        chartView.notifyDataSetChanged()
    }

    func setLineData(_ zone: Zone) {
        
        guard let data = chartView.data as? CombinedChartData else {
            return
        }
        
        var entries:[ChartDataEntry] = []
        for (index, chartPrice) in chartPrices.enumerated(){
            
            if(index == 0){
                entries.append(
                    ChartDataEntry(x: Double(-1) + 0.5, y: zone.getPriceByDate(date: DateHelper.strToDate(chartPrice.date_from)))
                )
            }
        
            
            entries.append(
                ChartDataEntry(x: Double(index) + 0.5, y: zone.getPriceByDate(date: DateHelper.strToDate(chartPrice.date_from)))
            )
            
            if(index == 23){
                entries.append(
                    ChartDataEntry(x: Double(24) + 0.5, y: zone.getPriceByDate(date: DateHelper.strToDate(chartPrice.date_from)))
                )
            }
        }
        
        
//        let entries = (0..<ITEM_COUNT).map { (i) -> ChartDataEntry in
//            return ChartDataEntry(x: Double(i) + 0.5, y: zone.getPriceByTime(time: i))
//        }

        let set = LineChartDataSet(entries: entries, label: "Mano tarifas")
        set.setColor(UIColor(hexString: "#EEA30C"))
        set.lineWidth = 2.5
        set.setCircleColor(UIColor(hexString: "#EEA30C"))
        set.circleRadius = 1
        set.circleHoleRadius = 2.5
        set.fillColor = UIColor(hexString: "#EEA30C")
        set.mode = .linear
        set.drawValuesEnabled = false
        set.valueFont = UIFont(name: "Avenir", size: 14)!
        set.valueTextColor = UIColor(hexString: "#EEA30C")
        set.highlightEnabled = false

        set.axisDependency = .left
        
        data.lineData = LineChartData(dataSet: set)
        chartView.data = data
        chartView.notifyDataSetChanged()
    }

    func generateBarData() -> BarChartData {
        /*
        let entries = (0..<ITEM_COUNT).map { (i) -> BarChartDataEntry in
            return BarChartDataEntry(x: Double(i) + 0.5, yValues: [chartPrices[i].transferPrice ?? 0, chartPrices[i].price ?? 0])
        }
        */
        
        var entries:[BarChartDataEntry] = []
        
        for (index, chartPrice) in chartPrices.enumerated(){
            entries.append(
                BarChartDataEntry(x: Double(index)+0.5, yValues: [chartPrice.transfer_distribution_price ?? 0, chartPrice.price ?? 0])
            )
        }
        

        let set = BarChartDataSet(entries: entries, label: "")
        set.stackLabels = ["Elektros perdavimo ir skirstymo ir sisteminių paslaugų kaina", "Šios dienos elektros rinkos kaina su PVM"]
        set.colors = [UIColor(hexString: "#3E93C6"),
                       UIColor(hexString: "#44B69F")
        ]
        set.axisDependency = .left
        set.drawValuesEnabled = false
        set.highlightEnabled = false

        let data = BarChartData(dataSet: set)
        data.barWidth = 0.8

        return data
    }

    @IBAction func linkTapped(_ sender: Any) {
        if let url = URL(string: "https://www.vert.lt/Puslapiai/default.aspx") {
            UIApplication.shared.open(url)
        }
    }

    private func getStandartinisData(callback: @escaping (Double)->Void) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSSSSS"
        dateFormatter.locale = Locale(identifier: "lt_LT")

//        EsoAPIProvider.getPlans() { items in
//            if let items = items {
//                for item in items {
//                    if let item = item as? [String: Any],
//                        let title = item["title"] as? String,
//                        title == "Standartinis" {
//                            if let zones = item["zones"] as? [Any] {
//                                for zone in zones {
//                                if let zone = zone as? [String: Any],
//                                    let zoneTitle = zone["title"] as? String,
//                                    zoneTitle == "Vienos laiko zonos" {
//                                        if let prices = zone["prices"] as? [Any] {
//                                            for price in prices {
//                                                if let price = price as? [String: Any],
//                                                    let priceTitle = price["title"] as? String,
//                                                    priceTitle == "Vienos laiko zonos energijos dedamoji",
//                                                    let value = price["price"] as? Double {
//                                                        callback(value)
//                                                    }
//                                            }
//                                    }
//                                    }
//                                }
//                        }
//                    }
//                }
//            }
//        }
    }

}

