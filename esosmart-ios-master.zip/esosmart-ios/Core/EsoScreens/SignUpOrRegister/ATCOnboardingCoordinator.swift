//
//  ATCOnboardingCoordinator.swift
//  DashboardApp
//
//  Created by Florian Marcu on 8/8/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit
var userLoggedIn = false

protocol ATCOnboardingCoordinatorDelegate: class {
    func coordinatorDidCompleteOnboarding(_ coordinator: ATCOnboardingCoordinatorProtocol, user: ATCUser?)
}

protocol ATCOnboardingCoordinatorProtocol: ATCLandingScreenManagerDelegate {
    func viewController() -> UIViewController
    var delegate: ATCOnboardingCoordinatorDelegate? {get set}
}

class ATCClassicOnboardingCoordinator: ATCOnboardingCoordinatorProtocol, ATCLoginScreenManagerDelegate, ATCSignUpScreenManagerDelegate {
    weak var delegate: ATCOnboardingCoordinatorDelegate?

    let landingManager: ATCLandingScreenManager
    let landingScreen: ATCClassicLandingScreenViewController

    let signUpManager: ATCSignUpScreenManager
    let signUpScreen: ATCClassicSignUpViewController

    lazy var confirmationViewController: ConfirmationViewController = {
        return ConfirmationViewController(nibName: "ConfirmationViewController", bundle: nil)
    }()
    
    lazy var loginConfirmationViewController: LoginConfirmationViewController = {
        return LoginConfirmationViewController(nibName: "LoginConfirmationViewController", bundle: nil)
    }()

    let navigationController: UINavigationController

    let serverConfig: ATCOnboardingServerConfigurationProtocol

    init(landingViewModel: ATCLandingScreenViewModel,
         loginViewModel: ATCLoginScreenViewModel,
         signUpViewModel: ATCSignUpScreenViewModel,
         uiConfig: ATCOnboardingConfigurationProtocol,
         serverConfig: ATCOnboardingServerConfigurationProtocol) {
        self.serverConfig = serverConfig
        self.landingScreen = ATCClassicLandingScreenViewController(nibName: "ATCClassicLandingScreenViewController", bundle: nil)
        self.landingManager = ATCLandingScreenManager(landingScreen: self.landingScreen, viewModel: landingViewModel, uiConfig: uiConfig)
        self.landingScreen.delegate = landingManager



        self.signUpScreen = ATCClassicSignUpViewController(nibName: "ATCClassicSignUpViewController", bundle: nil)
        self.signUpManager = ATCSignUpScreenManager(signUpScreen: self.signUpScreen, viewModel: signUpViewModel, uiConfig: uiConfig, serverConfig: serverConfig)
        self.signUpScreen.delegate = signUpManager

        self.navigationController = UINavigationController(rootViewController: landingScreen)

        self.landingManager.delegate = self
        self.signUpManager.delegate = self
    }

    func viewController() -> UIViewController {
        return navigationController
    }

    //apatinis mygtukas
    func landingScreenManagerDidTapLogIn(manager: ATCLandingScreenManager) {
        //Rodom bazine info be logino
        self.delegate?.coordinatorDidCompleteOnboarding(self, user: nil)
    }

    // Virsutinis mygtukas
    func landingScreenManagerDidTapSignUp(manager: ATCLandingScreenManager) {
        if let token = Prefs.userToken {
//            EsoAPIProvider.authorise(token: token) { user in
                
                
                
                //TODO: pakeisti i confirmed
//                if let confirmed = user?["confirmed"] as? Bool, confirmed {
//                    self.delegate?.coordinatorDidCompleteOnboarding(self, user: nil)
//                    UserDefaults.standard.set(true, forKey: "userLoggedIn")
//                    userLoggedIn = true
//                } else {
//                    let dialogMessage = UIAlertController(title: "Prisijungimas negalimas", message: "Prašome palaukti, kol būsite patvirtintas sistemos administratoriaus", preferredStyle: .alert)
//
//                    let ok = UIAlertAction(title: "Gerai", style: .default)
//                    dialogMessage.addAction(ok)
//
//                    self.navigationController.present(dialogMessage, animated: true, completion: nil)
//                }
//            }
        } else {
            self.navigationController.pushViewController(self.signUpScreen, animated: true)
        }
    }

    func loginManagerDidCompleteLogin(_ loginManager: ATCLoginScreenManager, user: ATCUser?) {
        self.delegate?.coordinatorDidCompleteOnboarding(self, user: user)
    }

    func signUpManagerDidCompleteSignUp(_ signUpManager: ATCSignUpScreenManager) {
        self.navigationController.fadeTo(self.confirmationViewController)

    }
    func signUpManagerDidCompleteLoginUp(_ signUpManager: ATCSignUpScreenManager) {
        self.navigationController.pushViewController(self.loginConfirmationViewController, animated: true)
    }
}
