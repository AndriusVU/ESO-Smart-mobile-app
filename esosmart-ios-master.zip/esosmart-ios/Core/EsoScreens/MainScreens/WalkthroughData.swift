import UIKit

class WalkthroughData {
    static let walkthroughs = [
        ATCWalkthroughModel(title: "ESO Smart",
                            subtitle: "Vilniaus Universitetas (VU) ir „Energijos skirstymo operatorius“ (ESO) atlieka mokslinį tyrimą, kurio tikslas pasiūlyti klientams lengvai prieinamą informaciją apie elektros energijos suvartojimą ir taip prisidėti prie energetinio efektyvumo gerinimo. Kviečiame išbandyti programėlę.",
                            icon: "vu", iconSecond: "eso-ismanieji-logo"),
        ATCWalkthroughModel(title: "Stebėkite savo elektros suvartojimą",
                            subtitle: "Jeigu Jūsų skaitiklio rodmenys yra nuskaitomi automatiniu būdu, galėsite stebėti savo valandinį elektros energijos suvartojimą.",
                            icon: "lamp"),
        ATCWalkthroughModel(title: "Susipažinkite, kas sudaro elektros energijos kainą ir palyginkite savo kainą su rinkos",
                            subtitle: "Stebėkite rinkos kainos pokyčius.",
                            icon: "bar-chart"),
        ATCWalkthroughModel(title: "Stebėkite elektros energijos suvartojimą ir gamybą Lietuvoje",
                            subtitle: "Programėlėje rasite šiai dienai suprognozuotus nacionalinius valandinius elektros energijos gamybos ir suvartojimo duomenis.",
                            icon: "options"),
        ]
}
