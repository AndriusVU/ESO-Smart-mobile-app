//
//  ATCDashboardHostViewController.swift
//  DashboardApp
//
//  Created by Florian Marcu on 7/28/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCDashboardHostViewController: UIViewController, UITabBarControllerDelegate {

    let uiConfig: ATCDashboardConfigurationProtocol
    let serverConfig: ATCOnboardingServerConfigurationProtocol

    let notificationsVC: NotificationsViewController = NotificationsViewController(nibName: "NotificationsViewController", bundle: nil)

    init(uiConfig: ATCDashboardConfigurationProtocol, serverConfig: ATCOnboardingServerConfigurationProtocol) {
        self.uiConfig = uiConfig
        self.serverConfig = serverConfig
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //Prefs.userToken = "d97ab0bd96181696bb7c25476b756d0b"
        //Prefs.userToken = nil
        //Prefs.confirmationHash = "111"
        
        checkData()
        
    }
    
    func checkData() {
        if let confirmationHash = Prefs.confirmationHash{
            Prefs.confirmationHash = nil
            
            EsoAPIProvider.confirmUser(hash: confirmationHash, completion: { registerData in
                if let registerData = registerData{
                    Prefs.userToken = registerData.token
                    self.checkData()
                }else{
                    self.initView()
                }
                
            }, failure: {(errCode, errDesc) in
                AlertHelper.showError(view: self, error: errCode, message: errDesc)
                self.initView()
            })
            
            
        }else if let token = Prefs.userToken{
            
            EsoAPIProvider.authorise(token: token) { (user) in
                if let userData = user{
                    Prefs.userData = userData
                }else{
                    Prefs.clearData()
                }
                self.initView()
            } failure: { (errCode, errDesc) in
                AlertHelper.showError(view: self, error: errCode, message: errDesc)
                if(errCode == 404){
                    Prefs.clearData()
                }
                self.initView()
            }
        }else{
            initView()
        }
    }
    
    func initView() {
        let hostController = self.getHostViewController(Prefs.userData)
        hostController.view.backgroundColor = self.uiConfig.mainThemeBackgroundColor
        self.addChildViewControllerWithView(hostController)
        
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return uiConfig.statusBarStyle
    }

    fileprivate func onboardingCoordinator(uiConfig: ATCDashboardConfigurationProtocol, serverConfig: ATCOnboardingServerConfigurationProtocol) -> ATCOnboardingCoordinatorProtocol {
        let landingViewModel = ATCLandingScreenViewModel(imageIcon: "analytics",
                                                         title: "ESO Smart",
                                                         subtitle: "Nemokamai stebėkite elektros rinkos kainas ir nacionalinius elektros gamybos bei suvartojimo duomenis. Jei jūsų senasis elektros skaitiklis yra pakeistas automatizuotu elektros skaitikliu, užsiregistravę, jūs galėsite nemokamai stebėti savo valandinį elektros suvartojimą ir tapti išmaniu elektros vartotoju. Prisiregistravę ir sutikę naudotis pilotinės programėlės versija, gausite dovanėlę.",
                                                         loginString: "Prisijungti (neturintiems skaitmenizuoto skaitliuko)",
                                                         signUpString: "Registruotis (turintiems skaitmenizuota skaitliuką)")

        let loginViewModel = ATCLoginScreenViewModel(contactPointField: "E-mail or phone number",
                                                     passwordField: "Password",
                                                     title: "Sign In",
                                                     loginString: "Log In",
                                                     facebookString: "Facebook Login",
                                                     separatorString: "OR")

        let signUpViewModel = ATCSignUpScreenViewModel(nameField: "Vardas, Pavardė",
                                                       addressField: "Objekto adresas",
                                                       phoneField: "Tel. numeris",
                                                       emailField: "El. paštas (kaip nurodyta ESO sutartyje)",
                                                       title: "Susikurkite savo paskyrą",
                                                       subTitle: "Prisijungti ir matyti informaciją apie nurodytą objektą gali tik objekto savininkas",
                                                       signUpString: "Registruotis")

        return ATCClassicOnboardingCoordinator(landingViewModel: landingViewModel,
                                               loginViewModel: loginViewModel,
                                               signUpViewModel: signUpViewModel,
                                               uiConfig: DashboardOnboardingUIConfig(config: uiConfig),
                                               serverConfig: serverConfig)
    }

    fileprivate func walkthroughVC(uiConfig: ATCDashboardConfigurationProtocol) -> ATCWalkthroughViewController {
        let viewControllers = WalkthroughData.walkthroughs.map { ATCClassicWalkthroughViewController(model: $0, uiConfig: uiConfig, nibName: "ATCClassicWalkthroughViewController", bundle: nil) }
        return ATCWalkthroughViewController(nibName: "ATCWalkthroughViewController",
                                            bundle: nil,
                                            viewControllers: viewControllers,
                                            uiConfig: uiConfig)
    }

    func getHostViewController(_ userData: UserData? = nil) -> ATCHostViewController {
        let menuConfiguration = ATCMenuConfiguration(user: nil,
                                                 cellClass: ATCCircledIconMenuCollectionViewCell.self,
                                                 headerHeight: 0,
                                                 items: getMenu(userData),
                                                 uiConfig: ATCMenuUIConfiguration(itemFont: uiConfig.regularSemiLargeFont,
                                                                                  tintColor: uiConfig.mainTextColor,
                                                                                  itemHeight: 75.0,
                                                                                  backgroundColor: uiConfig.mainThemeBackgroundColor))

        let config = ATCHostConfiguration(menuConfiguration: menuConfiguration,
                                          style: .sideBar,
                                          topNavigationRightViews: nil,
                                          topNavigationLeftImage: UIImage.localImage("three-equal-lines-icon", template: true),
                                          topNavigationTintColor: .white,
                                          statusBarStyle: uiConfig.statusBarStyle,
                                          uiConfig: uiConfig)

        if userData != nil {
            return ATCHostViewController(configuration: config, onboardingCoordinator: nil, walkthroughVC: nil)
        } else {
            let onboardingCoordinator = self.onboardingCoordinator(uiConfig: uiConfig, serverConfig: serverConfig)
            let walkthroughVC = self.walkthroughVC(uiConfig: uiConfig)
            return ATCHostViewController(configuration: config, onboardingCoordinator: onboardingCoordinator, walkthroughVC: walkthroughVC, profilePresenter: nil)
        }
    }

    func getMenu(_ userData:UserData? = nil) -> [ATCNavigationItem] {
        
        
        var menu:[ATCNavigationItem] = []
        
        menu.append(ATCNavigationItem(title: "Mano ir rinkos elektros kainos",
                                      viewController: PricesViewController(nibName: "PricesViewController", bundle: nil),
                                      image: UIImage.localImage("pie-chart", template: true),
                                      type: .viewController))
        
        menu.append(ATCNavigationItem(title: "Mano tarifas",
                              viewController: FareViewController(nibName: "FareViewController", bundle: nil),
                              image: UIImage.localImage("graph", template: true),
                              type: .viewController,
                              leftTopViews: nil,
                              rightTopViews: nil))

        menu.append(ATCNavigationItem(title: "Elektros gamyba ir suvartojimas",
                                      viewController: ForecastTabController(),
                                      image: UIImage.localImage("graph-arrow", template: true),
                                      type: .viewController))
        
        if let userData = userData{
            
            if(userData.isV1() || userData.isV2()){
                menu.append(ATCNavigationItem(title: "Mano suvartojama elektros energija",
                                      viewController: MyUsageTabController(),
                                      image: UIImage.localImage("bulb", template: true),
                                      type: .viewController))

            }
            
            if(userData.confirmed){
                menu.append(ATCNavigationItem(title: "Pranešimai",
                                              viewController: notificationsVC,
                                              image: UIImage.localImage("bell-filled", template: true),
                                              type: .viewController))
            }
            menu.append(ATCNavigationItem(title: "Pagalba",
                                          viewController: UIViewController(),
                                          image: UIImage.localImage("question", template: true),
                                          type: .email))
            
            menu.append(ATCNavigationItem(title: "Ištrinti paskyrą",
                                          viewController: UIViewController(),
                                          image: UIImage.localImage("times", template: true),
                                          type: .delete))
        }else{
            menu.append(ATCNavigationItem(title: "Pagalba",
                                          viewController: UIViewController(),
                                          image: UIImage.localImage("question", template: true),
                                          type: .email))
            menu.append(ATCNavigationItem(title: "Atsijungti",
                                  viewController: UIViewController(),
                                  image: UIImage.localImage("off", template: true),
                                  type: .logout))
        }
        
        return menu;
    }
}

