//
//  ATCImage.swift
//  ListingApp
//
//  Created by Florian Marcu on 6/10/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class ATCImage: ATCGenericBaseModel {

    var urlString: String?

    convenience init(_ urlString: String? = nil) {
        self.init(jsonDict: [:])
        self.urlString = urlString
    }

    required init(jsonDict: [String: Any]) {}

    var description: String {
        return urlString ?? ""
    }
}
