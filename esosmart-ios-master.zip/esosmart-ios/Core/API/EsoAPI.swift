//
//  EsoAPI.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-24.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation
import Moya

enum EsoAPI {
    static private let publicKey = "YOUR PUBLIC KEY"
    static private let privateKey = "YOUR PRIVATE KEY"
    static public let imageUrlBase = "https://vuapp.eso.lt"

    case register(first_name: String, last_name:String, email: String, phone: String?, address: String?)
    case login(email: String)
    case confirm(hash: String)
    case auth(token: String)
    case plans
    case prices
    case tariffs
    case deleteUser(token: String)
    case notifications(token: String)
    case compare(token: String, period: UsagePeriod)
    case forecast(date: String)
    case historical
    case usage(token: String, period: UsagePeriod)
}

extension EsoAPI: TargetType {

  public var baseURL: URL {
    return URL(string: "https://vuapp.eso.lt/api/")!
    //return URL(string: "http://esosmart.evin.kryptis.lt/api/")!
  }

  // 2
  public var path: String {
    switch self {
    case .register: return "users/register"
    case .login: return "users/login"
    case .confirm: return "users/confirm"
    case .auth: return "users/auth"
    case .plans: return "energy/plans"
    case .prices: return "energy/prices"
    case .tariffs: return "enery/tariffs"
    case .deleteUser: return "users/delete"
    case .notifications: return "users/messages"
    case .compare: return "users/compare"
    case .forecast: return "energy/usage"
    case .historical: return "energy/historical"
    case .usage: return "users/energy"
    }
  }

  // 3
  public var method: Moya.Method {
    switch self {
    case .register: return .post
    case .auth: return .post
    case .plans: return .post
    case .deleteUser: return .post
    case .notifications: return .get
    case .prices: return .get
    case .tariffs: return .get
    case .compare: return .post
    case .forecast: return .get
    case .historical: return .get
    case .usage: return .post
    case .login: return .post
    case .confirm: return .post
    }
  }

  // 4
  public var sampleData: Data {
    return Data()
  }

  // 5
  public var task: Task {
    switch  self {
    case .register(let first_name, let last_name, let email, let phone, let address):
        return .requestParameters(parameters: [
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
                "phone": phone ?? "",
                "object_address": address ?? ""],
            encoding: URLEncoding.queryString)
    case .login(let email):
        return .requestParameters(parameters: ["email": email], encoding: URLEncoding.queryString)
    case .confirm(let hash):
        return .requestParameters(parameters: ["hash": hash], encoding: URLEncoding.queryString)
    case .auth(let token):
        return .requestParameters(parameters: ["token": token], encoding: URLEncoding.queryString)
    case .deleteUser(let token):
        return .requestParameters(parameters: ["token": token], encoding: URLEncoding.queryString)
    case .notifications(let token):
        return .requestParameters(parameters: ["token": token], encoding: URLEncoding.queryString)
    case .compare(let token, let period):
        return .requestParameters(parameters: ["token": token, "period": period.rawValue], encoding: URLEncoding.queryString)
    case .usage(let token, let period):
        return .requestParameters(parameters: ["token": token, "period": period.rawValue], encoding: URLEncoding.queryString)
    case .forecast(let date):
        return .requestParameters(parameters: ["date": date], encoding: URLEncoding.queryString)
    default:
        return .requestPlain
    }
  }

  // 6
  public var headers: [String: String]? {
    return ["Content-Type": "application/json"]
  }

  // 7
  public var validationType: ValidationType {
    return .successCodes
  }
}
