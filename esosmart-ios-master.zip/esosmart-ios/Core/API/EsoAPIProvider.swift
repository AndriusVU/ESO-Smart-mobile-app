//
//  EsoAPIProvider.swift
//  DashboardApp
//
//  Created by Rokas Firantas on 2020-07-24.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation
import Moya
import Result

class EsoAPIProvider {

    static let provider = MoyaProvider<EsoAPI>(plugins: [CachePolicyPlugin()])
    
    static private func validateResult(
        _ result:Result<Moya.Response, MoyaError>,
        _ failure: ((Int, String) -> ())? = nil,
        _ success_callback: (_ response: Moya.Response) throws ->(),
        _ failed_callback: () -> ()
    ){
        
        var rError:ErrorData? = nil
        
        switch result {
            case .success(let response):
                do{
                    rError = try response.map(ErrorData.self)
                }catch{
                    do {
                        try success_callback(response)
                        return
                    } catch {
                        rError = ErrorData(error: error.localizedDescription)
                    }
                }
                break
            case .failure(let error):
                if let r = error.response{
                    do{
                        rError = try r.map(ErrorData.self)
                    }catch{
                        //errorDescription = r.data
                    }
                }
                
                if rError == nil{
                    rError = ErrorData(error: error.errorDescription ?? "Nežinoma klaida", code: error.errorCode)
                }
                break
        }
        
        if let rError = rError, let failure = failure{
            failure(rError.code ?? 0, rError.error)
        }else{
            failed_callback()
        }
    }

    static func registerUser(name: String, address: String, email: String, phone: String,
                             completion: @escaping(String?) -> (), failure: ((Int, String) -> ())? = nil
    ) {
        
        let names = name.components(separatedBy: " ")
        provider.request(.register(first_name: names.first ?? name, last_name: names.last ?? name, email: email, phone: phone, address: address)){ result in
            
            validateResult(result, failure, {response in
                let registerData = try response.map(RegisterData.self)
                completion(registerData.token)
            }, {
                completion(nil)
            })
        }
    }
    static func loginUser(email: String, completion: @escaping(Bool) -> (), failure: ((Int, String) -> ())? = nil
    ) {
        
        provider.request(.login(email: email)){ result in
            
            validateResult(result, failure, {response in
                let loginData = try response.map(LoginData.self)
                completion(loginData.ok)
            }, {
                completion(false)
            })
        }
    }

    static func confirmUser(hash: String, completion: @escaping(RegisterData?) -> (), failure: ((Int, String) -> ())? = nil
    ) {
        
        provider.request(.confirm(hash: hash)){ result in
            
            validateResult(result, failure, {response in
                let registerData = try response.map(RegisterData.self)
                completion(registerData)
            }, {
                completion(nil)
            })
        }
    }

    static func authorise(token: String, completion: @escaping (UserData?) -> (), failure: ((Int, String) -> ())? = nil) {
        
        provider.request(.auth(token: token)) { (result) in
            
            validateResult(result, failure, {(response) in
                let user = try response.map(UserData.self)
                completion(user)
            }, {
                completion(nil)
            })
        }
    }

    static func getPlans(completion: @escaping (PlanItems?) -> (), failure: ((Int, String) -> ())? = nil) {
        provider.request(.plans) { (result) in
            validateResult(result, failure, {(response) in
                let data = try response.map(PlanItems.self)
                completion(data)
            }, {
                completion(nil)
            })
        }
    }

    static func getNotifications(token: String, completion: @escaping (Any?) -> (), failure: ((Int, String) -> ())? = nil) {
        provider.request(.notifications(token: token)) { (result) in
            
            validateResult(result, failure, {(response) in
                if let data = try response.mapJSON(failsOnEmptyData: true) as? [String: Any]{
                    completion(data["items"])
                }
                
            }, {
                completion(nil)
            })

        }
    }

    static func getPrices(completion: @escaping (EnergyPriceItems?) -> (), failure: ( (Int, String) -> ())? = nil) {
        
        provider.request(.prices) { (result) in
            
            validateResult(result, failure, {(response) in
                let data = try response.map(EnergyPriceItems.self)
                completion(data)
            }, {
                completion(nil)
            })

        }
    }

    //[[{"time":"00:00","forecast_usage":1120,"planned_production":564,"planned_production_wind":132}
    static func getForecast(completion: @escaping ([ForecastData]?) -> (), failure: ((Int, String) -> ())? = nil) {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let dateString = formatter.string(from: date)

        provider.request(.forecast(date:dateString)) { (result) in
            
            validateResult(result, failure, {(response) in
                let data = try response.map([ForecastData].self)
                completion(data)
            }, {
                completion(nil)
            })
        }
    }

    static func getHistorical(completion: @escaping ([HistoricalPrice]?) -> (), failure: ((Int, String) -> ())? = nil) {
        provider.request(.historical) { (result) in
            
            validateResult(result, failure, {(response) in
                let data = try response.map([HistoricalPrice].self)
                completion(data)
            }, {
                completion(nil)
            })
            
        }
    }

    static func getCompare(token: String, period: UsagePeriod, completion: @escaping (CompareData?) -> (), failure: ((Int, String) -> ())? = nil) {
        provider.request(.compare(token: token, period: period)) { (result) in
            
            validateResult(result, failure, {(response) in
                let data = try response.map(CompareData.self)
                completion(data)
            }, {
                completion(nil)
            })
            
        }
    }

    static func getUsage(token: String, period: UsagePeriod,
                         completion: @escaping ([UserUsage]?) -> (),
                         failure: ((Int, String) -> ())? = nil
    ) {
        provider.request(.usage(token: token, period: period)) { (result) in
            
            validateResult(result, failure, {(response) in
                let data = try response.map([UserUsage].self)
                completion(data)
            }, {
                completion(nil)
            })
        }
    }

    static func deleteUser(token: String, completion: @escaping (Bool) -> (), failure: ((Int, String) -> ())? = nil) {
        provider.request(.deleteUser(token: token)) { (result) in
            
            validateResult(result, failure, {(response) in
                completion(true)
            }, {
                completion(false)
            })
            
        }
    }
}

protocol CachePolicyGettable {
    var cachePolicy: URLRequest.CachePolicy { get }
}

final class CachePolicyPlugin: PluginType {
    public func prepare(_ request: URLRequest, target: TargetType) -> URLRequest {
        if let cachePolicyGettable = target as? CachePolicyGettable {
            var mutableRequest = request
            mutableRequest.cachePolicy = cachePolicyGettable.cachePolicy
            return mutableRequest
        }

        return request
    }
}

extension EsoAPI: CachePolicyGettable {
    var cachePolicy: URLRequest.CachePolicy {
        return .reloadIgnoringLocalAndRemoteCacheData
    }
}


