//
//  UserData.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-09-30.
//  Copyright © 2020 Instamobile. All rights reserved.
//

struct UserData:Codable {
    let id:Int
    let first_name:String?
    let last_name:String?
    let phone:String
    let email:String
    let object_address:String?
    let object_uid:String?
    let role: [String]
    let roles: [UserRole]
    let actived:Bool
    let confirmed:Bool
    
    func isV1() -> Bool {
        return role.contains(RoleType.V1.rawValue)
    }
    func isV2() -> Bool {
        return role.contains(RoleType.V2.rawValue)
    }
}

struct UserRole:Codable {
    let title:String
    let description:String
}

enum RoleType:String {
    case V0 = "v0"
    case V1 = "v1"
    case V2 = "v2"
    case V3 = "v3"
}
