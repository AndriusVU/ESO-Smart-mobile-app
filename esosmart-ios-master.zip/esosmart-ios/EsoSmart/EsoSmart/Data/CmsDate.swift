//
//  CmsDate.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-10-01.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation

struct CmsDate:Codable {
    let date:String
    
    
    
    func getDate() -> Date {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss.SSSSSS"
        dateFormatter.locale = Locale(identifier: "lt_LT")
        return dateFormatter.date(from: date) ?? Date()
    }
    
    func getDateOnly() -> String {
        return date.components(separatedBy: " ").first ?? "----"
    }
}
