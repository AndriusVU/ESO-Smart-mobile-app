//
//  EnergyPrice.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-10-01.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation

struct EnergyPriceItems:Codable {
    let items:[EnergyPrice]
}

struct EnergyPrice:Codable {
    //let id:Int
    let date_from:String
    //let date_to:String
    let price:Double
    let transfer_distribution_price:Double
}

struct UserUsage:Codable{
    let time:String
    let consumed:Double
    let supplied:Double
}
