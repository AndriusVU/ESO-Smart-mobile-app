//
//  ForecastData.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-11-16.
//  Copyright © 2020 Instamobile. All rights reserved.
//

struct ForecastData:Codable {
    let time:String
    let forecast_usage:Double
    let planned_production:Double
    let planned_production_wind:Double
}
