//
//  PlanData.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-10-01.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation


enum ZoneType:Int {
    case ZONE_1 = 9001
    case ZONE_2 = 9002
    
    func getTitle() -> String {
        switch self {
        case .ZONE_1:
            return "Vienos laiko zonos"
        case .ZONE_2:
            return "Dviejų laiko zonų"
        default:
            return "nezinoma"
        }
    }
}

struct ZoneHours {
    static let dayHours = 7...23
    //static let nightHours = 0...6
    
    static let morningHours = 5...6
    static let workingHours = 7...16
    static let eveningHours = 17...21
    
    static let weekendDays = [1,7]
}

enum PriceType:String {
    case DED = "ded"
    case ALL = "all"
    case NIGHT = "night"
    case MORNING = "morning"
    case DAY = "day"
    case EVENING = "evening"
    
    func getTitle() -> String {
        switch self {
        case .DED:
            return "Pastovioji dedamoji"
        case .ALL:
            return "Vienos laiko zonos energijos dedamoji"
        case .NIGHT:
            return "Naktinė ir savaitgalio dedamoji"
        case .DAY:
            return "Dieninė energijos dedamoji"
        default:
            return "nezinoma"
        }
    }
}

struct UserPlan:Codable {
    let plan:Plan
    let zone:Zone
}

struct PlanItems:Codable {
    let items:[Plan]
}

struct Plan:Codable {
    let id:Int
    let title:String
    let description:String
    var date_from:CmsDate? = nil
    var date_to:CmsDate? = nil
    var icon:String? = nil
    var zones: [Zone]? = nil
}

struct Zone:Codable {
    let id: Int?
    let title: String?
    let prices: [PricePart]
    var isSelected: Bool? = false
    
    func getPriceByDate(date:Date) -> Double {
    
        
        if(isSingleZone()){
            return getAllPrice()
        }else{
            
            let h = Calendar.current.component(.hour, from: date)
            let weekD = Calendar.current.component(.weekday, from: date)
            
            if ZoneHours.weekendDays.contains(weekD){
                if isFourZone(){
                    if ZoneHours.dayHours.contains(h){
                        return getDayPrice()
                    }else{
                        return getNightPrice()
                    }
                }else{
                    return getNightPrice()
                }
            }else{
                if isFourZone(){
                    
                    if ZoneHours.morningHours.contains(h){
                        return getMorningPrice()
                    }else if ZoneHours.workingHours.contains(h){
                        return getDayPrice()
                    }else if ZoneHours.eveningHours.contains(h){
                        return getEveningPrice()
                    }else{
                        return getNightPrice()
                    }
                    
                }else{
                    if ZoneHours.dayHours.contains(h){
                        return getDayPrice()
                    }else{
                        return getNightPrice()
                    }
                }
            }
            

            
        }
        
        return 0
    }
    func getPriceByTime(time:Int) -> Double {
        
        let h = time == 24 ? 0 : time
        
        if(isSingleZone()){
            return getAllPrice()
        }else{
            
            if isFourZone(){
                
                if ZoneHours.morningHours.contains(h){
                    return getMorningPrice()
                }else if ZoneHours.workingHours.contains(h){
                    return getDayPrice()
                }else if ZoneHours.eveningHours.contains(h){
                    return getEveningPrice()
                }else{
                    return getNightPrice()
                }
                
            }else{
                if ZoneHours.dayHours.contains(h){
                    return getDayPrice()
                }else{
                    return getNightPrice()
                }
            }
            
        }
        
        return 0
    }
    
    func isFourZone() -> Bool {
        return prices.first(where: {$0.id == PriceType.MORNING.rawValue}) != nil
    }
    func isTwoZone() -> Bool {
        return prices.first(where: {$0.id == PriceType.NIGHT.rawValue}) != nil
    }
    func isSingleZone() -> Bool {
        return prices.first(where: {$0.id == PriceType.ALL.rawValue}) != nil
    }
    
    func getDedPrice() -> Double {
        return getPrice(PriceType.DED)
    }
    func getDayPrice() -> Double {
        return getPrice(PriceType.DAY)
    }
    func getNightPrice() -> Double {
        return getPrice(PriceType.NIGHT)
    }
    func getAllPrice() -> Double {
        return getPrice(PriceType.ALL)
    }
    func getMorningPrice() -> Double {
        return getPrice(PriceType.MORNING)
    }
    func getEveningPrice() -> Double {
        return getPrice(PriceType.EVENING)
    }
    
    func getPrice(_ type:PriceType) -> Double {
        if let p = prices.first(where: {
            $0.id == type.rawValue
        }){
            return p.price ?? 0
        }
        
        return 0
        
    }
}

struct PricePart:Codable {
    let id: String
    let title: String?
    let price: Double?
}
