//
//  RegisterData.swift
//  EsoSmart
//
//  Created by Evaldas on 2021-01-26.
//  Copyright © 2021 Instamobile. All rights reserved.
//

struct RegisterData:Codable {
    let token:String
    let id:Int
}
