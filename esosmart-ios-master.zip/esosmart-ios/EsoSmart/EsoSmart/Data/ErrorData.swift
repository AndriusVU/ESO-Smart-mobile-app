//
//  ErrorData.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-11-16.
//  Copyright © 2020 Instamobile. All rights reserved.
//

struct ErrorData:Codable {
    let error:String
    var code:Int? = nil
}
