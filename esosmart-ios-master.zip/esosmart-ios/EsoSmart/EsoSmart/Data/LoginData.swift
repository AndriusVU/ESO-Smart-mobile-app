//
//  LoginData.swift
//  EsoSmart
//
//  Created by Evaldas on 2021-02-02.
//  Copyright © 2021 Instamobile. All rights reserved.
//

struct LoginData:Codable {
    let ok:Bool
}
