//
//  CompareData.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-10-22.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation

struct CompareData:Codable {
    let my_total:Double
    let my_average:Double
    let others_average:Double
    let energy_group:EnergyGroup?
}

struct EnergyGroup:Codable {
    let id:Int
    let interval_from:Int
    let interval_to:Int
    let title:String
}
