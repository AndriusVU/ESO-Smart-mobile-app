//
//  HistoricalData.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-11-16.
//  Copyright © 2020 Instamobile. All rights reserved.
//


struct HistoricalPrice:Codable {
    let year:Int
    let month:Int
    let hour:String
    let energy_usage:Double
    let production:Double
    let production_wind:Double
}
