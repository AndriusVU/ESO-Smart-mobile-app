//
//  BaseTextField.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-09-29.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation
import UIKit

class BaseTextField:UITextField{
    @IBInspectable var cornerRadius: CGFloat = 26 { didSet { self.layer.cornerRadius = cornerRadius } }
    
    let padding = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 5)
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    override func prepareForInterfaceBuilder() {
        setup()
        super.prepareForInterfaceBuilder()
    }
    
    private func setup() {
        
        clipsToBounds = true
        
        backgroundColor = UIColor.white
        
        layer.borderWidth = 2
        layer.cornerRadius = cornerRadius
        layer.borderColor = UIColor.colorPrimary.cgColor
        
    }
    
    

    override open func textRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }

    override open func placeholderRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }

    override open func editingRect(forBounds bounds: CGRect) -> CGRect {
        return bounds.inset(by: padding)
    }
}
