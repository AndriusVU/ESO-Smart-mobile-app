//
//  BaseButton.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-09-29.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation
import UIKit

class BaseButton:UIButton{
    
    @IBInspectable var cornerRadius: CGFloat = 26 { didSet { self.layer.cornerRadius = cornerRadius } }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    override func prepareForInterfaceBuilder() {
        setup()
        super.prepareForInterfaceBuilder()
    }
    
    private func setup() {
        
        clipsToBounds = true
        cornerRadius = 16

        contentEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        
        backgroundColor = UIColor.white
        
        layer.borderWidth = 2
        layer.borderColor = UIColor.colorPrimary.cgColor
        
        
        setTitleColor(UIColor.colorPrimary, for: .normal)
        
    }
}
