//
//  DateHelper.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-10-09.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation


class DateHelper{
    
    static var dateFormatterISO:DateFormatter = {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.locale = Locale(identifier: "lt_LT")
        return dateFormatter
    }()
    
    static func strToDate(_ date:String) -> Date{
        return dateFormatterISO.date(from: date) ?? Date()
    }
}
