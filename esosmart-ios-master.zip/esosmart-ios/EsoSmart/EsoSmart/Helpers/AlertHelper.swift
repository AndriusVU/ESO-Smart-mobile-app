//
//  AlertHelper.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-10-01.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import UIKit


class AlertHelper {
    static func showError(view:UIViewController, error:Int, message:String? = nil){
        
        switch error {
        case 6:
            showError(view: view, message: "Panašų, kad šiuo metu neveikia internetas. Pabandykite prisijungti prie tinklo ir paleisti programėlę iš naujo")
        default:
            showError(view: view, message: message ?? String(error))
        }
        
    }
    static func showError(view:UIViewController, message:String){
        let dialogMessage = UIAlertController(title: "Dėmesio!", message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "Gerai", style: .default)
        dialogMessage.addAction(ok)
        view.present(dialogMessage, animated: true, completion: nil)
    }
    
    static func showAlert(view:UIViewController, message:String){
        let dialogMessage = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "Gerai", style: .default)
        dialogMessage.addAction(ok)
        view.present(dialogMessage, animated: true, completion: nil)
    }
    
}
