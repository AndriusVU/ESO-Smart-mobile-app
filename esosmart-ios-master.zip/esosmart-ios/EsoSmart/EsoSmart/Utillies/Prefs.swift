//
//  Prefs.swift
//  EsoSmart
//
//  Created by Evaldas on 2020-09-30.
//  Copyright © 2020 Instamobile. All rights reserved.
//

import Foundation

class Prefs {
    
    
    static private let USERPLAN = "USERPLAN_003"
    static private let USERTOKEN = "USERTOKEN"
    
    static private let storage = UserDefaults.standard
    
    static let jsonEncoder = JSONEncoder()
    static let jsonDecoder = JSONDecoder()
    
    static var userPlan:UserPlan?{
        get{
            
            if let encodedData = storage.object(forKey: USERPLAN) as? Data{
                if let userPlan = try? jsonDecoder.decode(UserPlan.self, from: encodedData){
                    return userPlan
                }
            }
            
            return nil;
        }
        set{
            if let encodedData = try? jsonEncoder.encode(newValue){
                storage.set(encodedData, forKey: USERPLAN)
            }
        }
    }
    
    static var userToken:String?{
        get{
            if let token = storage.string(forKey: USERTOKEN){
                return token
            }
            return nil
        }
        set{
            
            if newValue == nil{
                storage.removeObject(forKey: USERTOKEN)
            }else{
                storage.setValue(newValue, forKey: USERTOKEN)
            }
        }
    }
    
    static var confirmationHash:String? = nil;
    
    static var userData:UserData? = nil
    
    static func clearData(){
        storage.removeObject(forKey: USERPLAN)
        storage.removeObject(forKey: USERTOKEN)
        userData = nil
    }
}
