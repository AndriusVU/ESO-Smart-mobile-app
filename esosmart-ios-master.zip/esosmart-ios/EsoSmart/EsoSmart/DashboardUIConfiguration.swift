//
//  DashboardUIConfiguration.swift
//  DashboardApp
//
//  Created by Florian Marcu on 7/28/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

class DashboardUIConfiguration: ATCDashboardConfigurationProtocol, ATCOnboardingServerConfigurationProtocol {
    let mainThemeBackgroundColor: UIColor = .white
    let mainThemeForegroundColor: UIColor = UIColor(hexString: "#b4cc01")
    let mainTextColor: UIColor = UIColor(hexString: "#464646")
    let mainSubtextColor: UIColor = UIColor(hexString: "#b6b9bf")
    let statusBarStyle: UIStatusBarStyle = .default
    let hairlineColor: UIColor = UIColor(hexString: "#d6d6d6")

    let regularSmallFont = UIFont(name: "Avenir", size: 12)!
    let regularMediumFont = UIFont(name: "Avenir", size: 16)!
    let regularSemiLargeFont = UIFont(name: "Avenir", size: 18)!
    let regularLargeFont = UIFont(name: "Avenir", size: 20)!

    let mediumBoldFont = UIFont(name: "Avenir-heavy", size: 16)!
    let semiLargeMediumFont = UIFont(name: "Avenir-Medium", size: 22)!
    let boldLargeFont = UIFont(name: "Avenir-Heavy", size: 30)!

    let boldSmallFont = UIFont(name: "AppleSDGothicNeo-Bold", size: 12)!
    let boldSuperSmallFont = UIFont(name: "AppleSDGothicNeo-Bold", size: 10)!
    let boldSuperLargeFont = UIFont(name: "AppleSDGothicNeo-Bold", size: 28)!


    let italicMediumFont = UIFont(name: "TrebuchetMS-Italic", size: 14)!

    func regularFont(size: CGFloat) -> UIFont {
        return UIFont(name: "AppleSDGothicNeo-Regular", size: size)!
    }

    func boldFont(size: CGFloat) -> UIFont {
        return UIFont(name: "AppleSDGothicNeo-Bold", size: size)!
    }

    func configureUI() {
        UINavigationBar.appearance().backgroundColor = .red //self.mainThemeBackgroundColor
        UINavigationBar.appearance().barTintColor = self.mainThemeForegroundColor
        UINavigationBar.appearance().tintColor = .white
        UINavigationBar.appearance().isTranslucent = false

        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white,
                                                            NSAttributedString.Key.font: self.semiLargeMediumFont,
                                                            ]
    }

    var isFirebaseAuthEnabled: Bool {
        return false
    }

    var appIdentifier: String {
        return "ESO Smart"
    }
}
