//
//  AppDelegate.swift
//  DashboardApp
//
//  Created by Florian Marcu on 7/28/18.
//  Copyright © 2018 Instamobile. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    let config = DashboardUIConfiguration()
    
    
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        if
            let scheme = url.scheme,
            scheme.localizedCaseInsensitiveCompare("esosmart") == .orderedSame,
            let view = url.host
        {
            
            switch view{
                case "users.confirm":
                    URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.forEach { queryItem in
                        if queryItem.name == "hash", let hash = queryItem.value, !hash.isEmpty{
                            Prefs.confirmationHash = hash
                            window?.rootViewController = ATCDashboardHostViewController(uiConfig: config, serverConfig: config)
                        }
                    }
                    
                    break
                default:
                    break
            }
            
            
        }
        
        return true
    }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        
        config.configureUI()

//        if (config.isFirebaseAuthEnabled) {
//            FirebaseApp.configure()
//        }

        // Window setup
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.rootViewController = ATCDashboardHostViewController(uiConfig: config, serverConfig: config)
        window?.makeKeyAndVisible()
        
        //Prefs.userToken = "2d260b293b025018f21b81c5afd82298"
        
        //print("user token:", Prefs.userToken)

        return true
    }

//    func applicationWillEnterForeground(_ application: UIApplication) {
//        config.configureUI()
//
//        if (config.isFirebaseAuthEnabled) {
//            FirebaseApp.configure()
//        }
//
//        // Window setup
//        window = UIWindow(frame: UIScreen.main.bounds)
//        window?.rootViewController = ATCDashboardHostViewController(uiConfig: config, serverConfig: config)
//        window?.makeKeyAndVisible()
//    }
}

